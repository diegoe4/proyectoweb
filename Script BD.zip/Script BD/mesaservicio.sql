-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 25-01-2021 a las 17:22:15
-- Versión del servidor: 10.4.14-MariaDB
-- Versión de PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `mesaservicio`
--
CREATE DATABASE IF NOT EXISTS `mesaservicio` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `mesaservicio`;

DELIMITER $$
--
-- Procedimientos
--
DROP PROCEDURE IF EXISTS `pro_obtener_tickets_ano`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `pro_obtener_tickets_ano` (IN `ano` VARCHAR(4))  BEGIN

SELECT f.estado_id,sum(f.01) as '01',
sum(f.02) as '02',sum(f.03) as '03',sum(f.04) as '04',sum(f.05) as '05',
sum(f.06) as '06',sum(f.07) as '07',sum(f.08) as '08',sum(f.09) as '09',
sum(f.10) as '10',sum(f.11) as '11',sum(f.12) as '12' FROM (SELECT t.id as ticket_id,t.estado_id as estado_id, 
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='01' THEN 1 ELSE 0 END AS '01',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='02' THEN 1 ELSE 0 END AS '02',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='03' THEN 1 ELSE 0 END AS '03',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='04' THEN 1 ELSE 0 END AS '04',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='05' THEN 1 ELSE 0 END AS '05',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='06' THEN 1 ELSE 0 END AS '06',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='07' THEN 1 ELSE 0 END AS '07',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='08' THEN 1 ELSE 0 END AS '08',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='09' THEN 1 ELSE 0 END AS '09',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='10' THEN 1 ELSE 0 END AS '10',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='11' THEN 1 ELSE 0 END AS '11',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='12' THEN 1 ELSE 0 END AS '12'
FROM tickets t, estados e
WHERE t.estado_id = e.id AND CAST(t.fecha_creacion AS CHAR) like CONCAT('%', ano , '%')) AS f GROUP BY f.estado_id,f.01,f.02,f.03,f.04,f.05,f.06,f.07,f.08,f.09,f.10,f.11,f.12;

	
END$$

DROP PROCEDURE IF EXISTS `pro_obtener_tickets_ano_area`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `pro_obtener_tickets_ano_area` (IN `ano` VARCHAR(4), IN `area` VARCHAR(100))  BEGIN

SELECT f.estado_id,sum(f.01) as '01',
sum(f.02) as '02',sum(f.03) as '03',sum(f.04) as '04',sum(f.05) as '05',
sum(f.06) as '06',sum(f.07) as '07',sum(f.08) as '08',sum(f.09) as '09',
sum(f.10) as '10',sum(f.11) as '11',sum(f.12) as '12' FROM (SELECT t.id as ticket_id,t.estado_id as estado_id, 
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='01' THEN 1 ELSE 0 END AS '01',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='02' THEN 1 ELSE 0 END AS '02',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='03' THEN 1 ELSE 0 END AS '03',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='04' THEN 1 ELSE 0 END AS '04',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='05' THEN 1 ELSE 0 END AS '05',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='06' THEN 1 ELSE 0 END AS '06',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='07' THEN 1 ELSE 0 END AS '07',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='08' THEN 1 ELSE 0 END AS '08',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='09' THEN 1 ELSE 0 END AS '09',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='10' THEN 1 ELSE 0 END AS '10',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='11' THEN 1 ELSE 0 END AS '11',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='12' THEN 1 ELSE 0 END AS '12'
FROM tickets t, estados e
WHERE t.estado_id = e.id AND CAST(t.fecha_creacion AS CHAR) like CONCAT('%', ano , '%')
AND t.user_id in (select em.user_id from empleados em, areas ar WHERE ar.id = em.area_id AND CAST(ar.id AS CHAR) LIKE CAST(area AS CHAR))) AS f GROUP BY f.estado_id,f.01,f.02,f.03,f.04,f.05,f.06,f.07,f.08,f.09,f.10,f.11,f.12;

	
END$$

DROP PROCEDURE IF EXISTS `pro_obtener_tickets_ano_departamento`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `pro_obtener_tickets_ano_departamento` (IN `ano` VARCHAR(4), IN `departamento` VARCHAR(100))  BEGIN

SELECT f.estado_id,sum(f.01) as '01',
sum(f.02) as '02',sum(f.03) as '03',sum(f.04) as '04',sum(f.05) as '05',
sum(f.06) as '06',sum(f.07) as '07',sum(f.08) as '08',sum(f.09) as '09',
sum(f.10) as '10',sum(f.11) as '11',sum(f.12) as '12' FROM (SELECT t.id as ticket_id,t.estado_id as estado_id, 
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='01' THEN 1 ELSE 0 END AS '01',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='02' THEN 1 ELSE 0 END AS '02',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='03' THEN 1 ELSE 0 END AS '03',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='04' THEN 1 ELSE 0 END AS '04',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='05' THEN 1 ELSE 0 END AS '05',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='06' THEN 1 ELSE 0 END AS '06',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='07' THEN 1 ELSE 0 END AS '07',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='08' THEN 1 ELSE 0 END AS '08',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='09' THEN 1 ELSE 0 END AS '09',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='10' THEN 1 ELSE 0 END AS '10',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='11' THEN 1 ELSE 0 END AS '11',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='12' THEN 1 ELSE 0 END AS '12'
FROM tickets t, estados e
WHERE t.estado_id = e.id AND CAST(t.fecha_creacion AS CHAR) like CONCAT('%', ano , '%')
AND t.user_id in (select em.user_id from empleados em, areas ar, departamentos d WHERE ar.id = em.area_id AND ar.departamento_id = d.id AND CAST(d.id AS CHAR) LIKE CAST(departamento AS CHAR))) AS f GROUP BY f.estado_id,f.01,f.02,f.03,f.04,f.05,f.06,f.07,f.08,f.09,f.10,f.11,f.12;

	
END$$

DROP PROCEDURE IF EXISTS `pro_obtener_tickets_ano_sucursal`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `pro_obtener_tickets_ano_sucursal` (IN `ano` VARCHAR(4), IN `sucursal` VARCHAR(100))  BEGIN

SELECT f.estado_id,sum(f.01) as '01',
sum(f.02) as '02',sum(f.03) as '03',sum(f.04) as '04',sum(f.05) as '05',
sum(f.06) as '06',sum(f.07) as '07',sum(f.08) as '08',sum(f.09) as '09',
sum(f.10) as '10',sum(f.11) as '11',sum(f.12) as '12' FROM (SELECT t.id as ticket_id,t.estado_id as estado_id, 
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='01' THEN 1 ELSE 0 END AS '01',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='02' THEN 1 ELSE 0 END AS '02',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='03' THEN 1 ELSE 0 END AS '03',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='04' THEN 1 ELSE 0 END AS '04',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='05' THEN 1 ELSE 0 END AS '05',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='06' THEN 1 ELSE 0 END AS '06',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='07' THEN 1 ELSE 0 END AS '07',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='08' THEN 1 ELSE 0 END AS '08',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='09' THEN 1 ELSE 0 END AS '09',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='10' THEN 1 ELSE 0 END AS '10',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='11' THEN 1 ELSE 0 END AS '11',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='12' THEN 1 ELSE 0 END AS '12'
FROM tickets t, estados e
WHERE t.estado_id = e.id AND CAST(t.fecha_creacion AS CHAR) like CONCAT('%', ano , '%')
AND t.user_id in (select em.user_id from empleados em, areas ar, departamentos d,sucursals s WHERE ar.id = em.area_id AND ar.departamento_id = d.id AND s.id = d.sucursal_id AND CAST(s.id AS CHAR) LIKE CAST(sucursal AS CHAR))) AS f GROUP BY f.estado_id,f.01,f.02,f.03,f.04,f.05,f.06,f.07,f.08,f.09,f.10,f.11,f.12;

	
END$$

DROP PROCEDURE IF EXISTS `pro_obtener_tickets_general`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `pro_obtener_tickets_general` (IN `ano` VARCHAR(4), IN `consulta` VARCHAR(4))  BEGIN

IF consulta ='TODO' THEN

select * from (select f.nombre,sum(f.01) as '01',
sum(f.02) as '02',sum(f.03) as '03',sum(f.04) as '04',sum(f.05) as '05',
sum(f.06) as '06',sum(f.07) as '07',sum(f.08) as '08',sum(f.09) as '09',
sum(f.10) as '10',sum(f.11) as '11',sum(f.12) as '12',sum(f.01)+sum(f.02)+sum(f.03)+sum(f.04)+
sum(f.05)+sum(f.06)+sum(f.07)+sum(f.08)+sum(f.09)+sum(f.10)+sum(f.11)+sum(f.12) as TOTAL
from (
SELECT e.nombre,CASE WHEN SUBSTR(t.fecha_creacion,6,2)='01' THEN 1 ELSE 0 END AS '01',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='02' THEN 1 ELSE 0 END AS '02',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='03' THEN 1 ELSE 0 END AS '03',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='04' THEN 1 ELSE 0 END AS '04',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='05' THEN 1 ELSE 0 END AS '05',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='06' THEN 1 ELSE 0 END AS '06',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='07' THEN 1 ELSE 0 END AS '07',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='08' THEN 1 ELSE 0 END AS '08',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='09' THEN 1 ELSE 0 END AS '09',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='10' THEN 1 ELSE 0 END AS '10',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='11' THEN 1 ELSE 0 END AS '11',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='12' THEN 1 ELSE 0 END AS '12'
 from tickets t, estados e
WHERE t.estado_id = e.id AND CAST(t.fecha_creacion AS CHAR) like CONCAT('%', ano , '%')) as f GROUP BY f.nombre,f.01,f.02,f.03,f.04,f.05,f.06,f.07,f.08,f.09,f.10,f.11,f.12) as b ORDER BY TOTAL DESC;

END IF;


IF consulta ='AREA' THEN

select * from (select f.nombre, sum(f.01) as '01',
sum(f.02) as '02',sum(f.03) as '03',sum(f.04) as '04',sum(f.05) as '05',
sum(f.06) as '06',sum(f.07) as '07',sum(f.08) as '08',sum(f.09) as '09',
sum(f.10) as '10',sum(f.11) as '11',sum(f.12) as '12',sum(f.01)+sum(f.02)+sum(f.03)+sum(f.04)+
sum(f.05)+sum(f.06)+sum(f.07)+sum(f.08)+sum(f.09)+sum(f.10)+sum(f.11)+sum(f.12) as TOTAL
from (
SELECT ar.nombre,CASE WHEN SUBSTR(t.fecha_creacion,6,2)='01' THEN 1 ELSE 0 END AS '01',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='02' THEN 1 ELSE 0 END AS '02',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='03' THEN 1 ELSE 0 END AS '03',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='04' THEN 1 ELSE 0 END AS '04',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='05' THEN 1 ELSE 0 END AS '05',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='06' THEN 1 ELSE 0 END AS '06',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='07' THEN 1 ELSE 0 END AS '07',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='08' THEN 1 ELSE 0 END AS '08',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='09' THEN 1 ELSE 0 END AS '09',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='10' THEN 1 ELSE 0 END AS '10',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='11' THEN 1 ELSE 0 END AS '11',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='12' THEN 1 ELSE 0 END AS '12'
 from tickets t, users u,empleados em,areas ar
WHERE t.user_id = u.id AND em.user_id = u.id AND em.area_id=ar.id 
AND CAST(t.fecha_creacion AS CHAR) like CONCAT('%', ano , '%')) as f GROUP BY f.nombre,f.01,f.02,f.03,f.04,f.05,f.06,f.07,f.08,f.09,f.10,f.11,f.12) as b ORDER BY TOTAL DESC;

END IF;

IF consulta ='DEPA' THEN

select * from (select f.nombre, sum(f.01) as '01',
sum(f.02) as '02',sum(f.03) as '03',sum(f.04) as '04',sum(f.05) as '05',
sum(f.06) as '06',sum(f.07) as '07',sum(f.08) as '08',sum(f.09) as '09',
sum(f.10) as '10',sum(f.11) as '11',sum(f.12) as '12',sum(f.01)+sum(f.02)+sum(f.03)+sum(f.04)+
sum(f.05)+sum(f.06)+sum(f.07)+sum(f.08)+sum(f.09)+sum(f.10)+sum(f.11)+sum(f.12) as TOTAL
from (
SELECT d.nombre,CASE WHEN SUBSTR(t.fecha_creacion,6,2)='01' THEN 1 ELSE 0 END AS '01',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='02' THEN 1 ELSE 0 END AS '02',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='03' THEN 1 ELSE 0 END AS '03',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='04' THEN 1 ELSE 0 END AS '04',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='05' THEN 1 ELSE 0 END AS '05',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='06' THEN 1 ELSE 0 END AS '06',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='07' THEN 1 ELSE 0 END AS '07',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='08' THEN 1 ELSE 0 END AS '08',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='09' THEN 1 ELSE 0 END AS '09',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='10' THEN 1 ELSE 0 END AS '10',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='11' THEN 1 ELSE 0 END AS '11',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='12' THEN 1 ELSE 0 END AS '12'
 from tickets t, users u,empleados em,areas ar,departamentos d
WHERE t.user_id = u.id AND em.user_id = u.id AND em.area_id=ar.id AND ar.departamento_id= d.id
AND CAST(t.fecha_creacion AS CHAR) like CONCAT('%', ano , '%')) as f GROUP BY f.nombre,f.01,f.02,f.03,f.04,f.05,f.06,f.07,f.08,f.09,f.10,f.11,f.12) as b ORDER BY TOTAL DESC;

END IF;


IF consulta ='SUCU' THEN

select * from (select f.nombre, sum(f.01) as '01',
sum(f.02) as '02',sum(f.03) as '03',sum(f.04) as '04',sum(f.05) as '05',
sum(f.06) as '06',sum(f.07) as '07',sum(f.08) as '08',sum(f.09) as '09',
sum(f.10) as '10',sum(f.11) as '11',sum(f.12) as '12',sum(f.01)+sum(f.02)+sum(f.03)+sum(f.04)+
sum(f.05)+sum(f.06)+sum(f.07)+sum(f.08)+sum(f.09)+sum(f.10)+sum(f.11)+sum(f.12) as TOTAL
from (
SELECT s.nombre,CASE WHEN SUBSTR(t.fecha_creacion,6,2)='01' THEN 1 ELSE 0 END AS '01',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='02' THEN 1 ELSE 0 END AS '02',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='03' THEN 1 ELSE 0 END AS '03',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='04' THEN 1 ELSE 0 END AS '04',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='05' THEN 1 ELSE 0 END AS '05',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='06' THEN 1 ELSE 0 END AS '06',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='07' THEN 1 ELSE 0 END AS '07',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='08' THEN 1 ELSE 0 END AS '08',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='09' THEN 1 ELSE 0 END AS '09',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='10' THEN 1 ELSE 0 END AS '10',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='11' THEN 1 ELSE 0 END AS '11',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='12' THEN 1 ELSE 0 END AS '12'
 from tickets t, users u,empleados em,areas ar,departamentos d,sucursals s
WHERE t.user_id = u.id AND em.user_id = u.id AND em.area_id=ar.id AND ar.departamento_id= d.id AND s.id = d.sucursal_id
AND CAST(t.fecha_creacion AS CHAR) like CONCAT('%', ano , '%')) as f GROUP BY f.nombre,f.01,f.02,f.03,f.04,f.05,f.06,f.07,f.08,f.09,f.10,f.11,f.12) as b ORDER BY TOTAL DESC;

END IF;


IF consulta ='CATE' THEN

select * from (select f.nombre, sum(f.01) as '01',
sum(f.02) as '02',sum(f.03) as '03',sum(f.04) as '04',sum(f.05) as '05',
sum(f.06) as '06',sum(f.07) as '07',sum(f.08) as '08',sum(f.09) as '09',
sum(f.10) as '10',sum(f.11) as '11',sum(f.12) as '12',sum(f.01)+sum(f.02)+sum(f.03)+sum(f.04)+
sum(f.05)+sum(f.06)+sum(f.07)+sum(f.08)+sum(f.09)+sum(f.10)+sum(f.11)+sum(f.12) as TOTAL
from (
SELECT c.nombre,CASE WHEN SUBSTR(t.fecha_creacion,6,2)='01' THEN 1 ELSE 0 END AS '01',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='02' THEN 1 ELSE 0 END AS '02',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='03' THEN 1 ELSE 0 END AS '03',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='04' THEN 1 ELSE 0 END AS '04',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='05' THEN 1 ELSE 0 END AS '05',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='06' THEN 1 ELSE 0 END AS '06',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='07' THEN 1 ELSE 0 END AS '07',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='08' THEN 1 ELSE 0 END AS '08',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='09' THEN 1 ELSE 0 END AS '09',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='10' THEN 1 ELSE 0 END AS '10',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='11' THEN 1 ELSE 0 END AS '11',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='12' THEN 1 ELSE 0 END AS '12'
 from tickets t, subcategorias sb,categorias c
WHERE t.subcategoria_id = sb.id AND sb.categoria_id = c.id 
AND CAST(t.fecha_creacion AS CHAR) like CONCAT('%', ano , '%')) as f GROUP BY f.nombre,f.01,f.02,f.03,f.04,f.05,f.06,f.07,f.08,f.09,f.10,f.11,f.12) as b ORDER BY TOTAL;

END IF;

IF consulta ='SUBC' THEN

select * from (select f.nombre, sum(f.01) as '01',
sum(f.02) as '02',sum(f.03) as '03',sum(f.04) as '04',sum(f.05) as '05',
sum(f.06) as '06',sum(f.07) as '07',sum(f.08) as '08',sum(f.09) as '09',
sum(f.10) as '10',sum(f.11) as '11',sum(f.12) as '12',sum(f.01)+sum(f.02)+sum(f.03)+sum(f.04)+
sum(f.05)+sum(f.06)+sum(f.07)+sum(f.08)+sum(f.09)+sum(f.10)+sum(f.11)+sum(f.12) as TOTAL
from (
SELECT sb.nombre,CASE WHEN SUBSTR(t.fecha_creacion,6,2)='01' THEN 1 ELSE 0 END AS '01',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='02' THEN 1 ELSE 0 END AS '02',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='03' THEN 1 ELSE 0 END AS '03',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='04' THEN 1 ELSE 0 END AS '04',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='05' THEN 1 ELSE 0 END AS '05',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='06' THEN 1 ELSE 0 END AS '06',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='07' THEN 1 ELSE 0 END AS '07',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='08' THEN 1 ELSE 0 END AS '08',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='09' THEN 1 ELSE 0 END AS '09',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='10' THEN 1 ELSE 0 END AS '10',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='11' THEN 1 ELSE 0 END AS '11',
CASE WHEN SUBSTR(t.fecha_creacion,6,2)='12' THEN 1 ELSE 0 END AS '12'
 from tickets t, subcategorias sb
WHERE t.subcategoria_id = sb.id 
AND CAST(t.fecha_creacion AS CHAR) like CONCAT('%', ano , '%')) as f GROUP BY f.nombre,f.01,f.02,f.03,f.04,f.05,f.06,f.07,f.08,f.09,f.10,f.11,f.12) as b ORDER BY TOTAL DESC LIMIT 1;

END IF;



END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `areas`
--

DROP TABLE IF EXISTS `areas`;
CREATE TABLE `areas` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `departamento_id` int(11) NOT NULL,
  `mesa_servicio` tinyint(1) DEFAULT 1,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `areas`
--

INSERT INTO `areas` (`id`, `nombre`, `descripcion`, `departamento_id`, `mesa_servicio`, `activo`, `fecha_creacion`) VALUES
(1, 'Soporte Mesa de Servicio', 'Equipo de la mesa de servicio', 1, 1, 1, '2020-10-28 21:54:03'),
(2, 'Planeación Financiera', 'Finanzas', 3, 1, 1, '2020-11-26 03:06:04'),
(3, 'Servicio al Cliente', 'Customer Office', 5, 1, 1, '2020-11-26 03:07:00'),
(4, 'Comunicacines', 'Comms', 6, 1, 1, '2020-11-26 23:52:55');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cake_d_c_users_phinxlog`
--

DROP TABLE IF EXISTS `cake_d_c_users_phinxlog`;
CREATE TABLE `cake_d_c_users_phinxlog` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cake_d_c_users_phinxlog`
--

INSERT INTO `cake_d_c_users_phinxlog` (`version`, `migration_name`, `start_time`, `end_time`, `breakpoint`) VALUES
(20150513201111, 'Initial', '2020-10-16 08:49:54', '2020-10-16 08:49:54', 0),
(20161031101316, 'AddSecretToUsers', '2020-10-16 08:49:54', '2020-10-16 08:49:54', 0),
(20190208174112, 'AddAdditionalDataToUsers', '2020-10-16 08:49:54', '2020-10-16 08:49:55', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`, `descripcion`, `activo`, `fecha_creacion`) VALUES
(1, 'Soporte de Aplicaciones', 'Soporte de todos los aplicativos de la compañia', 1, '2020-10-28 20:51:18'),
(2, 'Soporte de Infraestructura', 'Soporte Servicios de Infraestructura', 1, '2020-10-28 20:52:01');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

DROP TABLE IF EXISTS `comentarios`;
CREATE TABLE `comentarios` (
  `id` int(11) NOT NULL,
  `detalle` varchar(1000) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `user_id` char(36) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `comentarios`
--

INSERT INTO `comentarios` (`id`, `detalle`, `ticket_id`, `user_id`, `fecha_creacion`) VALUES
(3, 'prueba', 32, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '2020-11-12 20:59:15'),
(4, 'prprprprpr', 32, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '2020-11-12 21:04:01'),
(5, 'ooototoot', 32, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '2020-11-12 21:12:46'),
(6, 'rrrrrrr', 32, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '2020-11-12 21:13:05');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentario_archivos`
--

DROP TABLE IF EXISTS `comentario_archivos`;
CREATE TABLE `comentario_archivos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `extension` varchar(5) NOT NULL,
  `contenido` blob DEFAULT NULL,
  `tamano` int(11) NOT NULL,
  `comentario_id` int(11) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamentos`
--

DROP TABLE IF EXISTS `departamentos`;
CREATE TABLE `departamentos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `sucursal_id` int(11) NOT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `departamentos`
--

INSERT INTO `departamentos` (`id`, `nombre`, `descripcion`, `empresa_id`, `sucursal_id`, `activo`, `fecha_creacion`) VALUES
(1, 'TI y Operaciones', 'Departamento de Sistemas y Operaciones', 1, 1, 1, '2020-10-28 18:52:21'),
(2, 'RRHH', 'Departamento de RRHH', 1, 1, 1, '2020-11-25 20:27:26'),
(3, 'Comercial Quito', 'Involucra todas las operaciones de Quito', 1, 1, 1, '2020-11-25 20:30:05'),
(4, 'Comercial Guayaquil', 'Involucra toda el area comercial de Guayaquil', 1, 2, 1, '2020-11-25 20:30:42'),
(5, 'Suscripción', 'Departamento de Suscriptor', 2, 1, 1, '2020-11-26 03:02:48'),
(6, 'Marketing', 'Departamento de comunicaciones', 1, 3, 1, '2020-11-26 23:52:33');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

DROP TABLE IF EXISTS `empleados`;
CREATE TABLE `empleados` (
  `id` int(11) NOT NULL,
  `user_id` char(36) NOT NULL,
  `area_id` int(11) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_ingreso` timestamp NULL DEFAULT NULL,
  `cargo` varchar(80) NOT NULL,
  `jefe` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`id`, `user_id`, `area_id`, `fecha_creacion`, `fecha_ingreso`, `cargo`, `jefe`) VALUES
(1, '74e24098-069c-4393-aede-0245475f01ac', 1, '2020-12-04 00:30:56', '2020-10-30 00:35:48', 'Asesor Comercial', 'Fausto Cobos'),
(3, '4759500e-0e79-46b4-b506-bd3e304afd6f', 2, '2020-12-04 00:31:18', '2020-11-01 23:53:09', 'Subgerente Financiera', 'Benedikt Meier'),
(4, 'df01ed54-4aa7-487e-a563-161f3acd4f66', 3, '2020-12-04 00:31:59', '2018-01-27 06:11:26', 'Gerente Customer Experience', 'Cynthia Dueñas'),
(5, 'f6f53803-812a-402b-bf38-2a55c24a55ae', 4, '2020-12-04 00:32:31', '2016-03-12 05:12:08', 'Asistente de Comunicaciones', 'Alejandra Romero'),
(6, '9ed5a9ac-f87d-4499-8967-8816b0db646c', 3, '2020-12-04 00:33:59', '2020-12-02 15:49:29', 'Director de Infraestructura y Soporte', 'Juan Carlos  Flores'),
(7, 'a18c21ee-dc0e-45eb-afb8-93b9d0789d09', 1, '2020-12-04 00:34:58', '2020-12-02 15:50:58', 'Analista de mesa de Servicio', 'Diego Estrella'),
(8, 'e869c107-8ab1-4b22-b037-5d015f2261ad', 2, '2020-12-04 00:35:35', '2020-12-02 15:52:12', 'Gerente de Planificación Financiera', 'Aston '),
(9, '4fd43ed4-d5d0-44a2-a3d2-278ac08cf936', 1, '2020-12-04 00:28:44', '2020-12-03 19:28:13', 'Soporte Contabilidad', 'Mariela Ballesteros');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresas`
--

DROP TABLE IF EXISTS `empresas`;
CREATE TABLE `empresas` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `empresas`
--

INSERT INTO `empresas` (`id`, `nombre`, `descripcion`, `activo`, `fecha_creacion`) VALUES
(1, 'Zurich Seguros', 'Empresa principal', 1, '2020-10-28 16:19:03'),
(2, 'Kruger', 'Proveedor de Servicios Informáticos ', 1, '2020-10-28 16:19:35');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuestas`
--

DROP TABLE IF EXISTS `encuestas`;
CREATE TABLE `encuestas` (
  `id` int(11) NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `departamento_id` int(11) NOT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `encuestas`
--

INSERT INTO `encuestas` (`id`, `nombre`, `descripcion`, `departamento_id`, `activo`, `fecha_creacion`) VALUES
(2, 'Encuesta de Satisfacción de IT', 'Evaluar el servicio de IT', 3, 1, '2020-12-04 00:51:34');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados`
--

DROP TABLE IF EXISTS `estados`;
CREATE TABLE `estados` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `estados`
--

INSERT INTO `estados` (`id`, `nombre`, `descripcion`, `activo`, `fecha_creacion`) VALUES
(1, 'Nueva', 'Nuevos Tickets', 1, '2020-10-28 20:34:54'),
(2, 'Asignada', 'Estado del Ticket', 1, '2020-10-28 20:35:53'),
(4, 'Cerrada', 'Estado del Ticket', 1, '2020-10-28 20:36:28'),
(5, 'Rechazada', 'Estado de los Tickets', 1, '2020-10-28 20:36:49');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historico_cambios`
--

DROP TABLE IF EXISTS `historico_cambios`;
CREATE TABLE `historico_cambios` (
  `id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `cambio` varchar(1000) NOT NULL,
  `comentario_id` int(11) DEFAULT NULL,
  `user_id` char(36) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `historico_cambios`
--

INSERT INTO `historico_cambios` (`id`, `ticket_id`, `cambio`, `comentario_id`, `user_id`, `fecha_creacion`) VALUES
(48, 30, 'Cambio realizado en lo siguiente:   ', NULL, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '2020-11-13 23:40:43'),
(49, 30, 'Cambio realizado en lo siguiente:Se cambio de tipo: 1 a Tipo: Requerimiento   ', NULL, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '2020-11-13 23:43:02'),
(50, 30, 'Cambio realizado en lo siguiente:Se cambio de tipo: 2 a Tipo: Incidente   ', NULL, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '2020-11-13 23:44:22'),
(51, 30, 'Cambio realizado en lo siguiente:Se cambio de Tipo: Incidente a Tipo: Requerimiento Se cambio de Proyecto: Tickets RRHH a Proyecto: Tickets Mesa de Servicio Se cambio de Estado: Nueva a Estado: Asignada Se cambio de Prioridad: Baja a Prioridad: Alta Se cambio de Subcategoria: Revisión de máquina PC a Subcategoria: Acceso usuario de base de datos', NULL, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '2020-11-14 00:00:45');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations_phinxlog`
--

DROP TABLE IF EXISTS `migrations_phinxlog`;
CREATE TABLE `migrations_phinxlog` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preguntas`
--

DROP TABLE IF EXISTS `preguntas`;
CREATE TABLE `preguntas` (
  `id` int(11) NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `encuesta_id` int(11) NOT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `explicacion_usuario` tinyint(1) DEFAULT 1,
  `orden` int(11) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `preguntas`
--

INSERT INTO `preguntas` (`id`, `nombre`, `descripcion`, `encuesta_id`, `activo`, `explicacion_usuario`, `orden`, `fecha_creacion`) VALUES
(1, '¿ Usted está satisfecho con el servicio de IT?', '¿ Usted está satisfecho con el servicio de IT?', 2, 1, 1, 4, '2020-12-04 00:52:20'),
(2, 'Ha tenido problemas con su computador', 'Medir satisfacción de IT', 2, 1, 1, 2, '2020-12-04 00:52:52'),
(3, 'Usted usa un plan celular corporativo', 'Usted usa un plan celular corporativo', 2, 1, 1, 3, '2020-12-04 00:53:17'),
(4, 'Usted ha tenido problemas de IT', 'Usted ha tenido problemas de IT', 2, 1, 1, 7, '2020-12-04 00:53:49'),
(5, 'pregunta 5 ', 'pregunta 5 ', 2, 1, 1, 8, '2020-12-04 00:54:20'),
(6, 'pregunta otra', 'pregunta otra', 2, 1, 1, 10, '2020-12-04 00:54:36'),
(7, 'pregunta adicional', 'pregunta adicional', 2, 1, 1, 11, '2020-12-04 00:54:47'),
(8, 'primera pregunta', 'primera pregunta', 2, 1, 1, 1, '2020-12-04 00:55:05'),
(9, 'pregunta adicionalpregunta adicional', 'pregunta adicionalpregunta adicional', 2, 1, 1, 19, '2020-12-04 00:57:54'),
(10, 'ejemolos', 'ejemolos', 2, 1, 1, 15, '2020-12-04 00:58:20'),
(11, 'holdkdd', 'dasdad', 2, 1, 1, 14, '2020-12-04 02:12:17'),
(12, 'sdsds', 'sdsdsd', 2, 1, 1, 30, '2020-12-04 02:12:38'),
(13, 'adsdsd', 'sdsds', 2, 1, 1, 12, '2020-12-04 02:47:56');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prioridads`
--

DROP TABLE IF EXISTS `prioridads`;
CREATE TABLE `prioridads` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `prioridads`
--

INSERT INTO `prioridads` (`id`, `nombre`, `descripcion`, `activo`, `fecha_creacion`) VALUES
(1, 'Alta', 'Prioridad de los tickets', 1, '2020-10-28 17:35:20'),
(2, 'Media', 'Prioridad de los Tickets', 1, '2020-10-28 17:35:35'),
(3, 'Baja', 'Prioridad de los Tickets', 1, '2020-10-28 17:35:59');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyectos`
--

DROP TABLE IF EXISTS `proyectos`;
CREATE TABLE `proyectos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `proyectos`
--

INSERT INTO `proyectos` (`id`, `nombre`, `descripcion`, `activo`, `fecha_creacion`) VALUES
(1, 'Soporte de Infraestructura', 'Proyecto que contendrá todos los tickets de la Mesa de Servicio', 1, '2020-10-28 16:00:49'),
(2, 'Soporte de Aplicaciones', 'Proyecto que mostrará todos los tickets que se asignen en RRHH', 1, '2020-10-28 16:01:53'),
(3, 'Soporte Reportería', 'Soporte aplicaciones legacy', 1, '2020-11-26 03:10:38'),
(4, 'Otros Servicios de IT', 'Reportes Ecuador', 1, '2020-11-26 03:11:13');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puntajes`
--

DROP TABLE IF EXISTS `puntajes`;
CREATE TABLE `puntajes` (
  `id` int(11) NOT NULL,
  `pregunta_id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `calificacion` smallint(6) DEFAULT 0,
  `explicacion` varchar(400) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `puntajes`
--

INSERT INTO `puntajes` (`id`, `pregunta_id`, `ticket_id`, `calificacion`, `explicacion`, `fecha_creacion`) VALUES
(1, 5, 39, 3, 'No apica', '2020-12-04 01:20:20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `seguidores`
--

DROP TABLE IF EXISTS `seguidores`;
CREATE TABLE `seguidores` (
  `id` int(11) NOT NULL,
  `user_id` char(36) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `activo` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `social_accounts`
--

DROP TABLE IF EXISTS `social_accounts`;
CREATE TABLE `social_accounts` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `provider` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `reference` varchar(255) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `link` varchar(255) NOT NULL,
  `token` varchar(500) NOT NULL,
  `token_secret` varchar(500) DEFAULT NULL,
  `token_expires` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `data` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subcategorias`
--

DROP TABLE IF EXISTS `subcategorias`;
CREATE TABLE `subcategorias` (
  `id` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `subcategorias`
--

INSERT INTO `subcategorias` (`id`, `categoria_id`, `nombre`, `descripcion`, `activo`, `fecha_creacion`) VALUES
(1, 2, 'Base de Datos', 'Errores en Base de Datos', 1, '2020-10-28 21:10:27'),
(2, 1, 'Accesos', 'Accesos a sistemas', 1, '2020-10-28 21:11:50'),
(4, 2, 'Creación de Servidores', 'Para crear nuevos servidores', 1, '2020-11-27 05:04:05'),
(5, 2, 'Reglas de Firewall', 'Soporte para crear nuevas reglas de firewall', 1, '2020-11-27 05:04:24'),
(6, 2, 'Equipo de Computación', 'Errores o requerimientos de equipos de computación', 1, '2020-11-28 00:32:47');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sucursals`
--

DROP TABLE IF EXISTS `sucursals`;
CREATE TABLE `sucursals` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `numero_empleados` int(11) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `sucursals`
--

INSERT INTO `sucursals` (`id`, `nombre`, `descripcion`, `direccion`, `telefono`, `numero_empleados`, `activo`, `fecha_creacion`) VALUES
(1, 'Matriz Quito', 'Sucursal Principal', NULL, NULL, NULL, 1, '2020-10-28 17:51:32'),
(2, 'Guayaquil', 'Sucursal de Guayaquil', NULL, NULL, NULL, 1, '2020-10-28 17:52:35'),
(3, 'Cuenca', 'Sucursal de Cuenca', NULL, NULL, NULL, 1, '2020-11-25 20:36:37'),
(4, 'Loja', 'Sucursal de loja', 'Cariamanga y Mariana de Jesus ', '+45454554545454', 4, 1, '2020-11-25 22:43:12'),
(5, 'Puyo', 'Agencia Puyo', 'Calle de los cerezos y Av9', '+5932595145', 3, 1, '2020-11-27 01:51:07');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tickets`
--

DROP TABLE IF EXISTS `tickets`;
CREATE TABLE `tickets` (
  `id` int(11) NOT NULL,
  `titulo` varchar(150) NOT NULL,
  `descripcion` varchar(4000) NOT NULL,
  `proyecto_id` int(11) NOT NULL,
  `estado_id` int(11) NOT NULL,
  `prioridad_id` int(11) NOT NULL,
  `user_id` char(36) NOT NULL,
  `asignado_id` char(36) NOT NULL,
  `tipo_id` int(11) NOT NULL,
  `subcategoria_id` int(11) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tickets`
--

INSERT INTO `tickets` (`id`, `titulo`, `descripcion`, `proyecto_id`, `estado_id`, `prioridad_id`, `user_id`, `asignado_id`, `tipo_id`, `subcategoria_id`, `fecha_creacion`) VALUES
(10, 'Error en mi teclado', 'No sirve mi teclado', 1, 4, 3, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2019-11-28 01:09:20'),
(30, 'ppp', 'prueba', 2, 1, 3, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 1, '2020-11-05 15:40:54'),
(31, 'prueba 2', 'prueba', 1, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 2, 2, '2020-11-05 15:42:13'),
(32, 'pruebw', 'prprpr', 1, 4, 1, '74e24098-069c-4393-aede-0245475f01ac', '', 1, 2, '2020-11-05 15:58:29'),
(33, 'Error  Base de Datos', 'Error al obtener un reporte', 1, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2020-11-26 03:09:42'),
(34, 'Error reporte de ventas mensual', 'El reporte de ventas mensual no se descarga', 4, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2020-10-26 03:13:12'),
(35, 'Error Reporte Infra', 'Error Reporte Infra', 1, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2020-11-26 23:54:15'),
(36, 'Error BD', 'BD', 3, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2020-11-27 01:52:54'),
(37, 'Error en mis accesos del sistema buxis', 'No puedo ingresar a mi sistema de nómina', 3, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2020-11-27 05:02:16'),
(38, 'Prima neta no se refleja en el sistema Póliza 2020', 'Prima neta no se refleja en el sistema Póliza 2020', 2, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 1, '2020-11-27 05:05:48'),
(39, 'Error reporte de ventas Enero a diciembre 2020', 'Error reporte de ventas Enero a diciembre 2020', 2, 1, 1, '4759500e-0e79-46b4-b506-bd3e304afd6f', '', 1, 1, '2020-11-27 05:09:32'),
(40, 'Error acceso Ensurance', 'No puedo ingresar al sistema', 2, 1, 1, '4759500e-0e79-46b4-b506-bd3e304afd6f', '', 1, 2, '2020-11-27 05:10:07'),
(41, 'Pantallazo azul en laptop', 'Pantallazo azul en laptop', 1, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2020-11-28 00:31:57'),
(42, 'Esto es prueba', 'Esto es prueba', 2, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2020-12-04 01:31:29'),
(43, 'Esto es pruebaddd', 'Esto es pruebafffff', 2, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2020-12-04 01:31:42'),
(44, 'dasdad', 'adadad', 4, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2020-12-04 01:32:17'),
(45, 'adadafa', 'fsdfsfsf', 4, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2020-12-04 01:32:24'),
(46, 'asdfadfasdf', 'sdfsdfsdfsd', 4, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2020-12-04 01:32:32'),
(47, 'sfdgg', 'gdgdg', 4, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2020-12-04 01:33:07'),
(48, 'hdfhdfghdfg', 'dfghdfghdfgh', 4, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2020-12-04 01:33:22'),
(49, 'dfghdgfhdgfhfdgh', 'dhdfghdfgh', 4, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2020-12-04 01:33:28'),
(50, 'dfghhdfgh', 'dghdfgh', 4, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2020-12-04 01:33:33'),
(51, 'dfgdfghf', 'dfghfgdhdfh', 4, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 2, '2020-12-04 01:33:51'),
(52, 'Error en un aplicativo Ensurance', 'Detallo toda la descripción del error', 2, 1, 1, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 1, '2021-01-20 16:20:10'),
(53, 'Error en teclado ', 'Descripción para analista', 1, 1, 3, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '', 1, 6, '2021-01-21 22:51:52');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ticket_archivos`
--

DROP TABLE IF EXISTS `ticket_archivos`;
CREATE TABLE `ticket_archivos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `contenido` blob DEFAULT NULL,
  `extension` varchar(80) NOT NULL,
  `tamano` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `user_id` char(36) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `ticket_archivos`
--

INSERT INTO `ticket_archivos` (`id`, `nombre`, `contenido`, `extension`, `tamano`, `ticket_id`, `user_id`, `fecha_creacion`) VALUES
(1, 'CERTIFICADO ANGEL Y DAISY YANEZ.cleaned.pdf', 0x255044462d312e360d25e2e3cfd30d0a312030206f626a0d0a3c3c2f4372656174696f6e4461746528443a32303230313131323137323131332d303527303027292f4d6f644461746528443a32303230313131323137323535312d303527303027292f50726f6475636572284550534f4e205363616e29203e3e20656e646f626a0d0a332030206f626a0d0a3c3c2f4c656e67746820333237382f537562747970652f584d4c2f547970652f4d657461646174613e3e73747265616d0d0a3c3f787061636b657420626567696e3d22efbbbf222069643d2257354d304d7043656869487a7265537a4e54637a6b633964223f3e0a3c783a786d706d65746120786d6c6e733a783d2261646f62653a6e733a6d6574612f2220783a786d70746b3d2241646f626520584d5020436f726520342e322e312d633034312035322e3334323939362c20323030382f30352f30372d32303a34383a30302020202020202020223e0a2020203c7264663a52444620786d6c6e733a7264663d22687474703a2f2f7777772e77332e6f72672f313939392f30322f32322d7264662d73796e7461782d6e7323223e0a2020202020203c7264663a4465736372697074696f6e207264663a61626f75743d22220a202020202020202020202020786d6c6e733a7064663d22687474703a2f2f6e732e61646f62652e636f6d2f7064662f312e332f223e0a2020202020202020203c7064663a50726f64756365723e4550534f4e205363616e3c2f7064663a50726f64756365723e0a2020202020203c2f7264663a4465736372697074696f6e3e0a2020202020203c7264663a4465736372697074696f6e207264663a61626f75743d22220a202020202020202020202020786d6c6e733a786d703d22687474703a2f2f6e732e61646f62652e636f6d2f7861702f312e302f223e0a2020202020202020203c786d703a4d6f64696679446174653e323032302d31312d31325431373a32353a35312d30353a30303c2f786d703a4d6f64696679446174653e0a2020202020202020203c786d703a437265617465446174653e323032302d31312d31325431373a32313a31332d30353a30303c2f786d703a437265617465446174653e0a2020202020202020203c786d703a4d65746164617461446174653e323032302d31312d31325431373a32353a35312d30353a30303c2f786d703a4d65746164617461446174653e0a2020202020203c2f7264663a4465736372697074696f6e3e0a2020202020203c7264663a4465736372697074696f6e207264663a61626f75743d22220a202020202020202020202020786d6c6e733a64633d22687474703a2f2f7075726c2e6f72672f64632f656c656d656e74732f312e312f223e0a2020202020202020203c64633a666f726d61743e6170706c69636174696f6e2f7064663c2f64633a666f726d61743e0a2020202020203c2f7264663a4465736372697074696f6e3e0a2020202020203c7264663a4465736372697074696f6e207264663a61626f75743d22220a202020202020202020202020786d6c6e733a786d704d4d3d22687474703a2f2f6e732e61646f62652e636f6d2f7861702f312e302f6d6d2f223e0a2020202020202020203c786d704d4d3a446f63756d656e7449443e757569643a38333465353638312d386135302d343135322d626464652d3530633432663238386361613c2f786d704d4d3a446f63756d656e7449443e0a2020202020202020203c786d704d4d3a496e7374616e636549443e757569643a35366231616439632d313864652d343338322d613134392d6131643263333935636539613c2f786d704d4d3a496e7374616e636549443e0a2020202020203c2f7264663a4465736372697074696f6e3e0a2020203c2f7264663a5244463e0a3c2f783a786d706d6574613e0a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020200a2020202020202020202020202020202020202020202020202020200a3c3f787061636b657420656e643d2277223f3e0d0a656e6473747265616d0d656e646f626a0d0a322030206f626a0d0a3c3c2f4d657461646174612033203020520d0a2f50616765732034203020520d0a2f547970652f436174616c6f673e3e0d656e646f626a0d0a382030206f626a0d0a3c3c2f42697473506572436f6d706f6e656e7420382f436f6c6f7253706163652f4465766963655247422f46696c7465722f4443544465636f64652f48656967687420333530392f496e746572706f6c61746520747275652f4c656e677468203430383132332f537562747970652f496d6167652f547970652f584f626a6563742f576964746820323438313e3e73747265616d0d0affd8ffe000104a46494600010201012c012c0000ffdb008400100b0c0e0c0a100e0d0e1211101318281a181616183123251d283a333d3c3933383740485c4e404457453738506d51575f626768673e4d71797064785c656763011112121815182f1a1a2f634238426363636363636363636363636363636363636363636363636363636363636363636363636363636363636363636363636363ffc401a20000010501010101010100000000000000000102030405060708090a0b100002010303020403050504040000017d01020300041105122131410613516107227114328191a1082342b1c11552d1f02433627282090a161718191a25262728292a3435363738393a434445464748494a535455565758595a636465666768696a737475767778797a838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae1e2e3e4e5e6e7e8e9eaf1f2f3f4f5f6f7f8f9fa0100030101010101010101010000000000000102030405060708090a0b1100020102040403040705040400010277000102031104052131061241510761711322328108144291a1b1c109233352f0156272d10a162434e125f11718191a262728292a35363738393a434445464748494a535455565758595a636465666768696a737475767778797a82838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7f8f9faffc00011080db509b103011100021101031101ffda000c03010002110311003f00f40a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a004a005a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a00a12dd5c25e88c5a4ad1160bbc631f5ff003e94ad21e85fa620a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a00648582fc8bba8004c941b860f7a007d0014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050065a6abbb5c7b0da3684c86f7ac954bcec5f2fbb7352b5202800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a00280393bed06fe1d64dee9ae312be7aff00abcf5fa8cff3ac674f5e646919f73aa1d2b6331d40050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050034e78c7e3400ea002800a002800a002800a002800a006f3bbda801d40050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014010fef7ed1d47978a2dd409a800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a004a005a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a006a90ca194e41e845003a800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a0028013ad002d0014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400d550a30a001ed400ea002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002801a68001ee73400ea002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002801a73d80a01f90ea002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a004a0028016800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002802387ccf253ce0a24c7cdb0f19a0092800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a008276b8057c88d1877dcd8a02e4a3a7a5003a800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002801b400ea002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a00649bb61d9c350028e9400ea002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a0028022dd279fb7cbfdde3ef86eff4a0096800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a006f39f6a0075001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140094005002d001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050065ea9addb69cbd77c99c6d150e68eaa385954f439c93c597c7e6436ea338fb87fc6a399bd8f4965d05b8e87c5d788374d12483a7cbde8e6770965d4dfc26ee97afdb5fed56fdccc73f29ff001adaf73cfaf839d234e69a3b788c92b6d41d4d26ec72c62e6ec8e56f7c63fbdc5920f2f9f99d7ef7b8a86d9ead1cbbad4282f89b53d8375cfcc17fe790e7dea7999d1fd9f48d3b0f172eec5e0fddff00cf41d6b4bf5673d5cbbac0e960b88ae63f32091644f55354795384a0ed226a090a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a0028032f5cd4d34db5fbc04aff73359cd9d585a3ed65aec716239b55b918ded21ee6a2317b1ee5e34a3736ed7c1d9506ea7ff0080a8ad23138aa667fca8964f0908e23e44e58e78de28e4338e62dbf7ce71e0b9d3ae32d9888f5acddcf514a35512df6a9757430ecc548036e692f78c69e1e11d8b1a7f872eefd32ffb91fdfad7d96a4d7c5429e86b7fc2190795cdcc9e77f7c0fe95765d0e1798be6d1195aa787af6d794c3c1eabfe15938db63b6963a131da0eb1fd9f205b87251f0bfeed25716330fed2373b9560ea194e54f20d6c7803a800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a00e1bc513c92eacc9b46130a1b158bdcf6f07654cd5f0842c2de59245e4b70dc56915a1cb8e96c8e92a8f38280286a9a747a85bec6fbdd8d06f42bba4ce7344d026373bef15879671f30ebf4a950b1e9d7c5c543dc3b050146074aa3c5dc7500348c8c1a00f35d42d845a8dcc68c7cbde73cfddac2fad8fa8a5372a773b7f0dced71a25bb3f5036f4c56e7cfe297ef19ab41ce140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001401c4789ad8c7ab348eff0024801502b399ece0dfeecd3f08cbfb99adfd0ee049cd381863e1aa91d2559e68500140050014005003598229663851c9340257d11e73a8bacda95c18b6aa1738c1c86ae77dcfa5a5092a766769e1e8bc9d222e7ef735d0bccf1316ef54d4a0e50a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a00c4f13599b8b41320cbc7c74cf151357476e0ea72cb959c9699a81d2eefce58f3fc3b73d6a2dd4f5eb52f690b1e8369731dddbacf09ca356c7cf4e0e0f9593d0405001400500140183e24d4bc9b636f6ec3cc3c3f1d0567292dae77e130fccf999cb58dab5dea3140c2475273f2d1057d4f52b4d5386e7a22208d15146028c0ad0f9d6eeeec7d020a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a004eb401c7f88b454b77fb5448e558f3b5738a4d763d9c262b9bdd667e95aec9a791b9d8c63fe595629ea75e230caaadb53b7b1be82fe012dbb861df9e95b9e055a52a4ed22d50641400500626b5aea58e62830f3f7e7eed672958eec2e17daeaf6392db3dedceef9e4797d054c6f23d9bc69af23b6d2b4b8f4f4c8cef61cd6db1e0d7aeea9a541cc140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400da007500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500348c8c1a00e435ef0d856fb45b6707ef0152cf6b0b8ce6f76467e9faacfa55ce1d9b6f75c715944eaab8755d1d9e9ba9c1a8c598dd7cc1f7d41e86b652b9e0d5a32a5b97090064f029989ce6b3e2151fb8b199779ff96839aca72ec7ab85c0b7ef4d1cf5a5b4da95ee7cc32cb9e4d2b687a3294694753b4d274a4d3e2e4ef97bb56cb43c2af88757d0d2a0e60a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a004eb401ccebfe1e5995a6b55e7f8854b89eae1319f66672b0cf7760e3cb91addb350d1ea548c6aab1a37fe22be9d235f336af7da3efd2bb673c3074e2ee8ab67a6dc6a739f295993d4d5c61746b56baa4b53bbd374c834f8555146f03ef55eda1e056af2aa5fa0c02800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a004a0028031f58d0a2d4118c67cb971d71c51bee76e1f192a5a331f4ff000ace653f6dc2c6381b5ab3503b6b63a9dbf767576f0476d108e25daa2b43c79cdcddd92138eb4137b0b400b40050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500319820cb544ea469abc8695cab2df00a7cb193db35c3531d15a44da345911bd93dab9a78baaf634f62884dc4addc8e6b9e5526d6e69ece244ef2f04390dec6a3dacbb9694477daae004d8d9f5078e2b5a78a9ade447b34581a838232015aea8e3a5d4cfd822dc57692fa8fad76d3c4c26612a6d0dbdb77ba836c570f09ce729deba474a6a0fde57388d49353b6965497cd7fe16723018564d58f7a87b19fc2538af6f576bc571223e7e623bfd7d6a5c9eccdbd852dac5bb6f115fc0e713ef079fde7cdcd5abf430960297635a0f186c216f2d1ba72d1734739c5532eb6cce82d353b3bd38b79d59f6eed9df1f4abe6479f3a3386e8b94cc82800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a004a00af3dd2c5c7f157157c528688d214f98cc964f364c9196ec7d2bc8756523b631e5278ec9e4e4f02b78612733375922ca58a01f3126bd0860a0b731759937d9e1e3f7638adfeaf4fb1973b186dadd14ee181eacd52f0f4bb14a73e821b281b240fd6a1e0e93561aab24577d3ceef95be5c572d4cbfac59b2c4158c6f080594835c2e12a5d0db994b61f05dc918e3e6e7a1ade862e502274932fc91dbdf45b240b2afa57b509a9aba39a329d277452ff0084734bff009f7ffc78d569d8e8fafd7ee55b8f0a59ba11033444fe34ac691cc6a7da312fbc317b6ae658499e30bdbef54fb3476d2c6d39d93d0ca5f36d1b6c876bf5e7ad46c776923a1d17c50fbdd2ff007327de12ff0077fd9f7ffebd5731e4e2303afb875714a9346248db72b7435a1e535624a041400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050054bbb9f2be55fbc6bcdc563143dc46d4a9f319e8ad3cc3e56f9bbfa579b4e94eacb43adb50469c5691a6095cb0ef5ed52c2c22b54714aa364f5d4662d00453cf1db42d2ccdb517bd05462e4ec8e17c47ad8d4311c5cc6ad95ae76dc8f7b0986f65ef751de1ed3af2eb0f14b2c08083bb71c37e15a429f562c5d5a70d19dcc4ac918567de7d6b43c162ba2c830e334a5152566228dc5871fbaaf2abe0acaf03a615fb95a1b8781f6f6ae4a15dd291bca9a9ab9ab14ab32e56bdda551548f3238251e525ad0414019fa8e936da8478906d6fef0a2c8e9a3899d17a1c76b5a1c9a701e5ee318ef59721ede1b12aaa26d1f5a934dd911f9a0ef9ec2852d7533c46163555d6e76d6f3c7730acd11ca30c8ad4f0251717664b4082800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a00ad753f92063ad7162b15ecb45b9ad387314228e4b9933d3debcda549d7773aa525046a4512c4b85af6a9d254d68714a5cc495a921400d6608a598e00a3604ae705afebb25f4be546bb611d39fbc3d6a19f4383c3aa4aef726d1fc37f6d512cccd1afb5108f59138ac6fb3d227690c29046238976a8ab3c2949c9dd92d048500250053b9b40c4cabf7ab831186fb7137a757a14a0b86849eff00ecd79b87aee99d338291aeadb9722bde84d4d732381ab0fab10500472c493465245ca9a071938bba388d7b4292cd9e68ff00e3d979eb51c87bf86c67b4d1ee4de18d6a1b18c5bdd3e04afc1ce704d11b9863f0f7fde1da559e30b400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400d270335339a82e66063c8de6c85bd4d7cfc9f3cae7a0972a34ad62f2e3fad7b586a7c9038ea4aecb15d066140050061f8a2f5adec0c31eddd2ff007ba62b394ba1dd82a3cf2bb395d36cdef6ee38123e1ba9c7cab452d59ebd5aaa8c4f418214b781228c00aa30315a1f3929733b92d0489d293928eac06ac88cc42b648a98d484be163b0fab1094019d7b6fb49751c1af1b174b925cc8eba53e8c34f93f7850d5e0aa6b662ad1d2e6957ac728500140115c4097303c320cab8c505464e2ee8e0354b43a6dfba15e0b70ded50cfa3a153db46e75be1cbefb669f8672f247c3138e6aee8f171747d9ccd7a0e40a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002802a6a0d882b831d2f76c6d417bc52b28f7c8bed5e7e129ca533a6acac8d7af7ce016800a004a00e0b5dbe375a8cb900c5f763c1aceccf7f0b4f921637fc2fa779109ba9500964e9839e2b48e91b1c18eadcf2e537e83cf0a00a9a87fa8c80739ed5c38efe19b51f88ab63cdc0fe2e3ae2b8b05fc4d0deb7c26ad7b6710500472a79898acab53f690e52a2ec6461924c13ce7aad785f04ceedd1b08dbd037ad7d0465ccae703561f5420a00280398f18596f8e3bb5ea9f29e2a27e47ab9754d790c9f0b5d3c1a922e7092fcac0d2523a71b4d3a773bdad0f042800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a00ccd458f98057898d9dea1d743626d39711679e6bb7051f76e675fe22ed7718050014011cce2285dcff0008cd0545733b1e6d12cb7850cb93cf29c0cfe55942377647d0cbdd47a45bc6b0dbc71a8c2aae056acf9d96e4949bb6ac447e7c59c798bf9d63f59a5fcc57248af77346d090ae09ae3c5d784a3eeb35a51772ad9604ea4f15cf849284eecdeb6b134bcf88e31229cf1d6bd6f6d4fb9c7c921caeadf7581ab8ce32d856687d508c9bd43f69fbbc75cfad78989a6a350eda32f74b760d9876f3f2d7a18495e061596a5baeb310a002802b5fc3e7d94b1e01caf7a4cd68cf92699e6b0cdb6e97787ca9edd73596da9f4f2d8f4cb49bed16b14d8237a83835b1f2b3567627a090a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002801280316e4feff8e79af9caf2fde1e853f84d2b1c7d957d7bf4af7a8ff0d1c757e22cd6a66140050067eb92797a45c1c67e5a991d38457ac8e4b404ff00899c081c1c9cf5e6a60df31eb62f95533bdad0f008e604c2c075c76aceaa6e0d22a3b991f6694f1b5ff2af11e126fa1dded2223432a0cb8fceb274ea53f786a717b0c54776f97ad6308ce6f42db4897ecf3ff70f5ae9785a9d8cbda44bda7ac8223e68c73c57a78284a31f78e7acd5f42e5771814352fe1af2731dd33a68069efd579abcbdee82b97ebd33982800a004a00f38d561d9a84cbfbbe1cfcbb6b0e547d1d1f8158edb4073268f6e59b271835b9e26295aab34a839c2800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a004a00c69ffe3e1bfc6be76a7b923d087c26a5bffa85af7683bd34714fe226ad480a0028033b5e07fb227c7619a991d584fe32398f0f29fed78f9e47f0d4c4f4f17fc23b8ad0f082800a00ad7bfea6b8f19f01ad2f88a763febc62b8705fc43a2b7c26ad7b471050014014752ff56bc579b8fe87461f719a6fde6fa54602dcccaae68d7aa728500140050079eeb9b5b53b9fde20f98e71582d0fa5c369491d6f86bfe4076fd3a76adcf0f17fc566ad07305001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400c72c3eeae7f1a0055391c8c7b5000181623b8a0075001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014018f7ab8b96cb75af9fc5a7ed8efa4fdd342cce60fbdbb1eb5ec61a57a672545ef162ba0cc2800a00a5ab45e769b3a0ebb78a99fc26d8776a88e3348dcbaa43b9ce43f3b39c5427cacf6f111bd367a056a7cf050014015350ff008f7ebdeb8f19f01b50f88a7a7f13d7160afce6f5fe135ebd93882800a00cfd4bf838af2b1fb9d5870d3b6ef7c11bb0322b4c0c7a935df4342bd139c2800a0064922c51b492305451924f61401e73a86e9f51b891c8c3375ac39ada1f534a368a48ee74218d1ad7eefdcfe1e95b25647cee21a755d8d0a66014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500370339a0075001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014019ba8afcc0d7918e8da475d063f4f93e5d86b4c04adeeb26baea5faf4ce60a002801ac32a45008f39f2fc97db1ed1cf1c7ddac3667d3e9247a058ce2eaca19d7a3a035b9f37523cb2b1628202802a6a1ff001efc8cf35c38ef80da87c454b123cf1fa719ae4c07c66f5be135abd9388280128032af1c3cdc0e457cfd6a9ed2a5ceda4ac8bb67198e2e4f5af630d0e581cf5657659ae8320a0028029ea974b69632484807185cfad4cf637c3d3f6951238545fb4ca14372cc1413f31ac63bec7d0bf7227a143188a148d7a28c574bd4f976494802800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a006f7eb400ea002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002802bdd442487938c735cd89a1eda3a1709f23b99d09f2650cdc81e95e5d1b4268ec9fbc8d7072335eea7738075001400500713e22b436da8bb050125f9d4fbf7a89a3dec1cfda532ef84f504dcf66f28ddf79509a21d8e6c7d1fb68ea6acf282802b5ea3490e1477ed5cd8a873c0d693b321b5b79227ce07bd72e12838cef234a93522fd7a67305004370fe5c479c678158d79f240a8abb32e35cce17debc6a71e69d8ee6fdd3614051815ef256d0f3f71d4c02800a00e47c677d1f9d0d91c1e37b0c527cdba3d6cbe9a7ab20f09da09af4ccc9f2c6377deeff4a1236cc26e30b1dad33c30a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002801280326ea1789bef123b1af07174792477539a9166c27ca9491be6edf4aecc157bae56615a3a97abd2300a002803335db1fb6d890a06f5e45291d585a9c93d4e2ecaea4b2b81202a0a7f7874fc2b9f667b9382a90b1dee9d7897f651dc4654ee1d8d74a3e76ad3f672b16a8330a002800a004a4da5ab032af6e7cc6c2745af0f138af68ed13b6953b6e4f6309e5e40bfecd7560a93f8999d697445faf4ce60a0028029ea57f169f6a6694fd3de836a145d59591c14937db251717129fbddfaf35cedb67d159528596877da75a8b3b348f6a86c7cf8ee6b78ab1f395aa73c8b74cc82800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a0028021b88bce4db922b1af4fda46c5425caccaf9a194835e1fbf4a477e9246a4170932f079f4af670f88555799c3383893d749014009401c6f8a347292acf0826263c8c6706a251ec7b783c4f32e5914744d61f4dbad85b7424e2a6ece8c55055a37ea77369750de402681b72d68a573e7ea5374dd99629901400d3c75a00a37b75c18d3f135e5e2f13f62274d1a7d590dadb995b71e95c787c3fb495cd2a54e5350715efc55958e21d4c02802adedfdb58c7bee2554f404f5a0d29d29547a1c46a7ab4bab4a460f95d85433e82861d5046ef85f4b1147f6995087e8b9f4a2079d8ec45fdc4749567981400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140104f00987bd73d7a0aa22e13e533087824e9c8ef5e2352a323b749a2ec37cbb3f79c57a34b1bd2673ca8be85959637fbae09c66bd14efb1ce494c06901860f4a00e4b5ef0f3eff00b45a7dceac2a26b43dac2e36fee4ccab0d5ee2c0e20ceecfcc185668ecab878d5f88eb34af105aea083e6f2e4f4356aa2ea78b5b073a7b1af5a1c655b9fb41e13a7b579f88fac3d226b0e5ea5586d2591b2c368cf39ae3a584a929fbc6f2aa96c69aa851815ed420a0ac8e36ee3aa8063bac6bb9d82a8ee681a57306efc5766a31667cff00f6874a9723ba860a55357b1c8dcdedc6a375bd98b31e296e7b71842947dd3a1f0e787f1fe9376a7af00d1ca79b8bc67d981d60181815678e3a800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a0028022961497ef56556946a2b32a327133e5b3743c72b5e4d4c24e075c6aa6408f246fb876ae78d59d37a1a34996a2be393bf95ed5dd0c6bea612a1d89bede9b7247e55aff006843a91ec192457514c768fd6b7a58aa75762254e5131b59f0dc77a7cdb6da927bf7adf94eda18e70d2472977a55d59bfcf1eee7baf4a857ea7b11ab0a8ae98fd3752bbb2388666518e57fcf14aeccea61e9cfa1ab67e309a2fdddda79d8fe31c135576724b2d8fd9668af8bed0ae7c894fae314f9cc1e5b3ee0be2eb59378589d580e379c668e727fb3a65097c6176ebfe8f6888deac77536ce98e5b1eaccabdd52eef3f76d3bc81ff84d66e4ced8d0a74f58a1967a35f5e11e5c24e0f53c62809e2a11f899d8e99a05bdac31fda1239a54e7257a56b1d11e2e2316ea3f77636299c42d00140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500250042f6d13e7e5c13dc5734f094a57d0d154922bb5871f2b5714b2fec69edc80d8cdc700fe35cff51abd4d7db4416d6e11fe55e28586acbec8fda41976d44caa44debc1ce6bd5c3fb54bdf396a72fd92592249576c88187bd74931938ec62ddf85ed666dd0c8f0f39c7506a7911dd0cc6aaf88c59fc1b768ff00b896371cf538a9e4b9d94f31a76d4abff08ceaaae36c00fd5a97b3ba379636935b87fc231aab5c37ee78ecc5b14e309585f5ea45cb6f085df99fbd996351d36b66a7924632cca1d0dab3f0cd9dbb6e7ccbc746e95a5bb9c75330a92db43680c74aa3cf1d400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014015ef6f20b0b66b8b97d91af5340d2b95f4dd5ed354dff00652ff2007e68caf073cf3f43408d0a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a00280296a7a95ae976a6e2ee4d89d3eb4058e46ebc773998fd92d9022b15c3fcc5bdf238a7cac158d4d27c67657ade5cffb97f5cf07fc294bdddc7e874a0e464502303c4fafcda3b5ba411c64cb9cb49d071fe38a2cdec1a14ee3c73691db446185a6b875e57a2a1f73f9fe54580857c76be62ab5af076e4e7a7afe14b5ea1cd13a1d1f5ab5d620df01db275685c8debf85098dab1a54c4616b3e2bd3b48631bb19a61d638b92285aec3313fe16241e61ff00436f2c77cf26ae34e56e661eeec74ba3eb969ac45baddb6bf78db1b96b3b886ebfac7f63daacbe57985d82fb0fad55ae1a751be1dd67fb6ed249fc9f2b6bedc67da959adc6cd7a047397be294b4d63ec1f673f7c216271d7b8f6a3a0f964745408cad63c4161a3e05cb932119d88326819807e20c3bf8b097cac724919cd1cb311bba2f88ac759f9607d930ff964fd7eb459adc76362811ce6a1e2c834fd4becb345f2f77ddd3b67e94b52f9741977e35d3a107ece1e738e3b29fc68b8e30bc6f729d978f6096e4c5776ad08fef29dd4d5c968eb609a3b8856585c3c6c32181a49dc938ff14788c486eb498ed3705f964793a53f796a064f87fc42ba3a4fb6069d9f193bfae38a76624add0ed740d5ceb16cf2b5bf91b1b6e376690c87c41e214d124b657877acadf33eec6c1fd681a2bbf8cb4f8ec52e19652eca1bcb51ebefd295c2c6ae95a947aa5b34d1a326d72855ba82298ae3756d66cb47843ddc982fc220ead40ec739278fd77fee74f25738fde4bb7f90355c83e536349f1458ea73fd9fe7827fee49dea2f6dc5636e9885a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a004a00f35d759b5cf11080b32e7e550c7000ce3f53fd28a6fa85476d8ece1d0b494b7581eda09360c9dc33fe7a53f6f6d2e2b1ce78a7c33676b6ed7964be59dd9214f7a154831a5ca8d1f036ab25f5a4f04ccccf030eab8ed480cbf8909ba6b32a46e0a7838f51fe78aa49bd857d4b9e12f0cda1d2e1bbbc89666946f01874aabf2ec54b57735b53f0e69f7367208eda38df66032af41537bbbb125638bf076a1f63d76381994a3feec337057da9592d096d9ddf88b51feccd265986379f950671cd08af3388f0b683fdaf297b9d9e4c470e31839f7ad24d740d0ece4f0c68f240d11b24c3753dff3a9f68c56463587829ed3575b9fb57eee33f27187eddc7e3f852d02c58f1f60e9b6e1958af9bce3b719a9189f0f883a4dc050302e0f6f614303aba00f3bf1093278abcb9953c9f3172ee38d9c647e78fceaa0b503bd9e65b7b4799885545cf34add00f35d22ddbc4bac4ad772425f765ca6013e94d596a173b5b7f0ae9705b240d0f9bb39dd273cd3e76b6158e53c41a68f0edf4575644a866e76f5fa7f3a972e6d06fc8eeb49bcfb7e9b05cedda5d791ef480f32f1445e6f89ee4461896947dd5f614e5b5ca5b9d8e8fe12b1fb24525f42249b3bf9a6a4d126678bbc276d0dacda85996461cb2f5aae76f4296a49f0e2f5a48ee6d8b65570c3dbd6b37a3b3211a5e2cd3eda3d26e6ea3548a638cc98aa4f5f78a31bc13a5da5f5a4eb7319723af3f77daa9cf67626fef1db5a595bd8a14b68963079381d4d437719c8fc4042f71678e9b581f933faf6a6bb8d15fc2be188ee6dfcdba3be0fee1aa7a6a45dbd0eca1b7b4d1f4e2b6f188a089738a8dca3818bcff126b262b82cdf312bbb6fcab9f6aad86fc8ed21f0e6991c1e535ac727393b877a9beb712d0e67c59a443a3dbfdaac97e779323e6e86abe3d00d8f036a8da8e8a16679249a03b4b3f7a524074b5201400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050034f231401e457768b06b9f67ba0d6d6ab31c0ef8cd6dd01ae53b0ff8416c665dff006c9db77cd92149fceb34d2d2c3726c961f04db408c82f25d8c30c3620e99c76f7a9b47b08d1d13c3f068d24af14d2c86418f9ff845306ee73ff10bfe3e2c972cbf2b1c8f4ef48ad2d66755a2851a3598472ebe4ae18f7e2825171fee1fa5008f35d2654ff84940b764b55f3b90cc33f7be61ef9c0e3b5683926757e3681e6d170ad81bc6efa5662e8cccf87b7b179735a32f973b317c7f7b18a6c5ea76b486442784cc6112a79abd533c8a00e63e21216d2216f27cd0b373fecfbd05446fc3d947f674f073b83efe7dfdbf0a6c93ada4079a6ab751cbe2a66b792425ae57eec83d97a74eddff00faf5a5a233bad69267d1a55b75467dbd24191f9567b82679a787ac1751bb68bed72db097e5f9063355f16ac5ccae75727826e64742daccadb061770f997f1a72e492b341aad3a049e06697224d52474e70acbedc1eb4bdddc1b6d9d2e97a7c7a5d8a5ac3f7173520cf35f102c717896e2285067cedf8fbdb9dbebf5aa5a32bde4b43d557ee8a924c9f15c493787ae924c60af1938e7b55455de8072bf0ea20ba95c17de6458f001fe1ff003c5372070ea74be32f2bfe11bbaf38baa71ca2e48e6a35e834ae64fc3d68bcbbc58e4dcdb8165f9b23fcfb55bdae2f23b3a80388f1fbdcacd69e40f9369dd9a340377c23ff0022f5b64b1ebcb36ecfe34dbb89177578da6d2aea34c6e319c6695ae3bb5b1c1f82ee6083c41b5dfc9dc8dc3cb9c938c7d4d57d9b033d22a40e73c733f93a1e06fcbb800ad34afb85ccff0087c242b76e77f97f28e58633f4edda9c98dab1da54882800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a00897cdf39f711e5ff08c5004b4005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500737e28f0e7f6a7fa4db63ed4ab8196c03f5fd69efa0d1ccdb6a9e23d264304858a236cc4b1f5fa554e1a682a764399bc41addd469e75ce09c9da3cb551428388f9a3d4efb4f4b88ec614bb6569c2fce57d6a094725e3c87cebdb31e4dc1c0fbebf7319e41ff3f9d524cb4d773a8d111e3d16c965ddbc42bbb775e94990b62eb7dd348679bd87da67f10452b2c986b85deb24478e9e9d3b7e5cd5c5b0936bdd3d167863b881e19543238c106a0168703aae83aae957935ed9cac50216565ea0e7a63e957ba072d4645e24d776794c5e47cf5c05fe1fa7af34726a1cd726f0e68ba95fde1bebe799033eedfe63293f41fe78a5b6e1d6e8ecf56b2fb7e9f25b86d8e47c8de86a40f398db58d02ea65225563d24dbb87d6b59c2fac06dd8b326bfe20d43f729bf7b701628700fd6a231bbf215fb99b6da75cda6bf6a2ed3e6f343317cf3cf7c77fd2b46b40f367ad101d707a1ac40e035ef0eddd8dea5d69e24619c9607a56bf121fb89dc65a78af5a86dc0910cbb7bb45cfd7ffad593df429b812d95f6bfa96b114c15c296e554fcab1e7f2cd528f2ee45d33bea903cbf5a676f134fe5befdb37ca4e4fcdc715a24bb0e5ef23d393ee0cfa566233bc468f2e837891637326397dbfad0546f7d0e63c04f8d4aee362c494dd8da7039fe7fe147258523b1d4ad7edb613db671e62119a0479e5addea5e1f96558adca36701082467fc2b4e4490d799d3f86b5ebcbfba6b6be450fb372b2a15cfaff4a8e57b89b5b22978f63ba636ef1806145627fdeedfd69fd90373c2c9b3c3d683e7fbbfc6db8d4891ad40ce07c43e1bbbb6d49b51b0dee99c900ee23fcf15a2b30b115a78975ab38b64a6293da45208acdc65b0db8ef61a21d63c5573e4ddee484479e46155b1fafad3e4e41dd389dd699642c2c62b7cee2a3e66f53449dd90958b948614005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050034702801d40050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400d6556fbc01fad0018c74a00750034807a8cd002d002d0033628390a2801f40094011fd9e1ce7ca4cffbb45c09280168018d1a3fdf50df514008b1227dc455fa0a0061b5b7371f68304666c6df336fcd8fad3bb026a4014010bdadbc9f7e08dbbf2b4eec0915550615401ed4807d00406d2dccfe71823f37fbfb79a77604f4806919183400d48a34fb88abf4145c09280229208a6ff5b1a3ff00bc29a760b5c72aaafdd503e948064f6f0dca6c9e24957d1d734d49c7601e88b1a048d42a8e8076a403e8012802136b6e5f79823dd8c676d004a005e831400ea002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a0028039fd4bc5967a7de0b6f26795bf88a0e1451d457bec6ddbcf1dcc11cf0b6e8e45dca68192d00140050014005001400500140050014005001400500140050054d4750b7d32d1ae6edf6463da802ae91af5a6ae5d6df7064ea186281d8d5a04140050014010dc5cc369099ae6548a31d59ce050032caf6dafe1f3ad2512c79c6450059a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002801280392b1f11ddcbe25fb0cbb82995d4a14e981f2e3f004fe3428bf88763aea0414005001401ca6a5e0c86f3521731ca22432798e36f24f19fe55ac66ba81d25a5ba5a5ac56f1711c4bb56b27a813d00140050014005001400500140050014005001400500140050067eb3a5c5abd8fd9a6c8f9832b0ec45080cdf0f78613479bcf794cb3ecdb9ad2525b205b1d15660140050014018fe2b1ff14e5e1dbbb6aee1cf439eb45ec066f80994e9d36c0ca85f72a124ec1e9cd54afd434e87555201400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050034f00d007995af882f2df5792512797bb23c939600ff9fa527e4174cb6d67e24d458dc79b361dcb6df319323dbb7f9e6b6f744e3a5c8acf5ad6342b88e1b83248863c98e6ec7d3359d90cb3a878a354d51cc7a4c4d1c3b79c7df27fc29c17702a5dc5e22b27fb4b7da0f1bf72dc375fa7f4c50bb0d5f7b1d2785fc50bab49f65954acfb7754a525f108e86e6478ada59228fcc7552553fbd401e7d2ea5e28d5ee1edd37c414618469b57fefaab505cc09c97412ea2f1269b189166b9554e72cf9e4ff00f5a972c4376751e1cf10ff006a1fb3ce3170177f03822a419178be1d4ee22822d3c49b58fccd1b1057ff00ad4d4530e6b1c6017d25ff0092b9fb503d7352a09752799b6749e18b4d760d481be2ed00c8fde4cc4fe1ff00d7aaf6765b97a1a3e33bf96cf4e410f98be613974cfc9c70723df14acba8afae872f67e29bf6d38d959bccf3ff0004c7e76fd68e41a3abf0aff69b452c9a8caccad8d8a5718f5ebcd3692d856b1cef89352bf8f5e9228e5b84fdf20428480a9c67be0f7ea28e55d44bde763bf8f3e5ae7ae290ce0bc43ae5f69fe2277432ec4608abbcecc63278cfbfe94ede60911af883c43a9c6c625d887a18539143a5706409ae6b7a54db2e6e9962527899779fe7fd6af91204cd3baf1cc924107d8adb12b1fde0fbf8fa7ad66d740b3285d6a5e268d5ee99a68772edfba1871eddbeb551a3dc395dcd8f0af892e2ee7367a86e773cc72ecfd0e2a6c1a3d8ebe8039af10f899b4e63159c1e73ae55d8ff00036011c77eb4e31e7d00e5de6f114db6fa39afc92df723638ffbe7a55f26b6275468d978c6f6ce616fa9db3ca7af0b87ff0003fa566d3dcab1da59ddc37d6cb716cfbe36e8680392f19ebb71a5dfac10cf247be3ddf2ed38a69260569bc59a95f48aba7c320551dbf8f3de972cb724a72eadafe932299e5ba391b9d9d329fe7db8aa8434d0a6757e1af1243acc211881723a80383ef53aa76196bc477325a689733432796e070dc50231fc0d7f75771dc7daa62e59b780cf923e9ed472f2e833775bbc9ec74c967b58bcd940f941f5a0471eda9f89b506df144de5ab748d7b76efd69285f76291546b5e23d3d5652f2ec3cedb94cf3efe95a4e9a5a81dce8fac5aeb16fe65b364af0c318c540c87c50e23f0edeb1207eefbd0bc80c5f87200d32e405c112f3efc0ab92b01d8d400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014009401e67a459493f8a4a35b62059987fba055ee347a5818181502386f88b122bda4a08591bef7206e03f5ef557d2c068f81a04fb14b3f9051f7edc91d7dc54f35c76b1d2ce8b2c0e8e3208a0479af85a546f125abc7105dcc541e5b8c1e33fe7a535703d3a9018d77e22d32c37fdf90affcf18f70cfa67a6684f9865193c57a7de5bb4324132f98bc86c74fcfff00af43d18bc8e5bc3f26ef1845f27dd94ededb47356d69703d42a00f34d1e2f33c6a8cc2343e6312a81b1dfbfd73d7f0aa1267a6548ce3fe22bedd32dbe507f7bdd73da80b5c8fc01656ef6cf7aa43b676918fb86a9b0b72ec76752079778814beb9206dcb75f6be7774dbfc18fd2af9ac1adb43d3a2ff00549f4a803cd7c451f9be317574f95a545fba39e98ad222d8f47b5b68ad6158e245503d2a1bb8cc1f1bd9acfa417f937038cb0a71634737f0f2c04d793cae80ac7820d68dae51fc2cf4665565dac320f6ac493cb359034ff11b797f29866054e768ff00f55696b8687a6dd5c7d9ec25b863b76465c9f4acc0e03c1c8751d6de6ba94bc87e7604afef3dff009553f41dda3d195428c2802a4472de3bb0824d24dc9da8f19fbdb793ed54bd2e041f0f2e9cda4d66edbbcac32fd0d12560d7a997f10e33fdaa8c8509645ceec02bd7fc7f9501a1d8e81a74565a745841bd979349816efede2b9b4912540e31d0d080f3af07acb6be218d1674fbe5248f8e78fe1a24f503b3f17873e1db9f2d0311cf3d87afd692576073bf0dcb79d76adced8d4063f5356ef603bb911258d92550c8dc153d0d42760316e7c4da1e99fbb37280f42b12e71f5c51ef761ee65eb7e23d1afec6485653e60c1e53b5167b5856b99df0fa71fdad728aa8bbd33d7e638a0ae8751e2d778fc3b75246650570498bef633cd344a28f814e34d9616642626dbf2b29e3f0a6e2e3b8743a8a900a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002800a002801a7a1a00f38f09fc9e294098030c0a49f7c7ff005eabdeeff98efa6c7a4d488e37e23c6ada6c0cfd15fd71da9fa0b52f780d0a786e3cbeecbb11c838a1f98ce89bee9a40799e86d10f17db797279fba438959f2df77d8e2af9740f8763b3f174f2dbf87ae5e16d8fc2e79eff004a80399f04d969f757127da44325c28e01ebfcaaeee217b33a9d42df48b281a692d60dc800184e7d054fb460ce0b48d87c551ba9dade78c0effcaaaf27a0fdeec7aa5408f3ab07fb278c259da07086623710abc64e4fd3f5fe5437cbf10e377b1df35e5b27961ae225f34e23cb8f9fe949493d85b1cd7c445ce9107ddc79c3391dbda98ba92f80005d11d063894e78c7f4fa55c877b9d45401e65e2b127fc24d71b4c27eef41b8afd4555d02d0f47b5c0b58b1fdd14981c16b4223e381bb6292c806480d9eb9e9d3b60fad3b3634d1e823a5488c6f177987c3b72220849c03bfa633cfe945d2dc37313e1eeddf7cbb5438c0f7c7bfeb427a05ee76d401e67e2bf3e4f153c7145f74a9181f7a8f3e608dafb1e8d8df6b81dd6803ceb489e0f0ff00895daec1893fd48cff003ab77484acf53d1a19e29e3124522ba9e720d64a49ec3391f19ebf6df647b3b5944b20fbde5b7dc3556e6d02f624f87f64f6f6724c4fcb274f9b229b56066678f5f76b318cb37950e768edfa739c554576057be8777664359c2c0100a0ea3150c0925ff54d9f4a04cf34f0d6dff84a860c41bcd71c630c3fd9aa1c3d4ec3c687fe299baf903e7039a94ae08c5f87bb8c9744ef01401fec1aad3943d49be21dc4a969044bfea797938e1bd07ebfa511571a20f0369fa65d593bca96f2dce4923ae01fe55a4a4e3a08bfe21b7d1b4bd3e4f26d6d96e8afc88b80d59a6e40e76d5989f0f98b6acf8c81b0eecff17a76fafe74e51b06faa3acf16c862f0e5dbabaa9dbfc5531033fc06241a539908f99b200fe1e3a51d076b1d4d21050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400d3c8c500725a5785ee6c3c422eb746d6c9ca9fe2e98edc556961aeecebea446178ab489f57b38a2b7584b2be7f7b9e2aa3ea546dd49bc35a6c9a5e94b6f3040fb89c21e293b6c84cd56fba71484719a2f85f50b2d5e1bcb8f21f6b1c9f3096c7f5357e8c2c8ec27896785a27ced618e2a53b01c35df81eea373f60913cbdbb76972b9faff2abf7451bf52d5af836e5e6596fef59fe5c321f9bf5a5a4761dacac334df0b5f5aeb2b3c8b1f94b2ee0c2539dbf4fca8f3b872c4edea00e4bc4be10fed3ba6bbb464495bef83d1ab45240ca7a5f863588f538ae6e658d02b2e76c8493b7a7e9c7e349aa606b78c747bbd5ed215b3da5d1ba33607d69440b1e17d3ef34db07b7bd2870ff00bbdbfdda24ee06dd481c3ebde1fd56f7c422e2d5446011b6712741feefafff005aae3e611d1dced635d91aafa0a8038ed4bc3ba85cf8abede823f2848ae1f3cedc0057f9d5c4563b3a8199faed9cd7fa4cd6f6fb7cc6e9bfa1a34ea066784f48b8d2fed0278238c6ec2b29e5c7b8ab95815ce92a00e1f5cf0e6a379ac4d2c50c1241236e3b8fb0c7f2e9fe35692dc19daa0db1a83d8540187e21f0ec7a9a19add512effbdfdefad5a6bed0b94e425f08ebb09fdcf3bd72fe5be39f4f7aae483ea5467cbd0d2d13c0b2c53a4d7ef1000e4a2f39a8f7101dbc10476d0ac50a0445e00149bb88e53c59a0ddea7a9412c116f8c0c1cc98fa71570b7524eae05658515ba8159943db953401c3691a0ea96daf2dd4b6bd1b96f3404c64e718ebc63d2b5d14436d8ea3c436f7175a34f159a8698f452719acb7d00caf086917ba6bdcb5dc4b107fba15f356ec901b7aa69b0ea76be44e38ea2a00e225f06ead65bdeca6127cbd158a1cfb569ee86a5987c1f7f379d737d2ab4ce3223f30e33ef53eec7e10b2ea58f08f87f51d2b5591ee638c43b0fce1b96f4aa902d3437fc4769717ba25cdbda2a34cc380ff00e7ad4202bf85acef2cace75be5c3b4c5c65b24e7d7b7e54b95476255fa9b941414005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400500140050014005001400, 'application/pdf', 412543, 31, '9ed5a9ac-f87d-4499-8967-8816b0db646c', '2020-11-23 19:26:27');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos`
--

DROP TABLE IF EXISTS `tipos`;
CREATE TABLE `tipos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tipos`
--

INSERT INTO `tipos` (`id`, `nombre`, `descripcion`, `activo`, `fecha_creacion`) VALUES
(1, 'Incidente', 'Todos los incidentes ', 1, '2020-10-28 20:16:45'),
(2, 'Requerimiento', 'Requerimiento de alguna funcionalidad', 1, '2020-10-28 20:17:21');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` char(36) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `token_expires` datetime DEFAULT NULL,
  `api_token` varchar(255) DEFAULT NULL,
  `activation_date` datetime DEFAULT NULL,
  `secret` varchar(32) DEFAULT NULL,
  `secret_verified` tinyint(1) DEFAULT NULL,
  `tos_date` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `is_superuser` tinyint(1) NOT NULL DEFAULT 0,
  `role` varchar(255) DEFAULT 'user',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `additional_data` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `first_name`, `last_name`, `token`, `token_expires`, `api_token`, `activation_date`, `secret`, `secret_verified`, `tos_date`, `active`, `is_superuser`, `role`, `created`, `modified`, `additional_data`) VALUES
('4759500e-0e79-46b4-b506-bd3e304afd6f', 'bmartinez', 'belen.martinez@hotmail.com', '$2y$10$ex/dBv/k3gjve2QHko4wmeNZIWrNFBGL2rJRJAdCBv9vifeNOVOOy', 'Belén ', 'Martínez', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 'user', '2020-11-26 03:04:30', '2020-11-26 03:04:30', NULL),
('4fd43ed4-d5d0-44a2-a3d2-278ac08cf936', 'fvillota', 'franklin.villota@gmail.com', '$2y$10$e1wG7v107GJyt1bBnwsLruxsSqlfih1qN0DRbwxYSa/sNyBDgov/G', 'Franklin', 'Villota', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 'user', '2020-12-04 00:27:59', '2020-12-04 00:27:59', NULL),
('74e24098-069c-4393-aede-0245475f01ac', 'user', 'user@gmail.com', '$2y$10$7v4shX7hQhZwdEzYgrwGp.4TE/nzWlm1y1of68zAf9QDuZYU2VvSy', 'Juan Carlos', 'Godoy', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 'user', '2020-10-28 20:51:44', '2020-10-28 20:51:44', NULL),
('9ed5a9ac-f87d-4499-8967-8816b0db646c', 'superadmin', 'superadmin@example.com', '$2y$10$MqxUZyOspKB0/flEGLQHw.NtOMmga1oFte839YtOUiRMNG1K7YOQm', 'Diego', 'Estrella', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 'superadmin', '2020-10-25 16:53:05', '2020-10-30 18:32:55', NULL),
('a18c21ee-dc0e-45eb-afb8-93b9d0789d09', 'psantamaria', 'panchosanta_25@gmail.com', '$2y$10$EC1Xx2rSSJDPAZwc4T1nFeHWyftCz4IDwgKgEy6DemzXKUDYQzSO6', 'Francisco', 'Santamaria', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 'user', '2020-11-26 03:03:39', '2020-11-26 03:03:39', NULL),
('df01ed54-4aa7-487e-a563-161f3acd4f66', 'alefran', 'alefran@gmail.com', '$2y$10$tmISR4Te9yYIZbiV9zUJBuaJgK9yNdHTKMARAvLSR6jLc9/AsH8Iu', 'Alejandro', 'Fran', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 'user', '2020-11-26 15:24:17', '2020-11-26 15:24:17', NULL),
('e869c107-8ab1-4b22-b037-5d015f2261ad', 'aarosemena', 'anie22@hotmail.com', '$2y$10$zTnmypQY3e.GZghBitjK0OTHs4Q3NZQ4ykdHXW5949.k1aCWRWM66', 'Angelica', 'Arosemena', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 'user', '2020-11-26 15:23:46', '2020-11-26 15:23:46', NULL),
('f6f53803-812a-402b-bf38-2a55c24a55ae', 'asistente', 'asistente@gmail.com', '$2y$10$cxut7DjeG1ae9ZO2g.rgkOTeQB7d0u5aXMsupgHnWjaOX20T9P8YC', 'Luis', 'Encalada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 'admin', '2020-11-05 16:03:19', '2020-11-05 16:09:11', NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `areas`
--
ALTER TABLE `areas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`),
  ADD KEY `departamento_key` (`departamento_id`);

--
-- Indices de la tabla `cake_d_c_users_phinxlog`
--
ALTER TABLE `cake_d_c_users_phinxlog`
  ADD PRIMARY KEY (`version`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ticket_key` (`ticket_id`),
  ADD KEY `usuario1_key` (`user_id`);

--
-- Indices de la tabla `comentario_archivos`
--
ALTER TABLE `comentario_archivos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comentario_key` (`comentario_id`);

--
-- Indices de la tabla `departamentos`
--
ALTER TABLE `departamentos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`),
  ADD KEY `empresa_key` (`empresa_id`),
  ADD KEY `sucursal_key` (`sucursal_id`);

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `fk_user_idx` (`user_id`),
  ADD KEY `area_key` (`area_id`);

--
-- Indices de la tabla `empresas`
--
ALTER TABLE `empresas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `encuestas`
--
ALTER TABLE `encuestas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`),
  ADD KEY `departamento1_key` (`departamento_id`);

--
-- Indices de la tabla `estados`
--
ALTER TABLE `estados`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `historico_cambios`
--
ALTER TABLE `historico_cambios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ticket1_key` (`ticket_id`),
  ADD KEY `usuario3_key` (`user_id`);

--
-- Indices de la tabla `migrations_phinxlog`
--
ALTER TABLE `migrations_phinxlog`
  ADD PRIMARY KEY (`version`);

--
-- Indices de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`),
  ADD KEY `encuesta_key` (`encuesta_id`);

--
-- Indices de la tabla `prioridads`
--
ALTER TABLE `prioridads`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `proyectos`
--
ALTER TABLE `proyectos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `puntajes`
--
ALTER TABLE `puntajes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pregunta_key` (`pregunta_id`),
  ADD KEY `ticket2_key` (`ticket_id`);

--
-- Indices de la tabla `seguidores`
--
ALTER TABLE `seguidores`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario2_key` (`user_id`),
  ADD KEY `ticket3_key` (`ticket_id`);

--
-- Indices de la tabla `social_accounts`
--
ALTER TABLE `social_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indices de la tabla `subcategorias`
--
ALTER TABLE `subcategorias`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`),
  ADD KEY `categoria_key` (`categoria_id`);

--
-- Indices de la tabla `sucursals`
--
ALTER TABLE `sucursals`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `titulo` (`titulo`),
  ADD KEY `proyecto_key` (`proyecto_id`),
  ADD KEY `estado_key` (`estado_id`),
  ADD KEY `prioridad_key` (`prioridad_id`),
  ADD KEY `usuario_key` (`user_id`),
  ADD KEY `tipo_key` (`tipo_id`),
  ADD KEY `subcategoria_key` (`subcategoria_id`);

--
-- Indices de la tabla `ticket_archivos`
--
ALTER TABLE `ticket_archivos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ticket_key3` (`ticket_id`),
  ADD KEY `usuario4_key` (`user_id`);

--
-- Indices de la tabla `tipos`
--
ALTER TABLE `tipos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `areas`
--
ALTER TABLE `areas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `comentario_archivos`
--
ALTER TABLE `comentario_archivos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `departamentos`
--
ALTER TABLE `departamentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `empleados`
--
ALTER TABLE `empleados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `empresas`
--
ALTER TABLE `empresas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `encuestas`
--
ALTER TABLE `encuestas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `estados`
--
ALTER TABLE `estados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `historico_cambios`
--
ALTER TABLE `historico_cambios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `prioridads`
--
ALTER TABLE `prioridads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `proyectos`
--
ALTER TABLE `proyectos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `puntajes`
--
ALTER TABLE `puntajes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `seguidores`
--
ALTER TABLE `seguidores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `subcategorias`
--
ALTER TABLE `subcategorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `sucursals`
--
ALTER TABLE `sucursals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT de la tabla `ticket_archivos`
--
ALTER TABLE `ticket_archivos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `tipos`
--
ALTER TABLE `tipos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `areas`
--
ALTER TABLE `areas`
  ADD CONSTRAINT `departamento_key` FOREIGN KEY (`departamento_id`) REFERENCES `departamentos` (`id`);

--
-- Filtros para la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD CONSTRAINT `ticket_key` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`),
  ADD CONSTRAINT `usuario1_key` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `comentario_archivos`
--
ALTER TABLE `comentario_archivos`
  ADD CONSTRAINT `comentario_key` FOREIGN KEY (`comentario_id`) REFERENCES `comentarios` (`id`);

--
-- Filtros para la tabla `departamentos`
--
ALTER TABLE `departamentos`
  ADD CONSTRAINT `empresa_key` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`id`),
  ADD CONSTRAINT `sucursal_key` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursals` (`id`);

--
-- Filtros para la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD CONSTRAINT `area_key` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`),
  ADD CONSTRAINT `usuario5_key` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `encuestas`
--
ALTER TABLE `encuestas`
  ADD CONSTRAINT `departamento1_key` FOREIGN KEY (`departamento_id`) REFERENCES `departamentos` (`id`);

--
-- Filtros para la tabla `historico_cambios`
--
ALTER TABLE `historico_cambios`
  ADD CONSTRAINT `ticket1_key` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`),
  ADD CONSTRAINT `usuario3_key` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `preguntas`
--
ALTER TABLE `preguntas`
  ADD CONSTRAINT `encuesta_key` FOREIGN KEY (`encuesta_id`) REFERENCES `encuestas` (`id`);

--
-- Filtros para la tabla `puntajes`
--
ALTER TABLE `puntajes`
  ADD CONSTRAINT `pregunta_key` FOREIGN KEY (`pregunta_id`) REFERENCES `preguntas` (`id`),
  ADD CONSTRAINT `ticket2_key` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`);

--
-- Filtros para la tabla `seguidores`
--
ALTER TABLE `seguidores`
  ADD CONSTRAINT `ticket3_key` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`),
  ADD CONSTRAINT `usuario2_key` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `social_accounts`
--
ALTER TABLE `social_accounts`
  ADD CONSTRAINT `social_accounts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `subcategorias`
--
ALTER TABLE `subcategorias`
  ADD CONSTRAINT `categoria_key` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`);

--
-- Filtros para la tabla `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `estado_key` FOREIGN KEY (`estado_id`) REFERENCES `estados` (`id`),
  ADD CONSTRAINT `prioridad_key` FOREIGN KEY (`prioridad_id`) REFERENCES `prioridads` (`id`),
  ADD CONSTRAINT `proyecto_key` FOREIGN KEY (`proyecto_id`) REFERENCES `proyectos` (`id`),
  ADD CONSTRAINT `subcategoria_key` FOREIGN KEY (`subcategoria_id`) REFERENCES `subcategorias` (`id`),
  ADD CONSTRAINT `tipo_key` FOREIGN KEY (`tipo_id`) REFERENCES `tipos` (`id`),
  ADD CONSTRAINT `usuario_key` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `ticket_archivos`
--
ALTER TABLE `ticket_archivos`
  ADD CONSTRAINT `ticket_key3` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`),
  ADD CONSTRAINT `usuario4_key` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

