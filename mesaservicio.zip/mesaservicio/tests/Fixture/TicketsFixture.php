<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * TicketsFixture
 */
class TicketsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id' => ['type' => 'integer', 'length' => null, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'autoIncrement' => true, 'precision' => null],
        'titulo' => ['type' => 'string', 'length' => 150, 'null' => false, 'default' => null, 'collate' => 'utf8_general_ci', 'comment' => '', 'precision' => null],
        'descripcion' => ['type' => 'string', 'length' => 4000, 'null' => false, 'default' => null, 'collate' => 'utf8_general_ci', 'comment' => '', 'precision' => null],
        'proyecto_id' => ['type' => 'integer', 'length' => null, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'estado_id' => ['type' => 'integer', 'length' => null, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'prioridad_id' => ['type' => 'integer', 'length' => null, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'user_id' => ['type' => 'uuid', 'length' => null, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null],
        'asignado_id' => ['type' => 'uuid', 'length' => null, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null],
        'tipo_id' => ['type' => 'integer', 'length' => null, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'subcategoria_id' => ['type' => 'integer', 'length' => null, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'fecha_creacion' => ['type' => 'timestamp', 'length' => null, 'precision' => null, 'null' => false, 'default' => 'current_timestamp()', 'comment' => ''],
        '_indexes' => [
            'proyecto_key' => ['type' => 'index', 'columns' => ['proyecto_id'], 'length' => []],
            'estado_key' => ['type' => 'index', 'columns' => ['estado_id'], 'length' => []],
            'prioridad_key' => ['type' => 'index', 'columns' => ['prioridad_id'], 'length' => []],
            'usuario_key' => ['type' => 'index', 'columns' => ['user_id'], 'length' => []],
            'tipo_key' => ['type' => 'index', 'columns' => ['tipo_id'], 'length' => []],
            'subcategoria_key' => ['type' => 'index', 'columns' => ['subcategoria_id'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id'], 'length' => []],
            'titulo' => ['type' => 'unique', 'columns' => ['titulo'], 'length' => []],
            'usuario_key' => ['type' => 'foreign', 'columns' => ['user_id'], 'references' => ['users', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'tipo_key' => ['type' => 'foreign', 'columns' => ['tipo_id'], 'references' => ['tipos', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'subcategoria_key' => ['type' => 'foreign', 'columns' => ['subcategoria_id'], 'references' => ['subcategorias', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'proyecto_key' => ['type' => 'foreign', 'columns' => ['proyecto_id'], 'references' => ['proyectos', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'prioridad_key' => ['type' => 'foreign', 'columns' => ['prioridad_id'], 'references' => ['prioridads', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'estado_key' => ['type' => 'foreign', 'columns' => ['estado_id'], 'references' => ['estados', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'utf8_general_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'titulo' => 'Lorem ipsum dolor sit amet',
                'descripcion' => 'Lorem ipsum dolor sit amet',
                'proyecto_id' => 1,
                'estado_id' => 1,
                'prioridad_id' => 1,
                'user_id' => '042f0d0f-c9d4-4e6f-800c-20c926a4cea3',
                'asignado_id' => '4a621e58-c561-41b5-b051-735f894b530e',
                'tipo_id' => 1,
                'subcategoria_id' => 1,
                'fecha_creacion' => 1603910923,
            ],
        ];
        parent::init();
    }
}
