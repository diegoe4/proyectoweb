<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\TipoTicketTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\TipoTicketTable Test Case
 */
class TipoTicketTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\TipoTicketTable
     */
    protected $TipoTicket;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.TipoTicket',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('TipoTicket') ? [] : ['className' => TipoTicketTable::class];
        $this->TipoTicket = $this->getTableLocator()->get('TipoTicket', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->TipoTicket);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
