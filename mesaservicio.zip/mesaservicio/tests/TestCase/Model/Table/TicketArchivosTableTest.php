<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\TicketArchivosTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\TicketArchivosTable Test Case
 */
class TicketArchivosTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\TicketArchivosTable
     */
    protected $TicketArchivos;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.TicketArchivos',
        'app.Tickets',
        'app.Users',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('TicketArchivos') ? [] : ['className' => TicketArchivosTable::class];
        $this->TicketArchivos = $this->getTableLocator()->get('TicketArchivos', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->TicketArchivos);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
