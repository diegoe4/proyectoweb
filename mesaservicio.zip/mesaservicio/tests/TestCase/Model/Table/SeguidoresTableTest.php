<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\SeguidoresTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\SeguidoresTable Test Case
 */
class SeguidoresTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\SeguidoresTable
     */
    protected $Seguidores;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.Seguidores',
        'app.Users',
        'app.Tickets',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Seguidores') ? [] : ['className' => SeguidoresTable::class];
        $this->Seguidores = $this->getTableLocator()->get('Seguidores', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->Seguidores);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
