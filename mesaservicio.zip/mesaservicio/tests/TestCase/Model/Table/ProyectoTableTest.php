<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\ProyectoTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\ProyectoTable Test Case
 */
class ProyectoTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\ProyectoTable
     */
    protected $Proyecto;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.Proyecto',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Proyecto') ? [] : ['className' => ProyectoTable::class];
        $this->Proyecto = $this->getTableLocator()->get('Proyecto', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->Proyecto);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
