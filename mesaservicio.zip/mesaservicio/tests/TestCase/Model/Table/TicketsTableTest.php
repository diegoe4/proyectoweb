<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\TicketsTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\TicketsTable Test Case
 */
class TicketsTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\TicketsTable
     */
    protected $Tickets;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.Tickets',
        'app.Proyectos',
        'app.Estados',
        'app.Prioridads',
        'app.Users',
        'app.Asignados',
        'app.Tipos',
        'app.Subcategorias',
        'app.Comentarios',
        'app.HistoricoCambios',
        'app.Puntajes',
        'app.Seguidores',
        'app.TicketArchivos',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Tickets') ? [] : ['className' => TicketsTable::class];
        $this->Tickets = $this->getTableLocator()->get('Tickets', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->Tickets);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
