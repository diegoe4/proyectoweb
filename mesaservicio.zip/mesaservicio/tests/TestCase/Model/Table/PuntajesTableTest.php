<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\PuntajesTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\PuntajesTable Test Case
 */
class PuntajesTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\PuntajesTable
     */
    protected $Puntajes;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.Puntajes',
        'app.Preguntas',
        'app.Tickets',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Puntajes') ? [] : ['className' => PuntajesTable::class];
        $this->Puntajes = $this->getTableLocator()->get('Puntajes', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->Puntajes);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
