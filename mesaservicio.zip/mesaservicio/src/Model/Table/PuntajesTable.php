<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Puntajes Model
 *
 * @property \App\Model\Table\PreguntasTable&\Cake\ORM\Association\BelongsTo $Preguntas
 * @property \App\Model\Table\TicketsTable&\Cake\ORM\Association\BelongsTo $Tickets
 *
 * @method \App\Model\Entity\Puntaje newEmptyEntity()
 * @method \App\Model\Entity\Puntaje newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\Puntaje[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Puntaje get($primaryKey, $options = [])
 * @method \App\Model\Entity\Puntaje findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\Puntaje patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Puntaje[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Puntaje|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Puntaje saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Puntaje[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Puntaje[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\Puntaje[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Puntaje[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 */
class PuntajesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('puntajes');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->belongsTo('Preguntas', [
            'foreignKey' => 'pregunta_id',
            'joinType' => 'INNER',
        ]);
        $this->belongsTo('Tickets', [
            'foreignKey' => 'ticket_id',
            'joinType' => 'INNER',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id')
            ->allowEmptyString('id', null, 'create');

        $validator
            ->allowEmptyString('calificacion');

        $validator
            ->scalar('explicacion')
            ->maxLength('explicacion', 400)
            ->requirePresence('explicacion', 'create')
            ->notEmptyString('explicacion');

        $validator
            ->dateTime('fecha_creacion')
            ->notEmptyDateTime('fecha_creacion');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['pregunta_id'], 'Preguntas'), ['errorField' => 'pregunta_id']);
        $rules->add($rules->existsIn(['ticket_id'], 'Tickets'), ['errorField' => 'ticket_id']);

        return $rules;
    }
}
