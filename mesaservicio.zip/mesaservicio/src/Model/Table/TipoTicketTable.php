<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * TipoTicket Model
 *
 * @method \App\Model\Entity\TipoTicket newEmptyEntity()
 * @method \App\Model\Entity\TipoTicket newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\TipoTicket[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\TipoTicket get($primaryKey, $options = [])
 * @method \App\Model\Entity\TipoTicket findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\TipoTicket patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\TipoTicket[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\TipoTicket|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\TipoTicket saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\TipoTicket[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\TipoTicket[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\TipoTicket[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\TipoTicket[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 */
class TipoTicketTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('tipo_ticket');
        $this->setDisplayField('ID');
        $this->setPrimaryKey('ID');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('ID')
            ->allowEmptyString('ID', null, 'create');

        $validator
            ->scalar('NOMBRE')
            ->maxLength('NOMBRE', 50)
            ->requirePresence('NOMBRE', 'create')
            ->notEmptyString('NOMBRE')
            ->add('NOMBRE', 'unique', ['rule' => 'validateUnique', 'provider' => 'table']);

        $validator
            ->boolean('ACTIVO')
            ->requirePresence('ACTIVO', 'create')
            ->notEmptyString('ACTIVO');

        $validator
            ->dateTime('FECHA_CREACION')
            ->notEmptyDateTime('FECHA_CREACION');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->isUnique(['NOMBRE']), ['errorField' => 'NOMBRE']);

        return $rules;
    }
}
