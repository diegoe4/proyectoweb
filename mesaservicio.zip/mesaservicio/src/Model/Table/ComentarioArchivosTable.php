<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * ComentarioArchivos Model
 *
 * @property \App\Model\Table\ComentariosTable&\Cake\ORM\Association\BelongsTo $Comentarios
 *
 * @method \App\Model\Entity\ComentarioArchivo newEmptyEntity()
 * @method \App\Model\Entity\ComentarioArchivo newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\ComentarioArchivo[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\ComentarioArchivo get($primaryKey, $options = [])
 * @method \App\Model\Entity\ComentarioArchivo findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\ComentarioArchivo patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\ComentarioArchivo[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\ComentarioArchivo|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\ComentarioArchivo saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\ComentarioArchivo[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\ComentarioArchivo[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\ComentarioArchivo[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\ComentarioArchivo[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 */
class ComentarioArchivosTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('comentario_archivos');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->belongsTo('Comentarios', [
            'foreignKey' => 'comentario_id',
            'joinType' => 'INNER',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id')
            ->allowEmptyString('id', null, 'create');

        $validator
            ->scalar('nombre')
            ->maxLength('nombre', 80)
            ->requirePresence('nombre', 'create')
            ->notEmptyString('nombre');

        $validator
            ->scalar('extension')
            ->maxLength('extension', 5)
            ->requirePresence('extension', 'create')
            ->notEmptyString('extension');

        $validator
            ->allowEmptyString('contenido');

        $validator
            ->integer('tamano')
            ->requirePresence('tamano', 'create')
            ->notEmptyString('tamano');

        $validator
            ->dateTime('fecha_creacion')
            ->notEmptyDateTime('fecha_creacion');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['comentario_id'], 'Comentarios'), ['errorField' => 'comentario_id']);

        return $rules;
    }
}
