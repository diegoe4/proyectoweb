<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Ticket Entity
 *
 * @property int $id
 * @property string $titulo
 * @property string $descripcion
 * @property int $proyecto_id
 * @property int $estado_id
 * @property int $prioridad_id
 * @property string $user_id
 * @property string $asignado_id
 * @property int $tipo_id
 * @property int $subcategoria_id
 * @property \Cake\I18n\FrozenTime $fecha_creacion
 *
 * @property \App\Model\Entity\Proyecto $proyecto
 * @property \App\Model\Entity\Estado $estado
 * @property \App\Model\Entity\Prioridad $prioridad
 * @property \CakeDC\Users\Model\Entity\User $user
 * @property \App\Model\Entity\Asignado $asignado
 * @property \App\Model\Entity\Tipo $tipo
 * @property \App\Model\Entity\Subcategoria $subcategoria
 * @property \App\Model\Entity\Comentario[] $comentarios
 * @property \App\Model\Entity\HistoricoCambio[] $historico_cambios
 * @property \App\Model\Entity\Puntaje[] $puntajes
 * @property \App\Model\Entity\Seguidore[] $seguidores
 * @property \App\Model\Entity\TicketArchivo[] $ticket_archivos
 */
class Ticket extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'titulo' => true,
        'descripcion' => true,
        'proyecto_id' => true,
        'estado_id' => true,
        'prioridad_id' => true,
        'user_id' => true,
        'asignado_id' => true,
        'tipo_id' => true,
        'subcategoria_id' => true,
        'fecha_creacion' => true,
        'proyecto' => true,
        'estado' => true,
        'prioridad' => true,
        'user' => true,
        'asignado' => true,
        'tipo' => true,
        'subcategoria' => true,
        'comentarios' => true,
        'historico_cambios' => true,
        'puntajes' => true,
        'seguidores' => true,
        'ticket_archivos' => true,
    ];
}
