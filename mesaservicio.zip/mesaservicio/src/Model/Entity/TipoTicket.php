<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * TipoTicket Entity
 *
 * @property int $ID
 * @property string $NOMBRE
 * @property bool $ACTIVO
 * @property \Cake\I18n\FrozenTime $FECHA_CREACION
 */
class TipoTicket extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'NOMBRE' => true,
        'ACTIVO' => true,
        'FECHA_CREACION' => true,
    ];
}
