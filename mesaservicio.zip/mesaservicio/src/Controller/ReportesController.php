<?php
declare(strict_types=1);

namespace App\Controller;

use Ghunti\HighchartsPHP\Highchart;
use Ghunti\HighchartsPHP\HighchartJsExpr;
use Cake\Datasource\ConnectionManager;


/**
 * Reportes Controller
 */
class ReportesController extends AppController
{
    /**
     * Reporte de Tickets
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function reportetickets($ano)
    {
		
	
        $chart = new Highchart();
		
		$chart->chart->renderTo = "container";
		$chart->chart->type = "column";
		$chart->title->text = "Tickets por estado en un determinado rango de tiempo.";
		$chart->xAxis->categories = array(
			'Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'
		);
		$chart->yAxis->allowDecimals = false;
		$chart->yAxis->min = 0;
		$chart->yAxis->title->text = "Número de tickets";
		$chart->tooltip->formatter = new HighchartJsExpr(
			"function() {
			return '<b>'+ this.x +'</b><br/>'+
			this.series.name +': '+ this.y +'<br/>'+
			'Total: '+ this.point.stackTotal;}");

		$chart->plotOptions->column->stacking = "normal";

		/*Ejecutamos el stored procedure para poder obtener informacion por ano de los tickets*/
		$this->connection = ConnectionManager::get('default');
		$listadoticketporestadomes = $this->connection->execute("CALL pro_obtener_tickets_ano(".$ano.")")->fetchAll('assoc');
				
		$estadoNuevo = [0,0,0,0,0,0,0,0,0,0,0,0];
		$estadoAsignada = [0,0,0,0,0,0,0,0,0,0,0,0];
		$estadoCerrada = [0,0,0,0,0,0,0,0,0,0,0,0];
		$estadoRechazada = [0,0,0,0,0,0,0,0,0,0,0,0];
		
		 foreach ($listadoticketporestadomes as $ticketestado) {
			 
			 if($ticketestado['estado_id']== '1'){
				 if((int)$ticketestado['01']>0)
				 $estadoNuevo[0] = (int)$ticketestado['01'];
				 if((int)$ticketestado['02']>0)
				 $estadoNuevo[1] = (int)$ticketestado['02'];
				 if((int)$ticketestado['03']>0)
				 $estadoNuevo[2] = (int)$ticketestado['03'];
				 if((int)$ticketestado['04']>0)
				 $estadoNuevo[3] = (int)$ticketestado['04'];
				 if((int)$ticketestado['05']>0)
				 $estadoNuevo[4] = (int)$ticketestado['05'];
				 if((int)$ticketestado['06']>0)
				 $estadoNuevo[5] = (int)$ticketestado['06'];
				 if((int)$ticketestado['07']>0)
				 $estadoNuevo[6] = (int)$ticketestado['07'];
				 if((int)$ticketestado['08']>0)
				 $estadoNuevo[7] = (int)$ticketestado['08'];
				 if((int)$ticketestado['09']>0)
				 $estadoNuevo[8] = (int)$ticketestado['09'];
				 if((int)$ticketestado['10']>0)
				 $estadoNuevo[9] = (int)$ticketestado['10'];
				 if((int)$ticketestado['11']>0)
				 $estadoNuevo[10] = (int) $ticketestado['11'];
				 if((int)$ticketestado['12']>0)
				 $estadoNuevo[11] = (int)$ticketestado['12'];
			 }
			 if($ticketestado['estado_id']== '2'){
				if((int)$ticketestado['01']>0)
				$estadoAsignada[0] = (int)$ticketestado['01'];
				if((int)$ticketestado['02']>0)
				$estadoAsignada[1] = (int)$ticketestado['02'];
				if((int)$ticketestado['03']>0)
				$estadoAsignada[2] = (int)$ticketestado['03'];
				if((int)$ticketestado['04']>0)
				$estadoAsignada[3] = (int)$ticketestado['04'];
				if((int)$ticketestado['05']>0)
				$estadoAsignada[4] = (int)$ticketestado['05'];
				if((int)$ticketestado['06']>0)
				$estadoAsignada[5] = (int)$ticketestado['06'];
				if((int)$ticketestado['07']>0)
				$estadoAsignada[6] = (int)$ticketestado['07'];
				if((int)$ticketestado['08']>0)
				$estadoAsignada[7] = (int)$ticketestado['08'];
				if((int)$ticketestado['09']>0)
				$estadoAsignada[8] = (int)$ticketestado['09'];
				if((int)$ticketestado['10']>0)
				$estadoAsignada[9] = (int)$ticketestado['10'];
				if((int)$ticketestado['11']>0)
				$estadoAsignada[10] = (int) $ticketestado['11'];
				if((int)$ticketestado['12']>0)
				$estadoAsignada[11] = (int)$ticketestado['12'];
			 }	
			 
			 if($ticketestado['estado_id']== '4'){
				if((int)$ticketestado['01']>0)
				 $estadoCerrada[0] = (int)$ticketestado['01'];
				 if((int)$ticketestado['02']>0)
				 $estadoCerrada[1] = (int)$ticketestado['02'];
				 if((int)$ticketestado['03']>0)
				 $estadoCerrada[2] = (int)$ticketestado['03'];
				 if((int)$ticketestado['04']>0)
				 $estadoCerrada[3] = (int)$ticketestado['04'];
				 if((int)$ticketestado['05']>0)
				 $estadoCerrada[4] = (int)$ticketestado['05'];
				 if((int)$ticketestado['06']>0)
				 $estadoCerrada[5] = (int)$ticketestado['06'];
				 if((int)$ticketestado['07']>0)
				 $estadoCerrada[6] = (int)$ticketestado['07'];
				 if((int)$ticketestado['08']>0)
				 $estadoCerrada[7] = (int)$ticketestado['08'];
				 if((int)$ticketestado['09']>0)
				 $estadoCerrada[8] = (int)$ticketestado['09'];
				 if((int)$ticketestado['10']>0)
				 $estadoCerrada[9] = (int)$ticketestado['10'];
				 if((int)$ticketestado['11']>0)
				 $estadoCerrada[10] = (int) $ticketestado['11'];
				 if((int)$ticketestado['12']>0)
				 $estadoCerrada[11] = (int)$ticketestado['12'];
			 }
			 
			 if($ticketestado['estado_id']== '5'){
				if((int)$ticketestado['01']>0)
				$estadoRechazada[0] = (int)$ticketestado['01'];
				if((int)$ticketestado['02']>0)
				$estadoRechazada[1] = (int)$ticketestado['02'];
				if((int)$ticketestado['03']>0)
				$estadoRechazada[2] = (int)$ticketestado['03'];
				if((int)$ticketestado['04']>0)
				$estadoRechazada[3] = (int)$ticketestado['04'];
				if((int)$ticketestado['05']>0)
				$estadoRechazada[4] = (int)$ticketestado['05'];
				if((int)$ticketestado['06']>0)
				$estadoRechazada[5] = (int)$ticketestado['06'];
				if((int)$ticketestado['07']>0)
				$estadoRechazada[6] = (int)$ticketestado['07'];
				if((int)$ticketestado['08']>0)
				$estadoRechazada[7] = (int)$ticketestado['08'];
				if((int)$ticketestado['09']>0)
				$estadoRechazada[8] = (int)$ticketestado['09'];
				if((int)$ticketestado['10']>0)
				$estadoRechazada[9] = (int)$ticketestado['10'];
				if((int)$ticketestado['11']>0)
				$estadoRechazada[10] = (int) $ticketestado['11'];
				if((int)$ticketestado['12']>0)
				$estadoRechazada[11] = (int)$ticketestado['12'];
			 }
			 
		}
		$chart->series[] = array('name' => "Nueva",'data' => $estadoNuevo,'stack' => 'nueva');
		$chart->series[] = array('name' => "Asignada",'data' => $estadoAsignada,'stack' => 'asignada');
		$chart->series[] = array('name' => "Cerrada",'data' => $estadoCerrada,'stack' => 'cerrada');
		$chart->series[] = array('name' => "Rechazada",'data' =>$estadoRechazada ,'stack' => 'rechazada');

		/*
		$consulta = 'TODO';		
		$listadoticketpormes = $this->connection->execute("CALL pro_obtener_tickets_general(".$ano.",'".$consulta."')")->fetchAll('assoc');
	
		
		$ticketmesmejor='';
		
		$group = array();
		$group2 = array();
		$contador = 0;
		$nombremayortickets = '';
		$valormayortickets = '';

		foreach ( $listadoticketpormes as $value ) {	
			$group[$value['nombre']][] =  $value['TOTAL'];
		}
		
		// Sumamos todos los elementos
		foreach($group as $nombre => $mod) {
			$contador +=1;
			if($contador==1){
				$nombremayortickets = $nombre;
				$valormayortickets = array_sum($mod);
			}
			$group2 [$nombre][] = array_sum($mod);
	   }
	  
	   $ticketsmestotal[$contador][13];
	   debug($ticketsmestotal);
	  
	   $contador=0;
	   foreach ($group2 as  $key => $val) {
		
	   foreach ($listadoticketpormes as $ticketmes) {

		
		if($ticketmes['nombre'] == $key){
			
			$ticketsmestotal[$contador][0] = $key;
			if((int)$ticketmes['01']>0)
			$ticketsmestotal[$contador][1] += (int)$ticketmes['01'];
			else
			$ticketsmestotal[$contador][1] += 0;
			if((int)$ticketmes['02']>0)
			$ticketsmestotal[$contador][2] += (int)$ticketmes['02'];
			else
			$ticketsmestotal[$contador][2] += (int)'0';
			if((int)$ticketmes['03']>0)
			$ticketsmestotal[$contador][3] += (int)$ticketmes['03'];
			else
			$ticketsmestotal[$contador][3] += (int)'0';
			if((int)$ticketmes['04']>0)
			$ticketsmestotal[$contador][4] += (int)$ticketmes['04'];
			else
			$ticketsmestotal[$contador][4] += (int)'0';
			if((int)$ticketmes['05']>0)
			$ticketsmestotal[$contador][5] += (int)$ticketmes['05'];
			else
			$ticketsmestotal[$contador][5] += (int)'0';
			if((int)$ticketmes['06']>0)
			$ticketsmestotal[$contador][6] += (int)$ticketmes['06'];
			else
			$ticketsmestotal[$contador][6] += (int)'0';
			if((int)$ticketmes['07']>0)
			$ticketsmestotal[$contador][7] += (int)$ticketmes['07'];
			else
			$ticketsmestotal[$contador][7] += (int)'0';
			if((int)$ticketmes['08']>0)
			$ticketsmestotal[$contador][8] += (int)$ticketmes['08'];
			else
			$ticketsmestotal[$contador][8] += (int)'0';
			if((int)$ticketmes['09']>0)
			$ticketsmestotal[$contador][9] += (int)$ticketmes['09'];
			else
			$ticketsmestotal[$contador][9] += (int)'0';
			if((int)$ticketmes['10']>0)
			$ticketsmestotal[$contador][10] += (int)$ticketmes['10'];
			else
			$ticketsmestotal[$contador][10] += (int)'0';
			if((int)$ticketmes['11']>0)
			$ticketsmestotal[$contador][11] += (int) $ticketmes['11'];
			else
			$ticketsmestotal[$contador][11] += (int)'0';
			if((int)$ticketmes['12']>0)
			$ticketsmestotal[$contador][12] += (int)$ticketmes['12'];
			else
			$ticketsmestotal[$contador][12] += (int)'0';
			}	
		}
		$contador +=1;
	}	
	
	debug($ticketsmestotal);
	
		$this->set('nombremayortickets', $nombremayortickets);
		$this->set('valormayortickets', $valormayortickets);
		$this->set('ticketsmestotal', $ticketsmestotal);
*/    
		$this->set( compact( 'chart' ) );
    }

	/**
     * Reporte de Tickets por area
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function reporteticketsarea($ano = null,$area = null)
    {
		$ticketsareatotal = [0,0,0,0,0,0,0,0,0,0,0,0,0];
		$ticketareamejor='';
		$nombremayortickets = '';
		$valormayortickets = '';
		
		$chart = new Highchart();
		
		$chart->chart->renderTo = "container";
		$chart->chart->type = "column";
		$chart->title->text = "Tickets por estado en un determinado rango de tiempo por área";
		$chart->xAxis->categories = array(
			'Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'
		);
		$chart->yAxis->allowDecimals = false;
		$chart->yAxis->min = 0;
		$chart->yAxis->title->text = "Número de tickets";
		$chart->tooltip->formatter = new HighchartJsExpr(
			"function() {
			return '<b>'+ this.x +'</b><br/>'+
			this.series.name +': '+ this.y +'<br/>'+
			'Total: '+ this.point.stackTotal;}");

		$chart->plotOptions->column->stacking = "normal";



		if($ano != null && $area!= null)
		{
		/*Ejecutamos el stored procedure para poder obtener informacion por ano de los tickets*/
		$this->connection = ConnectionManager::get('default');
		$listadoticketporestadomes = $this->connection->execute("CALL pro_obtener_tickets_ano_area(".$ano.",".$area.")")->fetchAll('assoc');
	
		
		$estadoNuevo = [0,0,0,0,0,0,0,0,0,0,0,0];
		$estadoAsignada = [0,0,0,0,0,0,0,0,0,0,0,0];
		$estadoCerrada = [0,0,0,0,0,0,0,0,0,0,0,0];
		$estadoRechazada = [0,0,0,0,0,0,0,0,0,0,0,0];
		
		 foreach ($listadoticketporestadomes as $ticketestado) {
			 
			if($ticketestado['estado_id']== '1'){
				if((int)$ticketestado['01']>0)
				$estadoNuevo[0] = (int)$ticketestado['01'];
				if((int)$ticketestado['02']>0)
				$estadoNuevo[1] = (int)$ticketestado['02'];
				if((int)$ticketestado['03']>0)
				$estadoNuevo[2] = (int)$ticketestado['03'];
				if((int)$ticketestado['04']>0)
				$estadoNuevo[3] = (int)$ticketestado['04'];
				if((int)$ticketestado['05']>0)
				$estadoNuevo[4] = (int)$ticketestado['05'];
				if((int)$ticketestado['06']>0)
				$estadoNuevo[5] = (int)$ticketestado['06'];
				if((int)$ticketestado['07']>0)
				$estadoNuevo[6] = (int)$ticketestado['07'];
				if((int)$ticketestado['08']>0)
				$estadoNuevo[7] = (int)$ticketestado['08'];
				if((int)$ticketestado['09']>0)
				$estadoNuevo[8] = (int)$ticketestado['09'];
				if((int)$ticketestado['10']>0)
				$estadoNuevo[9] = (int)$ticketestado['10'];
				if((int)$ticketestado['11']>0)
				$estadoNuevo[10] = (int) $ticketestado['11'];
				if((int)$ticketestado['12']>0)
				$estadoNuevo[11] = (int)$ticketestado['12'];
			}
			if($ticketestado['estado_id']== '2'){
			   if((int)$ticketestado['01']>0)
			   $estadoAsignada[0] = (int)$ticketestado['01'];
			   if((int)$ticketestado['02']>0)
			   $estadoAsignada[1] = (int)$ticketestado['02'];
			   if((int)$ticketestado['03']>0)
			   $estadoAsignada[2] = (int)$ticketestado['03'];
			   if((int)$ticketestado['04']>0)
			   $estadoAsignada[3] = (int)$ticketestado['04'];
			   if((int)$ticketestado['05']>0)
			   $estadoAsignada[4] = (int)$ticketestado['05'];
			   if((int)$ticketestado['06']>0)
			   $estadoAsignada[5] = (int)$ticketestado['06'];
			   if((int)$ticketestado['07']>0)
			   $estadoAsignada[6] = (int)$ticketestado['07'];
			   if((int)$ticketestado['08']>0)
			   $estadoAsignada[7] = (int)$ticketestado['08'];
			   if((int)$ticketestado['09']>0)
			   $estadoAsignada[8] = (int)$ticketestado['09'];
			   if((int)$ticketestado['10']>0)
			   $estadoAsignada[9] = (int)$ticketestado['10'];
			   if((int)$ticketestado['11']>0)
			   $estadoAsignada[10] = (int) $ticketestado['11'];
			   if((int)$ticketestado['12']>0)
			   $estadoAsignada[11] = (int)$ticketestado['12'];
			}	
			
			if($ticketestado['estado_id']== '4'){
			   if((int)$ticketestado['01']>0)
				$estadoCerrada[0] = (int)$ticketestado['01'];
				if((int)$ticketestado['02']>0)
				$estadoCerrada[1] = (int)$ticketestado['02'];
				if((int)$ticketestado['03']>0)
				$estadoCerrada[2] = (int)$ticketestado['03'];
				if((int)$ticketestado['04']>0)
				$estadoCerrada[3] = (int)$ticketestado['04'];
				if((int)$ticketestado['05']>0)
				$estadoCerrada[4] = (int)$ticketestado['05'];
				if((int)$ticketestado['06']>0)
				$estadoCerrada[5] = (int)$ticketestado['06'];
				if((int)$ticketestado['07']>0)
				$estadoCerrada[6] = (int)$ticketestado['07'];
				if((int)$ticketestado['08']>0)
				$estadoCerrada[7] = (int)$ticketestado['08'];
				if((int)$ticketestado['09']>0)
				$estadoCerrada[8] = (int)$ticketestado['09'];
				if((int)$ticketestado['10']>0)
				$estadoCerrada[9] = (int)$ticketestado['10'];
				if((int)$ticketestado['11']>0)
				$estadoCerrada[10] = (int) $ticketestado['11'];
				if((int)$ticketestado['12']>0)
				$estadoCerrada[11] = (int)$ticketestado['12'];
			}
			
			if($ticketestado['estado_id']== '5'){
			   if((int)$ticketestado['01']>0)
			   $estadoRechazada[0] = (int)$ticketestado['01'];
			   if((int)$ticketestado['02']>0)
			   $estadoRechazada[1] = (int)$ticketestado['02'];
			   if((int)$ticketestado['03']>0)
			   $estadoRechazada[2] = (int)$ticketestado['03'];
			   if((int)$ticketestado['04']>0)
			   $estadoRechazada[3] = (int)$ticketestado['04'];
			   if((int)$ticketestado['05']>0)
			   $estadoRechazada[4] = (int)$ticketestado['05'];
			   if((int)$ticketestado['06']>0)
			   $estadoRechazada[5] = (int)$ticketestado['06'];
			   if((int)$ticketestado['07']>0)
			   $estadoRechazada[6] = (int)$ticketestado['07'];
			   if((int)$ticketestado['08']>0)
			   $estadoRechazada[7] = (int)$ticketestado['08'];
			   if((int)$ticketestado['09']>0)
			   $estadoRechazada[8] = (int)$ticketestado['09'];
			   if((int)$ticketestado['10']>0)
			   $estadoRechazada[9] = (int)$ticketestado['10'];
			   if((int)$ticketestado['11']>0)
			   $estadoRechazada[10] = (int) $ticketestado['11'];
			   if((int)$ticketestado['12']>0)
			   $estadoRechazada[11] = (int)$ticketestado['12'];
			}
			 
		}
		$chart->series[] = array('name' => "Nueva",'data' => $estadoNuevo,'stack' => 'nueva');
		$chart->series[] = array('name' => "Asignada",'data' => $estadoAsignada,'stack' => 'asignada');
		$chart->series[] = array('name' => "Cerrada",'data' => $estadoCerrada,'stack' => 'cerrada');
		$chart->series[] = array('name' => "Rechazada",'data' =>$estadoRechazada ,'stack' => 'rechazada');

		$consulta = 'AREA';		
		$listadoticketporarea = $this->connection->execute("CALL pro_obtener_tickets_general(".$ano.",'".$consulta."')")->fetchAll('assoc');
	
		
		
		$group = array();
		$group2 = array();
		$contador = 0;


		foreach ( $listadoticketporarea as $value ) {	
			$group[$value['nombre']][] =  $value['TOTAL'];
		}
		
		// Sumamos todos los elementos
		foreach($group as $nombre => $mod) {
			$contador +=1;
			if($contador==1){
				$nombremayortickets = $nombre;
				$valormayortickets = array_sum($mod);
			}
			$group2 [$nombre][] = array_sum($mod);
	   }

		foreach ($listadoticketporarea as $ticketarea) {

			if($ticketarea['nombre'] == $nombremayortickets){
			
			if((int)$ticketarea['01']>0)
			$ticketsareatotal[0] = (int)$ticketarea['01'];
			if((int)$ticketarea['02']>0)
			$ticketsareatotal[1] = (int)$ticketarea['02'];
			if((int)$ticketarea['03']>0)
			$ticketsareatotal[2] = (int)$ticketarea['03'];
			if((int)$ticketarea['04']>0)
			$ticketsareatotal[3] = (int)$ticketarea['04'];
			if((int)$ticketarea['05']>0)
			$ticketsareatotal[4] = (int)$ticketarea['05'];
			if((int)$ticketarea['06']>0)
			$ticketsareatotal[5] = (int)$ticketarea['06'];
			if((int)$ticketarea['07']>0)
			$ticketsareatotal[6] = (int)$ticketarea['07'];
			if((int)$ticketarea['08']>0)
			$ticketsareatotal[7] = (int)$ticketarea['08'];
			if((int)$ticketarea['09']>0)
			$ticketsareatotal[8] = (int)$ticketarea['09'];
			if((int)$ticketarea['10']>0)
			$ticketsareatotal[9] = (int)$ticketarea['10'];
			if((int)$ticketarea['11']>0)
			$ticketsareatotal[10] = (int) $ticketarea['11'];
			if((int)$ticketarea['12']>0)
			$ticketsareatotal[11] = (int)$ticketarea['12'];
			}	
		}	
	
				
		}
		
		$this->loadModel('Areas');
		$areas = $this->Areas->find('list');
		$this->set( compact( 'chart','areas' ) );
		$this->set('nombremayortickets', $nombremayortickets);
		$this->set('valormayortickets', $valormayortickets);
		$this->set('ticketsareatotal', $ticketsareatotal);
		
    }
	
	
	/**
     * Reporte de Tickets por departamento
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function reporteticketsdepartamento($ano = null,$departamento = null)
    {
		$ticketsdepartamentototal = [0,0,0,0,0,0,0,0,0,0,0,0,0];
		$ticketdepartamentomejor='';
		$nombremayortickets = '';
		$valormayortickets = '';

        $chart = new Highchart();
		
		$chart->chart->renderTo = "container";
		$chart->chart->type = "column";
		$chart->title->text = "Tickets por estado en un determinado rango de tiempo por departamento";
		$chart->xAxis->categories = array(
			'Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'
		);
		$chart->yAxis->allowDecimals = false;
		$chart->yAxis->min = 0;
		$chart->yAxis->title->text = "Número de tickets";
		$chart->tooltip->formatter = new HighchartJsExpr(
			"function() {
			return '<b>'+ this.x +'</b><br/>'+
			this.series.name +': '+ this.y +'<br/>'+
			'Total: '+ this.point.stackTotal;}");

		$chart->plotOptions->column->stacking = "normal";



		if($ano != null && $departamento!= null)
		{
		/*Ejecutamos el stored procedure para poder obtener informacion por ano de los tickets*/
		$this->connection = ConnectionManager::get('default');
		$listadoticketporestadomes = $this->connection->execute("CALL pro_obtener_tickets_ano_departamento(".$ano.",".$departamento.")")->fetchAll('assoc');
	
		$estadoNuevo = [0,0,0,0,0,0,0,0,0,0,0,0];
		$estadoAsignada = [0,0,0,0,0,0,0,0,0,0,0,0];
		$estadoCerrada = [0,0,0,0,0,0,0,0,0,0,0,0];
		$estadoRechazada = [0,0,0,0,0,0,0,0,0,0,0,0];
		
		 foreach ($listadoticketporestadomes as $ticketestado) {
			 
			if($ticketestado['estado_id']== '1'){
				if((int)$ticketestado['01']>0)
				$estadoNuevo[0] = (int)$ticketestado['01'];
				if((int)$ticketestado['02']>0)
				$estadoNuevo[1] = (int)$ticketestado['02'];
				if((int)$ticketestado['03']>0)
				$estadoNuevo[2] = (int)$ticketestado['03'];
				if((int)$ticketestado['04']>0)
				$estadoNuevo[3] = (int)$ticketestado['04'];
				if((int)$ticketestado['05']>0)
				$estadoNuevo[4] = (int)$ticketestado['05'];
				if((int)$ticketestado['06']>0)
				$estadoNuevo[5] = (int)$ticketestado['06'];
				if((int)$ticketestado['07']>0)
				$estadoNuevo[6] = (int)$ticketestado['07'];
				if((int)$ticketestado['08']>0)
				$estadoNuevo[7] = (int)$ticketestado['08'];
				if((int)$ticketestado['09']>0)
				$estadoNuevo[8] = (int)$ticketestado['09'];
				if((int)$ticketestado['10']>0)
				$estadoNuevo[9] = (int)$ticketestado['10'];
				if((int)$ticketestado['11']>0)
				$estadoNuevo[10] = (int) $ticketestado['11'];
				if((int)$ticketestado['12']>0)
				$estadoNuevo[11] = (int)$ticketestado['12'];
			}
			if($ticketestado['estado_id']== '2'){
			   if((int)$ticketestado['01']>0)
			   $estadoAsignada[0] = (int)$ticketestado['01'];
			   if((int)$ticketestado['02']>0)
			   $estadoAsignada[1] = (int)$ticketestado['02'];
			   if((int)$ticketestado['03']>0)
			   $estadoAsignada[2] = (int)$ticketestado['03'];
			   if((int)$ticketestado['04']>0)
			   $estadoAsignada[3] = (int)$ticketestado['04'];
			   if((int)$ticketestado['05']>0)
			   $estadoAsignada[4] = (int)$ticketestado['05'];
			   if((int)$ticketestado['06']>0)
			   $estadoAsignada[5] = (int)$ticketestado['06'];
			   if((int)$ticketestado['07']>0)
			   $estadoAsignada[6] = (int)$ticketestado['07'];
			   if((int)$ticketestado['08']>0)
			   $estadoAsignada[7] = (int)$ticketestado['08'];
			   if((int)$ticketestado['09']>0)
			   $estadoAsignada[8] = (int)$ticketestado['09'];
			   if((int)$ticketestado['10']>0)
			   $estadoAsignada[9] = (int)$ticketestado['10'];
			   if((int)$ticketestado['11']>0)
			   $estadoAsignada[10] = (int) $ticketestado['11'];
			   if((int)$ticketestado['12']>0)
			   $estadoAsignada[11] = (int)$ticketestado['12'];
			}	
			
			if($ticketestado['estado_id']== '4'){
			   if((int)$ticketestado['01']>0)
				$estadoCerrada[0] = (int)$ticketestado['01'];
				if((int)$ticketestado['02']>0)
				$estadoCerrada[1] = (int)$ticketestado['02'];
				if((int)$ticketestado['03']>0)
				$estadoCerrada[2] = (int)$ticketestado['03'];
				if((int)$ticketestado['04']>0)
				$estadoCerrada[3] = (int)$ticketestado['04'];
				if((int)$ticketestado['05']>0)
				$estadoCerrada[4] = (int)$ticketestado['05'];
				if((int)$ticketestado['06']>0)
				$estadoCerrada[5] = (int)$ticketestado['06'];
				if((int)$ticketestado['07']>0)
				$estadoCerrada[6] = (int)$ticketestado['07'];
				if((int)$ticketestado['08']>0)
				$estadoCerrada[7] = (int)$ticketestado['08'];
				if((int)$ticketestado['09']>0)
				$estadoCerrada[8] = (int)$ticketestado['09'];
				if((int)$ticketestado['10']>0)
				$estadoCerrada[9] = (int)$ticketestado['10'];
				if((int)$ticketestado['11']>0)
				$estadoCerrada[10] = (int) $ticketestado['11'];
				if((int)$ticketestado['12']>0)
				$estadoCerrada[11] = (int)$ticketestado['12'];
			}
			
			if($ticketestado['estado_id']== '5'){
			   if((int)$ticketestado['01']>0)
			   $estadoRechazada[0] = (int)$ticketestado['01'];
			   if((int)$ticketestado['02']>0)
			   $estadoRechazada[1] = (int)$ticketestado['02'];
			   if((int)$ticketestado['03']>0)
			   $estadoRechazada[2] = (int)$ticketestado['03'];
			   if((int)$ticketestado['04']>0)
			   $estadoRechazada[3] = (int)$ticketestado['04'];
			   if((int)$ticketestado['05']>0)
			   $estadoRechazada[4] = (int)$ticketestado['05'];
			   if((int)$ticketestado['06']>0)
			   $estadoRechazada[5] = (int)$ticketestado['06'];
			   if((int)$ticketestado['07']>0)
			   $estadoRechazada[6] = (int)$ticketestado['07'];
			   if((int)$ticketestado['08']>0)
			   $estadoRechazada[7] = (int)$ticketestado['08'];
			   if((int)$ticketestado['09']>0)
			   $estadoRechazada[8] = (int)$ticketestado['09'];
			   if((int)$ticketestado['10']>0)
			   $estadoRechazada[9] = (int)$ticketestado['10'];
			   if((int)$ticketestado['11']>0)
			   $estadoRechazada[10] = (int) $ticketestado['11'];
			   if((int)$ticketestado['12']>0)
			   $estadoRechazada[11] = (int)$ticketestado['12'];
			}
			 
		}
		
		
		$consulta = 'DEPA';		
		$listadoticketpordepartamento = $this->connection->execute("CALL pro_obtener_tickets_general(".$ano.",'".$consulta."')")->fetchAll('assoc');

		
		$group = array();
		$group2 = array();
		$contador = 0;
		

		foreach ( $listadoticketpordepartamento as $value ) {	
			$group[$value['nombre']][] =  $value['TOTAL'];
		}
		
		// Sumamos todos los elementos
		foreach($group as $nombre => $mod) {
			$contador +=1;
			if($contador==1){
				$nombremayortickets = $nombre;
				$valormayortickets = array_sum($mod);
			}
			$group2 [$nombre][] = array_sum($mod);
	   }

		foreach ($listadoticketpordepartamento as $ticketdepartamento) {

			if($ticketdepartamento['nombre'] == $nombremayortickets){
			
			if((int)$ticketdepartamento['01']>0)
			$ticketsdepartamentototal[0] = (int)$ticketdepartamento['01'];
			if((int)$ticketdepartamento['02']>0)
			$ticketsdepartamentototal[1] = (int)$ticketdepartamento['02'];
			if((int)$ticketdepartamento['03']>0)
			$ticketsdepartamentototal[2] = (int)$ticketdepartamento['03'];
			if((int)$ticketdepartamento['04']>0)
			$ticketsdepartamentototal[3] = (int)$ticketdepartamento['04'];
			if((int)$ticketdepartamento['05']>0)
			$ticketsdepartamentototal[4] = (int)$ticketdepartamento['05'];
			if((int)$ticketdepartamento['06']>0)
			$ticketsdepartamentototal[5] = (int)$ticketdepartamento['06'];
			if((int)$ticketdepartamento['07']>0)
			$ticketsdepartamentototal[6] = (int)$ticketdepartamento['07'];
			if((int)$ticketdepartamento['08']>0)
			$ticketsdepartamentototal[7] = (int)$ticketdepartamento['08'];
			if((int)$ticketdepartamento['09']>0)
			$ticketsdepartamentototal[8] = (int)$ticketdepartamento['09'];
			if((int)$ticketdepartamento['10']>0)
			$ticketsdepartamentototal[9] = (int)$ticketdepartamento['10'];
			if((int)$ticketdepartamento['11']>0)
			$ticketsdepartamentototal[10] = (int) $ticketdepartamento['11'];
			if((int)$ticketdepartamento['12']>0)
			$ticketsdepartamentototal[11] = (int)$ticketdepartamento['12'];
			
			}
		}	
		
		
		}
		$chart->series[] = array('name' => "Nueva",'data' => $estadoNuevo,'stack' => 'nueva');
		$chart->series[] = array('name' => "Asignada",'data' => $estadoAsignada,'stack' => 'asignada');
		$chart->series[] = array('name' => "Cerrada",'data' => $estadoCerrada,'stack' => 'cerrada');
		$chart->series[] = array('name' => "Rechazada",'data' =>$estadoRechazada ,'stack' => 'rechazada');

		$this->loadModel('Departamentos');
		$departamentos = $this->Departamentos->find('list');
		$this->set( compact( 'chart','departamentos' ) );
		$this->set('nombremayortickets', $nombremayortickets);
		$this->set('valormayortickets', $valormayortickets);
		$this->set('ticketsdepartamentototal', $ticketsdepartamentototal);
		
    }
	
	
	/**
     * Reporte de Tickets por sucursal
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function reporteticketssucursal($ano = null,$sucursal = null)
    {
		$ticketssucursaltotal = [0,0,0,0,0,0,0,0,0,0,0,0,0];
		$ticketsucursalmejor='';
		$nombremayortickets = '';
		$valormayortickets = '';

		$chart = new Highchart();
		
		$chart->chart->renderTo = "container";
		$chart->chart->type = "column";
		$chart->title->text = "Tickets por estado en un determinado rango de tiempo por sucursal";
		$chart->xAxis->categories = array(
			'Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'
		);
		$chart->yAxis->allowDecimals = false;
		$chart->yAxis->min = 0;
		$chart->yAxis->title->text = "Número de tickets";
		$chart->tooltip->formatter = new HighchartJsExpr(
			"function() {
			return '<b>'+ this.x +'</b><br/>'+
			this.series.name +': '+ this.y +'<br/>'+
			'Total: '+ this.point.stackTotal;}");

		$chart->plotOptions->column->stacking = "normal";



		if($ano != null && $sucursal!= null)
		{
		/*Ejecutamos el stored procedure para poder obtener informacion por ano de los tickets*/
		$this->connection = ConnectionManager::get('default');
		$listadoticketporestadomes = $this->connection->execute("CALL pro_obtener_tickets_ano_sucursal(".$ano.",".$sucursal.")")->fetchAll('assoc');
	
		$estadoNuevo = [0,0,0,0,0,0,0,0,0,0,0,0];
		$estadoAsignada = [0,0,0,0,0,0,0,0,0,0,0,0];
		$estadoCerrada = [0,0,0,0,0,0,0,0,0,0,0,0];
		$estadoRechazada = [0,0,0,0,0,0,0,0,0,0,0,0];
		
		 foreach ($listadoticketporestadomes as $ticketestado) {
			 
			 if($ticketestado['estado_id']== '1'){
				 if((int)$ticketestado['01']>0)
				 $estadoNuevo[0] = (int)$ticketestado['01'];
				 if((int)$ticketestado['02']>0)
				 $estadoNuevo[1] = (int)$ticketestado['02'];
				 if((int)$ticketestado['03']>0)
				 $estadoNuevo[2] = (int)$ticketestado['03'];
				 if((int)$ticketestado['04']>0)
				 $estadoNuevo[3] = (int)$ticketestado['04'];
				 if((int)$ticketestado['05']>0)
				 $estadoNuevo[4] = (int)$ticketestado['05'];
				 if((int)$ticketestado['06']>0)
				 $estadoNuevo[5] = (int)$ticketestado['06'];
				 if((int)$ticketestado['07']>0)
				 $estadoNuevo[6] = (int)$ticketestado['07'];
				 if((int)$ticketestado['08']>0)
				 $estadoNuevo[7] = (int)$ticketestado['08'];
				 if((int)$ticketestado['09']>0)
				 $estadoNuevo[8] = (int)$ticketestado['09'];
				 if((int)$ticketestado['10']>0)
				 $estadoNuevo[9] = (int)$ticketestado['10'];
				 if((int)$ticketestado['11']>0)
				 $estadoNuevo[10] = (int) $ticketestado['11'];
				 if((int)$ticketestado['12']>0)
				 $estadoNuevo[11] = (int)$ticketestado['12'];
			 }
			 if($ticketestado['estado_id']== '2'){
				if((int)$ticketestado['01']>0)
				$estadoAsignada[0] = (int)$ticketestado['01'];
				if((int)$ticketestado['02']>0)
				$estadoAsignada[1] = (int)$ticketestado['02'];
				if((int)$ticketestado['03']>0)
				$estadoAsignada[2] = (int)$ticketestado['03'];
				if((int)$ticketestado['04']>0)
				$estadoAsignada[3] = (int)$ticketestado['04'];
				if((int)$ticketestado['05']>0)
				$estadoAsignada[4] = (int)$ticketestado['05'];
				if((int)$ticketestado['06']>0)
				$estadoAsignada[5] = (int)$ticketestado['06'];
				if((int)$ticketestado['07']>0)
				$estadoAsignada[6] = (int)$ticketestado['07'];
				if((int)$ticketestado['08']>0)
				$estadoAsignada[7] = (int)$ticketestado['08'];
				if((int)$ticketestado['09']>0)
				$estadoAsignada[8] = (int)$ticketestado['09'];
				if((int)$ticketestado['10']>0)
				$estadoAsignada[9] = (int)$ticketestado['10'];
				if((int)$ticketestado['11']>0)
				$estadoAsignada[10] = (int) $ticketestado['11'];
				if((int)$ticketestado['12']>0)
				$estadoAsignada[11] = (int)$ticketestado['12'];
			 }	
			 
			 if($ticketestado['estado_id']== '4'){
				if((int)$ticketestado['01']>0)
				 $estadoCerrada[0] = (int)$ticketestado['01'];
				 if((int)$ticketestado['02']>0)
				 $estadoCerrada[1] = (int)$ticketestado['02'];
				 if((int)$ticketestado['03']>0)
				 $estadoCerrada[2] = (int)$ticketestado['03'];
				 if((int)$ticketestado['04']>0)
				 $estadoCerrada[3] = (int)$ticketestado['04'];
				 if((int)$ticketestado['05']>0)
				 $estadoCerrada[4] = (int)$ticketestado['05'];
				 if((int)$ticketestado['06']>0)
				 $estadoCerrada[5] = (int)$ticketestado['06'];
				 if((int)$ticketestado['07']>0)
				 $estadoCerrada[6] = (int)$ticketestado['07'];
				 if((int)$ticketestado['08']>0)
				 $estadoCerrada[7] = (int)$ticketestado['08'];
				 if((int)$ticketestado['09']>0)
				 $estadoCerrada[8] = (int)$ticketestado['09'];
				 if((int)$ticketestado['10']>0)
				 $estadoCerrada[9] = (int)$ticketestado['10'];
				 if((int)$ticketestado['11']>0)
				 $estadoCerrada[10] = (int) $ticketestado['11'];
				 if((int)$ticketestado['12']>0)
				 $estadoCerrada[11] = (int)$ticketestado['12'];
			 }
			 
			 if($ticketestado['estado_id']== '5'){
				if((int)$ticketestado['01']>0)
				$estadoRechazada[0] = (int)$ticketestado['01'];
				if((int)$ticketestado['02']>0)
				$estadoRechazada[1] = (int)$ticketestado['02'];
				if((int)$ticketestado['03']>0)
				$estadoRechazada[2] = (int)$ticketestado['03'];
				if((int)$ticketestado['04']>0)
				$estadoRechazada[3] = (int)$ticketestado['04'];
				if((int)$ticketestado['05']>0)
				$estadoRechazada[4] = (int)$ticketestado['05'];
				if((int)$ticketestado['06']>0)
				$estadoRechazada[5] = (int)$ticketestado['06'];
				if((int)$ticketestado['07']>0)
				$estadoRechazada[6] = (int)$ticketestado['07'];
				if((int)$ticketestado['08']>0)
				$estadoRechazada[7] = (int)$ticketestado['08'];
				if((int)$ticketestado['09']>0)
				$estadoRechazada[8] = (int)$ticketestado['09'];
				if((int)$ticketestado['10']>0)
				$estadoRechazada[9] = (int)$ticketestado['10'];
				if((int)$ticketestado['11']>0)
				$estadoRechazada[10] = (int) $ticketestado['11'];
				if((int)$ticketestado['12']>0)
				$estadoRechazada[11] = (int)$ticketestado['12'];
			 }
		
			 $consulta = 'SUCU';		
		$listadoticketporsucursal = $this->connection->execute("CALL pro_obtener_tickets_general(".$ano.",'".$consulta."')")->fetchAll('assoc');
		
		

		$group = array();
		$group2 = array();
		$contador = 0;
		

		foreach ( $listadoticketporsucursal as $value ) {	
			$group[$value['nombre']][] =  $value['TOTAL'];
		}
		
		// Sumamos todos los elementos
		foreach($group as $nombre => $mod) {
			$contador +=1;
			if($contador==1){
				$nombremayortickets = $nombre;
				$valormayortickets = array_sum($mod);
			}
			$group2 [$nombre][] = array_sum($mod);
	   }
		
		foreach ($listadoticketporsucursal as $ticketsucursal) {

			if($ticketsucursal['nombre'] == $nombremayortickets){
			
			if((int)$ticketsucursal['01']>0)
			$ticketssucursaltotal[0] = (int)$ticketsucursal['01'];
			if((int)$ticketsucursal['02']>0)
			$ticketssucursaltotal[1] = (int)$ticketsucursal['02'];
			if((int)$ticketsucursal['03']>0)
			$ticketssucursaltotal[2] = (int)$ticketsucursal['03'];
			if((int)$ticketsucursal['04']>0)
			$ticketssucursaltotal[3] = (int)$ticketsucursal['04'];
			if((int)$ticketsucursal['05']>0)
			$ticketssucursaltotal[4] = (int)$ticketsucursal['05'];
			if((int)$ticketsucursal['06']>0)
			$ticketssucursaltotal[5] = (int)$ticketsucursal['06'];
			if((int)$ticketsucursal['07']>0)
			$ticketssucursaltotal[6] = (int)$ticketsucursal['07'];
			if((int)$ticketsucursal['08']>0)
			$ticketssucursaltotal[7] = (int)$ticketsucursal['08'];
			if((int)$ticketsucursal['09']>0)
			$ticketssucursaltotal[8] = (int)$ticketsucursal['09'];
			if((int)$ticketsucursal['10']>0)
			$ticketssucursaltotal[9] = (int)$ticketsucursal['10'];
			if((int)$ticketsucursal['11']>0)
			$ticketssucursaltotal[10] = (int) $ticketsucursal['11'];
			if((int)$ticketsucursal['12']>0)
			$ticketssucursaltotal[11] = (int)$ticketsucursal['12'];
			$ticketssucursaltotal[12] += (int)$ticketsucursal['TOTAL'];
			}
		}	
		
			 
		}
		$chart->series[] = array('name' => "Nueva",'data' => $estadoNuevo,'stack' => 'nueva');
		$chart->series[] = array('name' => "Asignada",'data' => $estadoAsignada,'stack' => 'asignada');
		$chart->series[] = array('name' => "Cerrada",'data' => $estadoCerrada,'stack' => 'cerrada');
		$chart->series[] = array('name' => "Rechazada",'data' =>$estadoRechazada ,'stack' => 'rechazada');
				
		}
		
		$this->set('nombremayortickets', $nombremayortickets);
		$this->set('valormayortickets', $valormayortickets);
		$this->set('ticketssucursaltotal', $ticketssucursaltotal);
		$this->loadModel('Sucursals');
		$sucursals = $this->Sucursals->find('list');
		$this->set( compact( 'chart','sucursals' ) );
		
	}
	

	 /**
     * Reporte de Tickets comparativos general
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function reporteticketsgeneral($ano)
    {
		$this->connection = ConnectionManager::get('default');
		
		$consulta = 'CATE';		
		$listadoticketporcategoria = $this->connection->execute("CALL pro_obtener_tickets_general(".$ano.",'".$consulta."')")->fetchAll('assoc');
	
		$ticketscategoriatotalsa = [0,0,0,0,0,0,0,0,0,0,0,0,0];
		$ticketscategoriatotalsanombre='Soporte de Aplicaciones';
		$ticketscategoriatotalsi = [0,0,0,0,0,0,0,0,0,0,0,0,0];
		$ticketscategoriatotalsinombre='Soporte de Infraestructura';
		
		foreach ($listadoticketporcategoria as $ticketcategoria) {

			if($ticketcategoria['nombre']== $ticketscategoriatotalsanombre){

			$ticketscategoriatotalsanombre = $ticketcategoria['nombre'];
			if((int)$ticketcategoria['01']>0)
			$ticketscategoriatotalsa[0] = (int)$ticketcategoria['01'];
			if((int)$ticketcategoria['02']>0)
			$ticketscategoriatotalsa[1] = (int)$ticketcategoria['02'];
			if((int)$ticketcategoria['03']>0)
			$ticketscategoriatotalsa[2] = (int)$ticketcategoria['03'];
			if((int)$ticketcategoria['04']>0)
			$ticketscategoriatotalsa[3] = (int)$ticketcategoria['04'];
			if((int)$ticketcategoria['05']>0)
			$ticketscategoriatotalsa[4] = (int)$ticketcategoria['05'];
			if((int)$ticketcategoria['06']>0)
			$ticketscategoriatotalsa[5] = (int)$ticketcategoria['06'];
			if((int)$ticketcategoria['07']>0)
			$ticketscategoriatotalsa[6] = (int)$ticketcategoria['07'];
			if((int)$ticketcategoria['08']>0)
			$ticketscategoriatotalsa[7] = (int)$ticketcategoria['08'];
			if((int)$ticketcategoria['09']>0)
			$ticketscategoriatotalsa[8] = (int)$ticketcategoria['09'];
			if((int)$ticketcategoria['10']>0)
			$ticketscategoriatotalsa[9] = (int)$ticketcategoria['10'];
			if((int)$ticketcategoria['11']>0)
			$ticketscategoriatotalsa[10] = (int) $ticketcategoria['11'];
			if((int)$ticketcategoria['12']>0)
			$ticketscategoriatotalsa[11] = (int)$ticketcategoria['12'];
			$ticketscategoriatotalsa[12] += (int)$ticketcategoria['TOTAL'];	
		}	

		if($ticketcategoria['nombre']== $ticketscategoriatotalsinombre){

			$ticketscategoriatotalsinombre = $ticketcategoria['nombre'];
			if((int)$ticketcategoria['01']>0)
			$ticketscategoriatotalsi[0] = (int)$ticketcategoria['01'];
			if((int)$ticketcategoria['02']>0)
			$ticketscategoriatotalsi[1] = (int)$ticketcategoria['02'];
			if((int)$ticketcategoria['03']>0)
			$ticketscategoriatotalsi[2] = (int)$ticketcategoria['03'];
			if((int)$ticketcategoria['04']>0)
			$ticketscategoriatotalsi[3] = (int)$ticketcategoria['04'];
			if((int)$ticketcategoria['05']>0)
			$ticketscategoriatotalsi[4] = (int)$ticketcategoria['05'];
			if((int)$ticketcategoria['06']>0)
			$ticketscategoriatotalsi[5] = (int)$ticketcategoria['06'];
			if((int)$ticketcategoria['07']>0)
			$ticketscategoriatotalsi[6] = (int)$ticketcategoria['07'];
			if((int)$ticketcategoria['08']>0)
			$ticketscategoriatotalsi[7] = (int)$ticketcategoria['08'];
			if((int)$ticketcategoria['09']>0)
			$ticketscategoriatotalsi[8] = (int)$ticketcategoria['09'];
			if((int)$ticketcategoria['10']>0)
			$ticketscategoriatotalsi[9] = (int)$ticketcategoria['10'];
			if((int)$ticketcategoria['11']>0)
			$ticketscategoriatotalsi[10] = (int) $ticketcategoria['11'];
			if((int)$ticketcategoria['12']>0)
			$ticketscategoriatotalsi[11] = (int)$ticketcategoria['12'];
			$ticketscategoriatotalsi[12] += (int)$ticketcategoria['TOTAL'];

		}	
	}	

		$this->set('ticketscategoriatotalsa', $ticketscategoriatotalsa);
		$this->set('ticketscategoriatotalsanombre', $ticketscategoriatotalsanombre);
		$this->set('ticketscategoriatotalsi', $ticketscategoriatotalsi);
		$this->set('ticketscategoriatotalsinombre', $ticketscategoriatotalsinombre);
	}
   
}
