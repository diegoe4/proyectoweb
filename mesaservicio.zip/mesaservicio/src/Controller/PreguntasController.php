<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Preguntas Controller
 *
 * @property \App\Model\Table\PreguntasTable $Preguntas
 * @method \App\Model\Entity\Pregunta[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PreguntasController extends AppController
{
    /**
     * List method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function list()
    {
        $this->paginate = [
            'contain' => ['Encuestas'],
        ];
        $preguntas = $this->paginate($this->Preguntas);

        $this->set(compact('preguntas'));
    }

    /**
     * View method
     *
     * @param string|null $id Pregunta id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $pregunta = $this->Preguntas->get($id, [
            'contain' => ['Encuestas', 'Puntajes'],
        ]);

        $this->set(compact('pregunta'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $pregunta = $this->Preguntas->newEmptyEntity();
        if ($this->request->is('post')) {
            $pregunta = $this->Preguntas->patchEntity($pregunta, $this->request->getData());
            if ($this->Preguntas->save($pregunta)) {
                $this->Flash->success(__('La pregunta se creo'));

                return $this->redirect(['action' => 'list']);
            }
            $this->Flash->error(__('La pregunta no pudo ser creado. Intente nuevamente'));
        }
        $encuestas = $this->Preguntas->Encuestas->find('list', ['limit' => 200]);
        $this->set(compact('pregunta', 'encuestas'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Pregunta id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $pregunta = $this->Preguntas->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $pregunta = $this->Preguntas->patchEntity($pregunta, $this->request->getData());
            if ($this->Preguntas->save($pregunta)) {
                $this->Flash->success(__('La pregunta ha sido actualizada'));

                return $this->redirect(['action' => 'list']);
            }
            $this->Flash->error(__('La pregunta no ha sido actualizada. Intente nuevamente'));
        }
        $encuestas = $this->Preguntas->Encuestas->find('list', ['limit' => 200]);
        $this->set(compact('pregunta', 'encuestas'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Pregunta id.
     * @return \Cake\Http\Response|null|void Redirects to list.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $pregunta = $this->Preguntas->get($id);
        if ($this->Preguntas->delete($pregunta)) {
            $this->Flash->success(__('La pregunta ha sido eliminada'));
        } else {
            $this->Flash->error(__('La pregunta no ha sido eliminada. Intente nuevamente'));
        }

        return $this->redirect(['action' => 'list']);
    }
}
