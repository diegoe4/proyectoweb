<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Proyectos Controller
 *
 * @property \App\Model\Table\ProyectosTable $Proyectos
 * @method \App\Model\Entity\Proyecto[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ProyectosController extends AppController
{
    /**
     * List method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function list()
    {
        $proyectos = $this->paginate($this->Proyectos);

        $this->set(compact('proyectos'));
    }

    /**
     * View method
     *
     * @param string|null $id Proyecto id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $proyecto = $this->Proyectos->get($id, [
            'contain' => ['Tickets'],
        ]);

        $this->set(compact('proyecto'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $proyecto = $this->Proyectos->newEmptyEntity();
        if ($this->request->is('post')) {
            $proyecto = $this->Proyectos->patchEntity($proyecto, $this->request->getData());
            if ($this->Proyectos->save($proyecto)) {
                $this->Flash->success(__('El proyecto a sido creado.'));

                return $this->redirect(['action' => 'list']);
            }
            $this->Flash->error(__('El proyecto no ha sido creado. Intente nuevamente.'));
        }
        $this->set(compact('proyecto'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Proyecto id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $proyecto = $this->Proyectos->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $proyecto = $this->Proyectos->patchEntity($proyecto, $this->request->getData());
            if ($this->Proyectos->save($proyecto)) {
                $this->Flash->success(__('El proyecto ha sido actualizado'));

                return $this->redirect(['action' => 'list']);
            }
            $this->Flash->error(__('El proyecto no ha sido actualizado. Intente nuevamente.'));
        }
        $this->set(compact('proyecto'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Proyecto id.
     * @return \Cake\Http\Response|null|void Redirects to list.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $proyecto = $this->Proyectos->get($id);
        if ($this->Proyectos->delete($proyecto)) {
            $this->Flash->success(__('El proyecto ha sido eliminado'));
        } else {
            $this->Flash->error(__('El proyecto no ha sido eliminado. Intente nuevamente'));
        }

        return $this->redirect(['action' => 'list']);
    }
}
