<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * TicketArchivos Controller
 *
 * @property \App\Model\Table\TicketArchivosTable $TicketArchivos
 * @method \App\Model\Entity\TicketArchivo[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class TicketArchivosController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Tickets'],
        ];
        $ticketArchivos = $this->paginate($this->TicketArchivos);

        $this->set(compact('ticketArchivos'));
    }

    /**
     * View method
     *
     * @param string|null $id Ticket Archivo id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $ticketArchivo = $this->TicketArchivos->get($id, [
            'contain' => ['Tickets'],
        ]);

        $this->set(compact('ticketArchivo'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add($ticket_id,$usuario_id)
    {
		$archivo = $this->request->getData()['contenido'];
		$nombreArchivo = $archivo['name'];
		$tamanoArchivo = $archivo['size'];
		$tipoArchivo = $archivo['type'];
		
		
		$fp = fopen($this->request->getData()['contenido']['tmp_name'], "r");						 
		$fileData = fread($fp, $this->request->getData()['contenido']['size']);
		fclose($fp);

        $ticketArchivo = $this->Ticketarchivos->newEmptyEntity();
        if ($this->request->is('post')) {
            $ticketArchivo = $this->Ticketarchivos->patchEntity($ticketArchivo, $this->request->getData());
			
			$ticketArchivo->set('ticket_id', $ticket_id);
			$ticketArchivo->set('nombre',$nombreArchivo);
			$ticketArchivo->set('tamano',$tamanoArchivo);
			$ticketArchivo->set('extension',$tipoArchivo);
			$ticketArchivo->set('user_id', $usuario_id);
			$ticketArchivo->set('contenido', $fileData);
			
            if ($this->Ticketarchivos->save($ticketArchivo)) {
                $this->Flash->success(__('The ticket archivo has been saved.'));

                return $this->redirect('/tickets/view/'. $ticket_id);
            }
            $this->Flash->error(__('The ticket archivo could not be saved. Please, try again.'));
        }
        $tickets = $this->TicketArchivos->Tickets->find('list', ['limit' => 200]);
        $this->set(compact('ticketArchivo', 'tickets'));
    }


	
	public function download($id) {
		$file = $this->Ticketarchivos->get($id, ['contain' => [],]);
		
        $extension= $file['extension'];
        $tamano = $file['tamano'];
        $nombre = $file['nombre'];
		
		
		
		$this->response->body(stream_get_contents($file['contenido'], -1, 0));
		

		
		header("Content-Disposition: inline; filename=".$nombre);
		header("Content-length: ".$tamano);
		header("Content-type: ".$extension);
		echo $base64Data;
		exit;
    }
	
    /**
     * Edit method
     *
     * @param string|null $id Ticket Archivo id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $ticketArchivo = $this->TicketArchivos->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $ticketArchivo = $this->TicketArchivos->patchEntity($ticketArchivo, $this->request->getData());
            if ($this->TicketArchivos->save($ticketArchivo)) {
                $this->Flash->success(__('The ticket archivo has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The ticket archivo could not be saved. Please, try again.'));
        }
        $tickets = $this->TicketArchivos->Tickets->find('list', ['limit' => 200]);
        $this->set(compact('ticketArchivo', 'tickets'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Ticket Archivo id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $ticketArchivo = $this->TicketArchivos->get($id);
        if ($this->TicketArchivos->delete($ticketArchivo)) {
            $this->Flash->success(__('The ticket archivo has been deleted.'));
        } else {
            $this->Flash->error(__('The ticket archivo could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
