<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Sucursals Controller
 *
 * @property \App\Model\Table\SucursalsTable $Sucursals
 * @method \App\Model\Entity\Sucursal[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class SucursalsController extends AppController
{
    /**
     * List method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function list()
    {
        $sucursals = $this->paginate($this->Sucursals);

        $this->set(compact('sucursals'));
    }

    /**
     * View method
     *
     * @param string|null $id Sucursal id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $sucursal = $this->Sucursals->get($id, [
            'contain' => ['Departamentos'],
        ]);

        $this->set(compact('sucursal'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $sucursal = $this->Sucursals->newEmptyEntity();
        if ($this->request->is('post')) {
            $sucursal = $this->Sucursals->patchEntity($sucursal, $this->request->getData());
            if ($this->Sucursals->save($sucursal)) {
                $this->Flash->success(__('La sucursal ha siddo creada.'));

                return $this->redirect(['action' => 'list']);
            }
            $this->Flash->error(__('La sucursal no ha sido creada. Intente nuevamente'));
        }
        $this->set(compact('sucursal'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Sucursal id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $sucursal = $this->Sucursals->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $sucursal = $this->Sucursals->patchEntity($sucursal, $this->request->getData());
            if ($this->Sucursals->save($sucursal)) {
                $this->Flash->success(__('La sucursal ha sido eliminada'));

                return $this->redirect(['action' => 'list']);
            }
            $this->Flash->error(__('La sucursal no ha sido eliminada. Intente nuevamente'));
        }
        $this->set(compact('sucursal'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Sucursal id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $sucursal = $this->Sucursals->get($id);
        if ($this->Sucursals->delete($sucursal)) {
            $this->Flash->success(__('The sucursal has been deleted.'));
        } else {
            $this->Flash->error(__('The sucursal could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
