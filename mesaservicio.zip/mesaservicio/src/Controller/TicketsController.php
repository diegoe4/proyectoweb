<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Tickets Controller
 *
 * @property \App\Model\Table\TicketsTable $Tickets
 * @method \App\Model\Entity\Ticket[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
 
 use CakeDC\Users\Model\Entity;
 
class TicketsController extends AppController
{
    /**
     * List method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function list()
    {
        $this->paginate = [
            'contain' => ['Proyectos', 'Estados', 'Prioridads', 'Users', 'Tipos', 'Subcategorias'],
        ];
        $tickets = $this->paginate($this->Tickets);

        $this->set(compact('tickets'));
    }
	
	
	/**
     * User List  method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function listUser($userId)
    {
        $this->paginate = [
            'contain' => ['Proyectos', 'Estados', 'Prioridads', 'Users', 'Tipos', 'Subcategorias'],
        ];
        $tickets = $this->paginate($this->Tickets->find() ->where(['user_id =' => $userId]));
        $this->set(compact('tickets'));
    }
	

    /**
     * View method
     *
     * @param string|null $id Ticket id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $ticket = $this->Tickets->get($id, [
            'contain' => ['Proyectos', 'Estados', 'Prioridads', 'Users', 'Tipos', 'Subcategorias', 'Comentarios.Users', 'HistoricoCambios.Users', 'Puntajes', 'Seguidores', 'TicketArchivos'],
        ]);

        $this->set(compact('ticket'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add($userId )
    {
        $ticket = $this->Tickets->newEmptyEntity();
		$nuevoEstado = (int)'1';

        if ($this->request->is('post')) {

            $ticket = $this->Tickets->patchEntity($ticket, $this->request->getData());
			$ticket->set('user_id', $userId);
			$ticket->set('estado_id', $nuevoEstado);
            if ($this->Tickets->save($ticket)) {
                $this->Flash->success(__('El ticket ha sido creado'));

                return $this->redirect(['action' => 'list']);
            }
            $this->Flash->error(__('El ticket no ha sido creado. Intente nuevamente.'));
        }
        $proyectos = $this->Tickets->Proyectos->find('list', ['limit' => 200]);
        $estados = $this->Tickets->Estados->find('list', ['limit' => 200]);
        $prioridads = $this->Tickets->Prioridads->find('list', ['limit' => 200]);
        $users = $this->Tickets->Users->find('list', ['limit' => 200]);
        $tipos = $this->Tickets->Tipos->find('list', ['limit' => 200]);
        $subcategorias = $this->Tickets->Subcategorias->find('list', ['limit' => 200]);
        $this->set(compact('ticket', 'proyectos', 'estados', 'prioridads', 'users', 'tipos', 'subcategorias'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Ticket id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null,$userUpdate)
    {
        $ticket = $this->Tickets->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $ticket = $this->Tickets->patchEntity($ticket, $this->request->getData());
			/* Inicio: Guardamos el historico del ticket: Quien hizo el cambio*/
			$dirtyFields = $ticket->getDirty();
			$resultadoOriginal = $ticket->extractOriginalChanged($dirtyFields);
			
			$nuevoTipo = "";
			$nuevoProyecto = "";
			$nuevoEstado = "";
			$nuevaPrioridad = "";
			$nuevaSubcategoria = "";
			$mensajeTotal = "";
		
			/*Tipo de ticket*/
			
			if(isset($resultadoOriginal["tipo_id"])){
				$tipo_id = (int)$resultadoOriginal['tipo_id'];
				$tipoModificado = $this->Tickets->Tipos->get($tipo_id, ['contain' => [],]);
				$tipoOriginal = $this->Tickets->Tipos->get($ticket->get('tipo_id'), ['contain' => [],]);
				$nuevoTipo = "Se cambio de Tipo: ".$tipoModificado->nombre." a Tipo: ".$tipoOriginal->nombre;
			}
			/*Proyecto de ticket*/
			if(isset($resultadoOriginal["proyecto_id"])){
				$proyecto_id = (int)$resultadoOriginal['proyecto_id'];
				$proyectoModificado = $this->Tickets->Proyectos->get($proyecto_id, ['contain' => [],]);
				$proyectoOriginal = $this->Tickets->Proyectos->get($ticket->get('proyecto_id'), ['contain' => [],]);
				$nuevoProyecto = "Se cambio de Proyecto: ".$proyectoModificado->nombre." a Proyecto: ".$proyectoOriginal->nombre;
			}
			/*Estado de ticket*/
			if(isset($resultadoOriginal["estado_id"])){
				$estado_id = (int)$resultadoOriginal['estado_id'];
				$estadoModificado = $this->Tickets->Estados->get($estado_id, ['contain' => [],]);
				$estadoOriginal = $this->Tickets->Estados->get($ticket->get('estado_id'), ['contain' => [],]);
				$nuevoEstado = "Se cambio de Estado: ".$estadoModificado->nombre." a Estado: ".$estadoOriginal->nombre;
			}
			/*Prioridad de ticket*/
			if(isset($resultadoOriginal["prioridad_id"])){
				$prioridad_id = (int)$resultadoOriginal['prioridad_id'];
				$prioridadModificado = $this->Tickets->Prioridads->get($prioridad_id, ['contain' => [],]);
				$prioridadOriginal = $this->Tickets->Prioridads->get($ticket->get('prioridad_id'), ['contain' => [],]);
				$nuevaPrioridad = "Se cambio de Prioridad: ".$prioridadModificado->nombre." a Prioridad: ".$prioridadOriginal->nombre;
			}
			/*Subcategoria de ticket*/
			if(isset($resultadoOriginal["subcategoria_id"])){
				$subcategoria_id = (int)$resultadoOriginal['subcategoria_id'];
				$subcategoriaModificado = $this->Tickets->Subcategorias->get($subcategoria_id, ['contain' => [],]);
				$subcategoriaOriginal = $this->Tickets->Subcategorias->get($ticket->get('subcategoria_id'), ['contain' => [],]);
				$nuevaSubcategoria = "Se cambio de Subcategoria: ".$subcategoriaModificado->nombre." a Subcategoria: ".$subcategoriaOriginal->nombre;
			}
			
						
			$mensajeTotal = $nuevoTipo.' '.$nuevoProyecto.' '.$nuevoEstado.' '.$nuevaPrioridad.' '.$nuevaSubcategoria;	
				
		
			
            if ($this->Tickets->save($ticket)) {

				/* Inicio: Guardamos el historico del ticket: Quien hizo el cambio*/
				$this->loadModel('HistoricoCambios');
				$historicoCambio = $this->HistoricoCambios->newEmptyEntity();
				$historicoCambio->set('user_id',$userUpdate );
				$historicoCambio->set('ticket_id',$ticket->get('id'));
				$historicoCambio->set('cambio','Cambio realizado en lo siguiente:'.$mensajeTotal );
				
				
				
				
				
				
				$this->HistoricoCambios->save($historicoCambio);
				/* Fin: Guardamos el historico del ticket: Quien hizo el cambio*/
                $this->Flash->success(__('El ticket ha sido actualizado'));

                return $this->redirect(['action' => 'list']);
            }
            $this->Flash->error(__('El ticket no ha sido actilizado. Intente nuevamente'));
        }
        $proyectos = $this->Tickets->Proyectos->find('list', ['limit' => 200]);
        $estados = $this->Tickets->Estados->find('list', ['limit' => 200]);
        $prioridads = $this->Tickets->Prioridads->find('list', ['limit' => 200]);
        $users = $this->Tickets->Users->find('list', ['limit' => 200]);
        $tipos = $this->Tickets->Tipos->find('list', ['limit' => 200]);
        $subcategorias = $this->Tickets->Subcategorias->find('list', ['limit' => 200]);
        $this->set(compact('ticket', 'proyectos', 'estados', 'prioridads', 'users', 'tipos', 'subcategorias'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Ticket id.
     * @return \Cake\Http\Response|null|void Redirects to list.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $ticket = $this->Tickets->get($id);
        if ($this->Tickets->delete($ticket)) {
            $this->Flash->success(__('El ticket ha sido eliminado.'));
        } else {
            $this->Flash->error(__('El ticket no ha sido eliminado. Intente nuevamente'));
        }

        return $this->redirect(['action' => 'list']);
    }
}
