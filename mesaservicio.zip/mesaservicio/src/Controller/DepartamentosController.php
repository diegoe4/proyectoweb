<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Departamentos Controller
 *
 * @property \App\Model\Table\DepartamentosTable $Departamentos
 * @method \App\Model\Entity\Departamento[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class DepartamentosController extends AppController
{
    /**
     * List method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function list()
    {
        $this->paginate = [
            'contain' => ['Empresas', 'Sucursals'],
        ];
        $departamentos = $this->paginate($this->Departamentos);

        $this->set(compact('departamentos'));
    }

    /**
     * View method
     *
     * @param string|null $id Departamento id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $departamento = $this->Departamentos->get($id, [
            'contain' => ['Empresas', 'Sucursals', 'Areas', 'Encuestas'],
        ]);

        $this->set(compact('departamento'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $departamento = $this->Departamentos->newEmptyEntity();
        if ($this->request->is('post')) {
            $departamento = $this->Departamentos->patchEntity($departamento, $this->request->getData());
            if ($this->Departamentos->save($departamento)) {
                $this->Flash->success(__('El departamento ha sido creado'));

                return $this->redirect(['action' => 'list']);
            }
            $this->Flash->error(__('El departamento no se ha creado. Intente nuevamente'));
        }
        $empresas = $this->Departamentos->Empresas->find('list', ['limit' => 200]);
        $sucursals = $this->Departamentos->Sucursals->find('list', ['limit' => 200]);
        $this->set(compact('departamento', 'empresas', 'sucursals'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Departamento id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $departamento = $this->Departamentos->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $departamento = $this->Departamentos->patchEntity($departamento, $this->request->getData());
            if ($this->Departamentos->save($departamento)) {
                $this->Flash->success(__('El departamento ha sido actualizado'));

                return $this->redirect(['action' => 'list']);
            }
            $this->Flash->error(__('El departamento ha sido actualizado. Intente nuevamente'));
        }
        $empresas = $this->Departamentos->Empresas->find('list', ['limit' => 200]);
        $sucursals = $this->Departamentos->Sucursals->find('list', ['limit' => 200]);
        $this->set(compact('departamento', 'empresas', 'sucursals'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Departamento id.
     * @return \Cake\Http\Response|null|void Redirects to list.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $departamento = $this->Departamentos->get($id);
        if ($this->Departamentos->delete($departamento)) {
            $this->Flash->success(__('El departemento ha sido eliminado.'));
        } else {
            $this->Flash->error(__('El departamento no ha sido eliminado. Intente nuevamente'));
        }

        return $this->redirect(['action' => 'list']);
    }
}
