<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * ComentarioArchivos Controller
 *
 * @property \App\Model\Table\ComentarioArchivosTable $ComentarioArchivos
 * @method \App\Model\Entity\ComentarioArchivo[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ComentarioArchivosController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Comentarios'],
        ];
        $comentarioArchivos = $this->paginate($this->ComentarioArchivos);

        $this->set(compact('comentarioArchivos'));
    }

    /**
     * View method
     *
     * @param string|null $id Comentario Archivo id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $comentarioArchivo = $this->ComentarioArchivos->get($id, [
            'contain' => ['Comentarios'],
        ]);

        $this->set(compact('comentarioArchivo'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $comentarioArchivo = $this->ComentarioArchivos->newEmptyEntity();
        if ($this->request->is('post')) {
            $comentarioArchivo = $this->ComentarioArchivos->patchEntity($comentarioArchivo, $this->request->getData());
            if ($this->ComentarioArchivos->save($comentarioArchivo)) {
                $this->Flash->success(__('The comentario archivo has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The comentario archivo could not be saved. Please, try again.'));
        }
        $comentarios = $this->ComentarioArchivos->Comentarios->find('list', ['limit' => 200]);
        $this->set(compact('comentarioArchivo', 'comentarios'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Comentario Archivo id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $comentarioArchivo = $this->ComentarioArchivos->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $comentarioArchivo = $this->ComentarioArchivos->patchEntity($comentarioArchivo, $this->request->getData());
            if ($this->ComentarioArchivos->save($comentarioArchivo)) {
                $this->Flash->success(__('The comentario archivo has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The comentario archivo could not be saved. Please, try again.'));
        }
        $comentarios = $this->ComentarioArchivos->Comentarios->find('list', ['limit' => 200]);
        $this->set(compact('comentarioArchivo', 'comentarios'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Comentario Archivo id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $comentarioArchivo = $this->ComentarioArchivos->get($id);
        if ($this->ComentarioArchivos->delete($comentarioArchivo)) {
            $this->Flash->success(__('The comentario archivo has been deleted.'));
        } else {
            $this->Flash->error(__('The comentario archivo could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
