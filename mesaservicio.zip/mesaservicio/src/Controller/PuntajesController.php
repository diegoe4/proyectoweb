<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Puntajes Controller
 *
 * @property \App\Model\Table\PuntajesTable $Puntajes
 * @method \App\Model\Entity\Puntaje[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PuntajesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function list()
    {
        $this->paginate = [
            'contain' => ['Preguntas', 'Tickets'],
        ];
        $puntajes = $this->paginate($this->Puntajes);

        $this->set(compact('puntajes'));
    }

    /**
     * View method
     *
     * @param string|null $id Puntaje id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $puntaje = $this->Puntajes->get($id, [
            'contain' => ['Preguntas', 'Tickets'],
        ]);

        $this->set(compact('puntaje'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $puntaje = $this->Puntajes->newEmptyEntity();
        if ($this->request->is('post')) {
            $puntaje = $this->Puntajes->patchEntity($puntaje, $this->request->getData());
            if ($this->Puntajes->save($puntaje)) {
                $this->Flash->success(__('The puntaje has been saved.'));

                return $this->redirect(['action' => 'list']);
            }
            $this->Flash->error(__('The puntaje could not be saved. Please, try again.'));
        }
        $preguntas = $this->Puntajes->Preguntas->find('list', ['limit' => 200]);
        $tickets = $this->Puntajes->Tickets->find('list', ['limit' => 200]);
        $this->set(compact('puntaje', 'preguntas', 'tickets'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Puntaje id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $puntaje = $this->Puntajes->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $puntaje = $this->Puntajes->patchEntity($puntaje, $this->request->getData());
            if ($this->Puntajes->save($puntaje)) {
                $this->Flash->success(__('The puntaje has been saved.'));

                return $this->redirect(['action' => 'list']);
            }
            $this->Flash->error(__('The puntaje could not be saved. Please, try again.'));
        }
        $preguntas = $this->Puntajes->Preguntas->find('list', ['limit' => 200]);
        $tickets = $this->Puntajes->Tickets->find('list', ['limit' => 200]);
        $this->set(compact('puntaje', 'preguntas', 'tickets'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Puntaje id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $puntaje = $this->Puntajes->get($id);
        if ($this->Puntajes->delete($puntaje)) {
            $this->Flash->success(__('The puntaje has been deleted.'));
        } else {
            $this->Flash->error(__('The puntaje could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
