<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Encuestas Controller
 *
 * @property \App\Model\Table\EncuestasTable $Encuestas
 * @method \App\Model\Entity\Encuesta[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class EncuestasController extends AppController
{
    /**
     * List method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function list()
    {
        $this->paginate = [
            'contain' => ['Departamentos'],
        ];
        $encuestas = $this->paginate($this->Encuestas);

        $this->set(compact('encuestas'));
    }

    /**
     * View method
     *
     * @param string|null $id Encuesta id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $encuesta = $this->Encuestas->get($id, [
            'contain' => ['Departamentos', 'Preguntas'],
        ]);

        $this->set(compact('encuesta'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $encuesta = $this->Encuestas->newEmptyEntity();
        if ($this->request->is('post')) {
            $encuesta = $this->Encuestas->patchEntity($encuesta, $this->request->getData());
            if ($this->Encuestas->save($encuesta)) {
                $this->Flash->success(__('La encuesta ha sido creada'));

                return $this->redirect(['action' => 'list']);
            }
            $this->Flash->error(__('La encuesta no has sido creada. Intente nuevamente'));
        }
        $departamentos = $this->Encuestas->Departamentos->find('list', ['limit' => 200]);
        $this->set(compact('encuesta', 'departamentos'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Encuesta id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $encuesta = $this->Encuestas->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $encuesta = $this->Encuestas->patchEntity($encuesta, $this->request->getData());
            if ($this->Encuestas->save($encuesta)) {
                $this->Flash->success(__('La encuesta ha sido actualizada'));

                return $this->redirect(['action' => 'list']);
            }
            $this->Flash->error(__('La encuesta no ha sido actualizada. Intente nuevamente'));
        }
        $departamentos = $this->Encuestas->Departamentos->find('list', ['limit' => 200]);
        $this->set(compact('encuesta', 'departamentos'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Encuesta id.
     * @return \Cake\Http\Response|null|void Redirects to list.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $encuesta = $this->Encuestas->get($id);
        if ($this->Encuestas->delete($encuesta)) {
            $this->Flash->success(__('La encuesta ha sido eliminada'));
        } else {
            $this->Flash->error(__('La encuesta no ha sido eliminada. Intente nuevamente'));
        }

        return $this->redirect(['action' => 'list']);
    }
}
