<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * HistoricoCambios Controller
 *
 * @property \App\Model\Table\HistoricoCambiosTable $HistoricoCambios
 * @method \App\Model\Entity\HistoricoCambio[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class HistoricoCambiosController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Tickets', 'Comentarios'],
        ];
        $historicoCambios = $this->paginate($this->HistoricoCambios);

        $this->set(compact('historicoCambios'));
    }

    /**
     * View method
     *
     * @param string|null $id Historico Cambio id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $historicoCambio = $this->HistoricoCambios->get($id, [
            'contain' => ['Tickets', 'Comentarios'],
        ]);

        $this->set(compact('historicoCambio'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $historicoCambio = $this->HistoricoCambios->newEmptyEntity();
        if ($this->request->is('post')) {
            $historicoCambio = $this->HistoricoCambios->patchEntity($historicoCambio, $this->request->getData());
            if ($this->HistoricoCambios->save($historicoCambio)) {
                $this->Flash->success(__('The historico cambio has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The historico cambio could not be saved. Please, try again.'));
        }
        $tickets = $this->HistoricoCambios->Tickets->find('list', ['limit' => 200]);
        $comentarios = $this->HistoricoCambios->Comentarios->find('list', ['limit' => 200]);
        $this->set(compact('historicoCambio', 'tickets', 'comentarios'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Historico Cambio id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $historicoCambio = $this->HistoricoCambios->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $historicoCambio = $this->HistoricoCambios->patchEntity($historicoCambio, $this->request->getData());
            if ($this->HistoricoCambios->save($historicoCambio)) {
                $this->Flash->success(__('The historico cambio has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The historico cambio could not be saved. Please, try again.'));
        }
        $tickets = $this->HistoricoCambios->Tickets->find('list', ['limit' => 200]);
        $comentarios = $this->HistoricoCambios->Comentarios->find('list', ['limit' => 200]);
        $this->set(compact('historicoCambio', 'tickets', 'comentarios'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Historico Cambio id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $historicoCambio = $this->HistoricoCambios->get($id);
        if ($this->HistoricoCambios->delete($historicoCambio)) {
            $this->Flash->success(__('The historico cambio has been deleted.'));
        } else {
            $this->Flash->error(__('The historico cambio could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
