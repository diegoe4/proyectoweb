<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Subcategoria[]|\Cake\Collection\CollectionInterface $subcategorias
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>
<div class="subcategorias index content">
    <?= $this->Html->link(__('Nueva Subcategoria'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Subcategorias') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('categoria_id') ?></th>
                    <th><?= $this->Paginator->sort('nombre') ?></th>
                    <th><?= $this->Paginator->sort('descripcion') ?></th>
                    <th><?= $this->Paginator->sort('activo') ?></th>
                    <th><?= $this->Paginator->sort('fecha_creacion') ?></th>
                    <th class="actions"><?= __('Acciones') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($subcategorias as $subcategoria): ?>
                <tr>
                    <td><?= $this->Number->format($subcategoria->id) ?></td>
                    <td><?= $subcategoria->has('categoria') ? $this->Html->link($subcategoria->categoria->id, ['controller' => 'Categorias', 'action' => 'view', $subcategoria->categoria->id]) : '' ?></td>
                    <td><?= h($subcategoria->nombre) ?></td>
                    <td><?= h($subcategoria->descripcion) ?></td>
                    <td><?= h($subcategoria->activo) ?></td>
                    <td><?= h($subcategoria->fecha_creacion) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('Ver'), ['action' => 'view', $subcategoria->id]) ?>
                        <?= $this->Html->link(__('Editar'), ['action' => 'edit', $subcategoria->id]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('primero')) ?>
            <?= $this->Paginator->prev('< ' . __('previo')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('siguiente') . ' >') ?>
            <?= $this->Paginator->last(__('ultimo') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Pagina {{page}} de {{pages}}, mostrando {{current}} registros(s) de un total de {{count}}')) ?></p>
    </div>
</div>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>
