<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Subcategoria $subcategoria
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>


    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
            <?= $this->Html->link(__('Listado de Subcategorias'), ['action' => 'list'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
	</br>
    <div class="column-responsive column-80">
        <div class="subcategorias form content">
            <?= $this->Form->create($subcategoria) ?>
            <fieldset>
                <legend><?= __('Agregar Subcategoria') ?></legend>
                <?php
                    echo $this->Form->control('categoria_id', ['options' => $categorias], ['label' => __d('cake_d_c/users', 'Categoria')]);
                    echo $this->Form->control('nombre', ['label' => __d('cake_d_c/users', 'Nombre')]);
                    echo $this->Form->control('descripcion', ['label' => __d('cake_d_c/users', 'Descripción')]);
                    echo $this->Form->control('activo', ['label' => __d('cake_d_c/users', 'Activo')]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Enviar')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>

<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>