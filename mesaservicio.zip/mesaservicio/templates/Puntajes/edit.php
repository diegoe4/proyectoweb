<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Puntaje $puntaje
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>

    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Acciones') ?></h4>
            
            <?= $this->Html->link(__('List Puntajes'), ['action' => 'list'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="puntajes form content">
            <?= $this->Form->create($puntaje) ?>
            <fieldset>
                <legend><?= __('Editar un Puntaje') ?></legend>
                <?php
                    echo $this->Form->control('pregunta_id', ['options' => $preguntas]);
                    echo $this->Form->control('ticket_id', ['options' => $tickets]);
                    echo $this->Form->control('calificacion');
                    echo $this->Form->control('explicacion');
                    echo $this->Form->control('fecha_creacion');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Enviar')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
    <?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>

