<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Puntaje[]|\Cake\Collection\CollectionInterface $puntajes
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>

<div class="puntajes index content">
    <?= $this->Html->link(__('Nuevo Puntaje'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Puntajes') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('pregunta_id') ?></th>
                    <th><?= $this->Paginator->sort('ticket_id') ?></th>
                    <th><?= $this->Paginator->sort('calificacion') ?></th>
                    <th><?= $this->Paginator->sort('explicacion') ?></th>
                    <th><?= $this->Paginator->sort('fecha_creacion') ?></th>
                    <th class="actions"><?= __('Acciones') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($puntajes as $puntaje): ?>
                <tr>
                    <td><?= $this->Number->format($puntaje->id) ?></td>
                    <td><?= $puntaje->has('pregunta') ? $this->Html->link($puntaje->pregunta->id, ['controller' => 'Preguntas', 'action' => 'view', $puntaje->pregunta->id]) : '' ?></td>
                    <td><?= $puntaje->has('ticket') ? $this->Html->link($puntaje->ticket->id, ['controller' => 'Tickets', 'action' => 'view', $puntaje->ticket->id]) : '' ?></td>
                    <td><?= $this->Number->format($puntaje->calificacion) ?></td>
                    <td><?= h($puntaje->explicacion) ?></td>
                    <td><?= h($puntaje->fecha_creacion) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('Ver'), ['action' => 'view', $puntaje->id]) ?>
                        <?= $this->Html->link(__('Editar'), ['action' => 'edit', $puntaje->id]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('primero')) ?>
            <?= $this->Paginator->prev('< ' . __('previo')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('siguiente') . ' >') ?>
            <?= $this->Paginator->last(__('ultimo') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Pagina {{page}} de {{pages}}, mostrando {{current}} registros(s) de un total de {{count}}')) ?></p>
    </div>
</div>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>