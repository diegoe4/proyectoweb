<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Puntaje $puntaje
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>

    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
          
            <?= $this->Html->link(__('Listado de Puntajes'), ['action' => 'list'], ['class' => 'side-nav-item']) ?>
            
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="puntajes view content">
            <h3><?= h($puntaje->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Pregunta') ?></th>
                    <td><?= $puntaje->has('pregunta') ? $this->Html->link($puntaje->pregunta->id, ['controller' => 'Preguntas', 'action' => 'view', $puntaje->pregunta->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Ticket') ?></th>
                    <td><?= $puntaje->has('ticket') ? $this->Html->link($puntaje->ticket->id, ['controller' => 'Tickets', 'action' => 'view', $puntaje->ticket->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Explicacion') ?></th>
                    <td><?= h($puntaje->explicacion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($puntaje->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Calificacion') ?></th>
                    <td><?= $this->Number->format($puntaje->calificacion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Fecha Creacion') ?></th>
                    <td><?= h($puntaje->fecha_creacion) ?></td>
                </tr>
            </table>
        </div>
    </div>

    <?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>
