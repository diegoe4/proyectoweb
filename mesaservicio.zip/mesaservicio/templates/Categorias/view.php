<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Categoria $categoria
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>


    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
            <?= $this->Html->link(__('Listado de Categorias'), ['action' => 'list'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
	</br>
    <div class="column-responsive column-80">
        <div class="categorias view content">
            <table>
                <tr>
                    <th><?= __('Nombre') ?></th>
                    <td><?= h($categoria->nombre) ?></td>
                </tr>
                <tr>
                    <th><?= __('Descripcion') ?></th>
                    <td><?= h($categoria->descripcion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($categoria->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Fecha Creacion') ?></th>
                    <td><?= h($categoria->fecha_creacion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Activo') ?></th>
                    <td><?= $categoria->activo ? __('Si') : __('No'); ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Subcategorias Relacionadas') ?></h4>
                <?php if (!empty($categoria->subcategorias)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Categoria Id') ?></th>
                            <th><?= __('Nombre') ?></th>
                            <th><?= __('Descripcion') ?></th>
                            <th><?= __('Activo') ?></th>
                            <th><?= __('Fecha Creacion') ?></th>
                            <th class="actions"><?= __('Acciones') ?></th>
                        </tr>
                        <?php foreach ($categoria->subcategorias as $subcategorias) : ?>
                        <tr>
                            <td><?= h($subcategorias->id) ?></td>
                            <td><?= h($subcategorias->categoria_id) ?></td>
                            <td><?= h($subcategorias->nombre) ?></td>
                            <td><?= h($subcategorias->descripcion) ?></td>
                            <td><?= h($subcategorias->activo) ?></td>
                            <td><?= h($subcategorias->fecha_creacion) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('Ver'), ['controller' => 'Subcategorias', 'action' => 'view', $subcategorias->id]) ?>
                                <?= $this->Html->link(__('Editar'), ['controller' => 'Subcategorias', 'action' => 'edit', $subcategorias->id]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>