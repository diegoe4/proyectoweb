<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Empleado $empleado
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>

    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
            <?= $this->Html->link(__('Listado de Empleados'), ['action' => 'list'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
	</br>
    <div class="column-responsive column-80">
        <div class="empleados form content">
            <?= $this->Form->create($empleado) ?>
            <fieldset>
                <legend><?= __('Editar Empleado') ?></legend>
                <?php
                    echo $this->Form->control('user_id', ['options' => $users,'label' => __d('cake_d_c/users', 'Usuario')]);
                    echo $this->Form->control('area_id', ['options' => $areas]);
                    echo $this->Form->control('fecha_ingreso');
                    echo $this->Form->control('cargo');
                    echo $this->Form->control('jefe');
                ?>
            </fieldset>
			</br>
            <?= $this->Form->button(__('Enviar')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>
