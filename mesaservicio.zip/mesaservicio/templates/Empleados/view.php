<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Empleado $empleado
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>


    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
            <?= $this->Html->link(__('Listado de Empleados'), ['action' => 'list'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
	</br>
    <div class="column-responsive column-80">
        <div class="empleados view content">
            <h3><?= h($empleado->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('User') ?></th>
                    <td><?= $empleado->has('user') ? $this->Html->link($empleado->user->id, ['controller' => 'Users', 'action' => 'view', $empleado->user->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Area') ?></th>
                    <td><?= $empleado->has('area') ? $this->Html->link($empleado->area->nombre, ['controller' => 'Areas', 'action' => 'view', $empleado->area->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Cargo') ?></th>
                    <td><?= h($empleado->cargo) ?></td>
                </tr>
                <tr>
                    <th><?= __('Jefe') ?></th>
                    <td><?= h($empleado->jefe) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($empleado->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Fecha Creacion') ?></th>
                    <td><?= h($empleado->fecha_creacion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Fecha Ingreso') ?></th>
                    <td><?= h($empleado->fecha_ingreso) ?></td>
                </tr>
            </table>
        </div>
    </div>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>
