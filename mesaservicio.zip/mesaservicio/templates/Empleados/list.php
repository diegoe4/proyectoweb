<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Empleado[]|\Cake\Collection\CollectionInterface $empleados
 */
?>

<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>


<div class="empleados index content">
    <?= $this->Html->link(__('Nuevo Empleado'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Empleados') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('Usuario') ?></th>
                    <th><?= $this->Paginator->sort('Area') ?></th>
                    <th><?= $this->Paginator->sort('Fecha creación') ?></th>
                    <th><?= $this->Paginator->sort('Fecha Ingreso') ?></th>
                    <th><?= $this->Paginator->sort('Cargo') ?></th>
                    <th><?= $this->Paginator->sort('Jefe') ?></th>
                    <th class="actions"><?= __('Acciones') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($empleados as $empleado): ?>
                <tr>
                    <td><?= $this->Number->format($empleado->id) ?></td>
                    <td><?= h($empleado->user ->first_name.' '.$empleado->user ->last_name)?></td>
                    <td><?= h($empleado->area->nombre) ?></td>
                    <td><?= h($empleado->fecha_creacion) ?></td>
                    <td><?= h($empleado->fecha_ingreso) ?></td>
                    <td><?= h($empleado->cargo) ?></td>
                    <td><?= h($empleado->jefe) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('Ver'), ['action' => 'view', $empleado->id]) ?>
                        <?= $this->Html->link(__('Editar'), ['action' => 'edit', $empleado->id]) ?>                      
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('primero')) ?>
            <?= $this->Paginator->prev('< ' . __('previo')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('siguiente') . ' >') ?>
            <?= $this->Paginator->last(__('ultimo') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Pagina {{page}} de {{pages}}, mostrando {{current}} registros(s) de un total de {{count}}')) ?></p>
    </div>
</div>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>

