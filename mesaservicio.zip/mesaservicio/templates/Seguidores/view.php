<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Seguidore $seguidore
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Seguidore'), ['action' => 'edit', $seguidore->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Seguidore'), ['action' => 'delete', $seguidore->id], ['confirm' => __('Are you sure you want to delete # {0}?', $seguidore->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Seguidores'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Seguidore'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="seguidores view content">
            <h3><?= h($seguidore->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('User') ?></th>
                    <td><?= $seguidore->has('user') ? $this->Html->link($seguidore->user->id, ['controller' => 'Users', 'action' => 'view', $seguidore->user->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Ticket') ?></th>
                    <td><?= $seguidore->has('ticket') ? $this->Html->link($seguidore->ticket->id, ['controller' => 'Tickets', 'action' => 'view', $seguidore->ticket->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($seguidore->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Fecha Creacion') ?></th>
                    <td><?= h($seguidore->fecha_creacion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Activo') ?></th>
                    <td><?= $seguidore->activo ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
