<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Seguidore[]|\Cake\Collection\CollectionInterface $seguidores
 */
?>
<div class="seguidores index content">
    <?= $this->Html->link(__('New Seguidore'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Seguidores') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('usuario_id') ?></th>
                    <th><?= $this->Paginator->sort('ticket_id') ?></th>
                    <th><?= $this->Paginator->sort('fecha_creacion') ?></th>
                    <th><?= $this->Paginator->sort('activo') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($seguidores as $seguidore): ?>
                <tr>
                    <td><?= $this->Number->format($seguidore->id) ?></td>
                    <td><?= $seguidore->has('user') ? $this->Html->link($seguidore->user->id, ['controller' => 'Users', 'action' => 'view', $seguidore->user->id]) : '' ?></td>
                    <td><?= $seguidore->has('ticket') ? $this->Html->link($seguidore->ticket->id, ['controller' => 'Tickets', 'action' => 'view', $seguidore->ticket->id]) : '' ?></td>
                    <td><?= h($seguidore->fecha_creacion) ?></td>
                    <td><?= h($seguidore->activo) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $seguidore->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $seguidore->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $seguidore->id], ['confirm' => __('Are you sure you want to delete # {0}?', $seguidore->id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
