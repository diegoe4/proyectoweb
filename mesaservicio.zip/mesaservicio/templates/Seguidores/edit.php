<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Seguidore $seguidore
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $seguidore->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $seguidore->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Seguidores'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="seguidores form content">
            <?= $this->Form->create($seguidore) ?>
            <fieldset>
                <legend><?= __('Edit Seguidore') ?></legend>
                <?php
                    echo $this->Form->control('usuario_id', ['options' => $users]);
                    echo $this->Form->control('ticket_id', ['options' => $tickets]);
                    echo $this->Form->control('fecha_creacion');
                    echo $this->Form->control('activo');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
