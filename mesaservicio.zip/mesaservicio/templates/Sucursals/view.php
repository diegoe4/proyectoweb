<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Sucursal $sucursal
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
            <?= $this->Html->link(__('Listado de Sucursales'), ['action' => 'list'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
	</br>
    <div class="column-responsive column-80">
        <div class="sucursals view content">
            <table>
                <tr>
                    <th><?= __('Nombre') ?></th>
                    <td><?= h($sucursal->nombre) ?></td>
                </tr>
                <tr>
                    <th><?= __('Descripcion') ?></th>
                    <td><?= h($sucursal->descripcion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($sucursal->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Fecha Creacion') ?></th>
                    <td><?= h($sucursal->fecha_creacion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Activo') ?></th>
                    <td><?= $sucursal->activo ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Departamentos Relacionados') ?></h4>
                <?php if (!empty($sucursal->departamentos)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Nombre') ?></th>
                            <th><?= __('Descripcion') ?></th>
                            <th><?= __('Empresa Id') ?></th>
                            <th><?= __('Sucursal Id') ?></th>
                            <th><?= __('Activo') ?></th>
                            <th><?= __('Fecha Creacion') ?></th>
                            <th class="actions"><?= __('Acciones') ?></th>
                        </tr>
                        <?php foreach ($sucursal->departamentos as $departamentos) : ?>
                        <tr>
                            <td><?= h($departamentos->id) ?></td>
                            <td><?= h($departamentos->nombre) ?></td>
                            <td><?= h($departamentos->descripcion) ?></td>
                            <td><?= h($departamentos->empresa_id) ?></td>
                            <td><?= h($departamentos->sucursal_id) ?></td>
                            <td><?= h($departamentos->activo) ?></td>
                            <td><?= h($departamentos->fecha_creacion) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('Ver'), ['controller' => 'Departamentos', 'action' => 'view', $departamentos->id]) ?>
                                <?= $this->Html->link(__('Editar'), ['controller' => 'Departamentos', 'action' => 'edit', $departamentos->id]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>