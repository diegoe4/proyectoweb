<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Sucursal[]|\Cake\Collection\CollectionInterface $sucursals
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>
<div class="sucursals index content">
    <?= $this->Html->link(__('Nueva Sucursal'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Sucursales') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('nombre') ?></th>
                    <th><?= $this->Paginator->sort('descripcion') ?></th>
					<th><?= $this->Paginator->sort('direccion') ?></th>
					<th><?= $this->Paginator->sort('telefono') ?></th>
					<th><?= $this->Paginator->sort('numero empleados') ?></th>
                    <th><?= $this->Paginator->sort('activo') ?></th>
                    <th><?= $this->Paginator->sort('fecha_creacion') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($sucursals as $sucursal): ?>
                <tr>
                    <td><?= $this->Number->format($sucursal->id) ?></td>
                    <td><?= h($sucursal->nombre) ?></td>
                    <td><?= h($sucursal->descripcion) ?></td>
					<td><?= h($sucursal->direccion) ?></td>
					<td><?= h($sucursal->telefono) ?></td>
					<td><?= h($sucursal->numero_empleados) ?></td>
                    <td><?= h($sucursal->activo) ?></td>
                    <td><?= h($sucursal->fecha_creacion) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('Ver'), ['action' => 'view', $sucursal->id]) ?>
                        <?= $this->Html->link(__('Editar'), ['action' => 'edit', $sucursal->id]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('primero')) ?>
            <?= $this->Paginator->prev('< ' . __('previo')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('siguiente') . ' >') ?>
            <?= $this->Paginator->last(__('ultimo') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Pagina {{page}} de {{pages}}, mostrando {{current}} registros(s) de un total de {{count}}')) ?></p>
    </div>
</div>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>
