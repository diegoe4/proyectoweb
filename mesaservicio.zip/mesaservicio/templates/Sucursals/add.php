<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Sucursal $sucursal
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>

    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
            <?= $this->Html->link(__('Listado de Sucursales'), ['action' => 'list'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
	</br>
    <div class="column-responsive column-80">
        <div class="sucursals form content">
            <?= $this->Form->create($sucursal) ?>
            <fieldset>
                <legend><?= __('Agregar Sucursal') ?></legend>
                <?php
                     echo $this->Form->control('nombre', ['label' => __d('cake_d_c/users', 'Nombre')]);
                    echo $this->Form->control('descripcion', ['label' => __d('cake_d_c/users', 'Descripción')]);
					echo $this->Form->control('direccion', ['label' => __d('cake_d_c/users', 'Dirección')]);
					echo $this->Form->control('telefono', ['label' => __d('cake_d_c/users', 'Teléfono')]);
					echo $this->Form->control('numero_empleados', ['label' => __d('cake_d_c/users', 'Número de empleados')]);
                    echo $this->Form->control('activo', ['label' => __d('cake_d_c/users', 'Activo')]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Enviar')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>

<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>