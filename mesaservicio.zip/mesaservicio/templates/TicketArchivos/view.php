<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\TicketArchivo $ticketArchivo
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Ticket Archivo'), ['action' => 'edit', $ticketArchivo->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Ticket Archivo'), ['action' => 'delete', $ticketArchivo->id], ['confirm' => __('Are you sure you want to delete # {0}?', $ticketArchivo->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Ticket Archivos'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Ticket Archivo'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="ticketArchivos view content">
            <h3><?= h($ticketArchivo->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Nombre') ?></th>
                    <td><?= h($ticketArchivo->nombre) ?></td>
                </tr>
                <tr>
                    <th><?= __('Extension') ?></th>
                    <td><?= h($ticketArchivo->extension) ?></td>
                </tr>
                <tr>
                    <th><?= __('Ticket') ?></th>
                    <td><?= $ticketArchivo->has('ticket') ? $this->Html->link($ticketArchivo->ticket->id, ['controller' => 'Tickets', 'action' => 'view', $ticketArchivo->ticket->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($ticketArchivo->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Tamano') ?></th>
                    <td><?= $this->Number->format($ticketArchivo->tamano) ?></td>
                </tr>
                <tr>
                    <th><?= __('Fecha Creacion') ?></th>
                    <td><?= h($ticketArchivo->fecha_creacion) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
