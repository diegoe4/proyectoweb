<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Ticket $ticket
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';

?>


    
	</br>
    <div class="column-responsive column-80">
        <div class="tickets view content">
            <table>
                <tr>
                    <th><?= __('Titulo') ?></th>
                    <td colspan=4><?= h($ticket->titulo) ?></td>
                </tr>
                <tr>
                    <th><?= __('Descripcion') ?></th>
                    <td colspan=4><?= h($ticket->descripcion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Proyecto') ?></th>
                    <td><?= h($ticket->proyecto ->nombre) ?></td>
					<th><?= __('Tipo') ?></th>
                    <td><?= h($ticket->tipo ->nombre) ?></td>
                </tr>
                <tr>
                    <th><?= __('Estado') ?></th>
                    <td><?= h($ticket->estado ->nombre) ?></td>
					<th><?= __('Usuario') ?></th>
                    <td><?= h($ticket->user ->first_name.' '.$ticket->user ->last_name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Usuario Asignado') ?></th>
                    <td><?= h($ticket->asignado_id) ?></td>
					<th><?= __('Subcategoria') ?></th>
                    <td><?= h($ticket->subcategoria ->nombre) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($ticket->id) ?></td>
					<th><?= __('Prioridad') ?></th>
                    <td><?= h($ticket->prioridad ->nombre) ?></td>
                </tr>
				 <tr>
					<th><?= __('Fecha Creacion') ?></th>
                    <td colspan=4><?= h($ticket->fecha_creacion) ?></td>
				 </tr>
            </table>
			
			</br>
			</br>
			
			
			<nav>
			  <div class="nav nav-tabs" id="nav-tab" role="tablist">
			    <a class="nav-item nav-link active" id="tab2" data-toggle="tab" href="#nav-2" role="tab" aria-controls="nav-2" aria-selected="false">Historico de Cambios</a>
				<a class="nav-item nav-link" id="tab1" data-toggle="tab" href="#nav-1" role="tab" aria-controls="nav-1" aria-selected="true">Comentarios</a>
				<a class="nav-item nav-link" id="tab3" data-toggle="tab" href="#nav-3" role="tab" aria-controls="nav-3" aria-selected="false" style="display:none">Puntajes de Encuestas</a>
				<a class="nav-item nav-link" id="tab3" data-toggle="tab" href="#nav-4" role="tab" aria-controls="nav-4" aria-selected="false" style="display:none">Seguidores por Ticket</a>
				<a class="nav-item nav-link" id="tab2" data-toggle="tab" href="#nav-5" role="tab" aria-controls="nav-5" aria-selected="false">Archivos por Ticket</a>
			  </div>
			</nav>
			<div class="tab-content" id="nav-tabContent">
			  <div class="tab-pane fade" id="nav-1" role="tabpanel" aria-labelledby="tab1">
					
						</br>
					
					
						<!-- Button trigger modal -->
						<button type="button" class="button" data-toggle="modal" data-target="#myModal">
						  Ingrese un comentario
						</button>

						<!-- Modal -->
						<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
						  <div class="modal-dialog" role="document">
							<div class="modal-content">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							  </div>
							  <div class="modal-body">
								<?= $this->Form->create(NULL,array('url'=>'/comentarios/add/'.$ticket->id.'/'.$userId)); ?>
								<fieldset>
									<legend><?= __('Agregue un comentario') ?></legend>
									<?php
										echo $this->Form->control('detalle');
										echo $this->Form->input('ticket_id',array('type'=>'hidden','value' => $ticket->id));
										echo $this->Form->input('user_id',array('type'=>'hidden','value' => $userId));
									?>
								</fieldset>
								</br>
								<?= $this->Form->button(__('Enviar')) ?>
								<?= $this->Form->end() ?>
							  </div>
							</div>
						  </div>
						</div>
					
					
						<h4><?= __('Comentarios del Ticket') ?></h4>
						<?php if (!empty($ticket->comentarios)) : ?>
						<div class="table-responsive">
							<table>
								<tr>
									<th><?= __('Detalle Comentario') ?></th>
									<th><?= __('Usuario que comentó') ?></th>
									<th><?= __('Fecha Creacion') ?></th>
								</tr>
								<?php foreach ($ticket->comentarios as $comentarios) : ?>
								<tr>
									<td><?= h($comentarios->detalle) ?></td>
									<td><?= h($comentarios->user->first_name.' '.$comentarios->user->last_name) ?></td>
									<td><?= h($comentarios->fecha_creacion) ?></td>
								</tr>
								<?php endforeach; ?>
							</table>
						</div>
						<?php endif; ?>
			  </div>
			  <div class="tab-pane fade show active" id="nav-2" role="tabpanel" aria-labelledby="tab2">
				  <div class="related">
					<?php if (!empty($ticket->historico_cambios)) : ?>
					<div class="table-responsive">
						<table>
							<tr>
								<th><?= __('Cambio') ?></th>
								<th><?= __('Cambio realizado por') ?></th>
								<th><?= __('Fecha ') ?></th>
							</tr>
							<?php foreach ($ticket->historico_cambios as $historicoCambios) : ?>
							<tr>
								<td><?= h($historicoCambios->cambio) ?></td>
								<td><?= h($historicoCambios->user->first_name.' '.$historicoCambios->user->last_name) ?></td>
								<td><?= h($historicoCambios->fecha_creacion) ?></td>
							</tr>
							<?php endforeach; ?>
						</table>
					</div>
					<?php endif; ?>
					</div>
			  </div>
			  <div class="tab-pane fade" id="nav-3" role="tabpanel" aria-labelledby="tab3">
					<div class="related">
                <h4><?= __('Puntajes de Encuesta') ?></h4>
                <?php if (!empty($ticket->puntajes)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Pregunta Id') ?></th>
                            <th><?= __('Ticket Id') ?></th>
                            <th><?= __('Calificacion') ?></th>
                            <th><?= __('Explicacion') ?></th>
                            <th><?= __('Fecha Creacion') ?></th>
                            <th class="actions"><?= __('Acciones') ?></th>
                        </tr>
                        <?php foreach ($ticket->puntajes as $puntajes) : ?>
                        <tr>
                            <td><?= h($puntajes->id) ?></td>
                            <td><?= h($puntajes->pregunta_id) ?></td>
                            <td><?= h($puntajes->ticket_id) ?></td>
                            <td><?= h($puntajes->calificacion) ?></td>
                            <td><?= h($puntajes->explicacion) ?></td>
                            <td><?= h($puntajes->fecha_creacion) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('Ver'), ['controller' => 'Puntajes', 'action' => 'view', $puntajes->id]) ?>
                                <?= $this->Html->link(__('Editar'), ['controller' => 'Puntajes', 'action' => 'edit', $puntajes->id]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
			  </div>
			  <div class="tab-pane fade" id="nav-4" role="tabpanel" aria-labelledby="tab4">
					<div class="related">
                <h4><?= __('Seguidores por Ticket') ?></h4>
                <?php if (!empty($ticket->seguidores)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('User Id') ?></th>
                            <th><?= __('Ticket Id') ?></th>
                            <th><?= __('Fecha Creacion') ?></th>
                            <th><?= __('Activo') ?></th>
                            <th class="actions"><?= __('Acciones') ?></th>
                        </tr>
                        <?php foreach ($ticket->seguidores as $seguidores) : ?>
                        <tr>
                            <td><?= h($seguidores->id) ?></td>
                            <td><?= h($seguidores->user_id) ?></td>
                            <td><?= h($seguidores->ticket_id) ?></td>
                            <td><?= h($seguidores->fecha_creacion) ?></td>
                            <td><?= h($seguidores->activo) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('Ver'), ['controller' => 'Seguidores', 'action' => 'view', $seguidores->id]) ?>
                                <?= $this->Html->link(__('Editar'), ['controller' => 'Seguidores', 'action' => 'edit', $seguidores->id]) ?>
                                <?= $this->Form->postLink(__('Eliminar'), ['controller' => 'Seguidores', 'action' => 'delete', $seguidores->id], ['confirm' => __('Quiere eliminar seguidor?', $seguidores->id)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
			  </div>
			  <div class="tab-pane fade" id="nav-5" role="tabpanel" aria-labelledby="tab5">
					<div class="related">
                </br>
					
					
						<!-- Button trigger modal -->
						<button type="button" class="button" data-toggle="modal" data-target="#myModalArchivo">
						  Ingrese un archivo
						</button>

						<!-- Modal -->
						<div class="modal fade" id="myModalArchivo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
						  <div class="modal-dialog" role="document">
							<div class="modal-content">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							  </div>
							  <div class="modal-body">
								<?= $this->Form->create(null,array('url'=>'/ticketarchivos/add/'.$ticket->id.'/'.$userId,'type' => 'file')); ?>
								<fieldset>
									<legend><?= __('Agregue un Archivo al ticket') ?></legend>
									<?php
										echo $this->Form->input('contenido', ['type' => 'file']);
										echo $this->Form->input('ticket_id',array('type'=>'hidden','value' => $ticket->id));
										echo $this->Form->input('user_id',array('type'=>'hidden','value' => $userId));
									?>
								</fieldset>
								</br>
								<?= $this->Form->button(__('Enviar')) ?>
								<?= $this->Form->end() ?>
							  </div>
							</div>
						  </div>
						</div>
                <?php if (!empty($ticket->ticket_archivos)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Nombre') ?></th>
							<th><?= __('Extensión') ?></th>
							<th><?= __('Tamaño') ?></th>
							<th><?= __('Descargar') ?></th>
                            <th><?= __('Fecha Creacion') ?></th>
                            <th class="actions"><?= __('Acciones') ?></th>
                        </tr>
                        <?php foreach ($ticket->ticket_archivos as $ticketArchivos) : ?>
                        <tr>
                            <td><?= h($ticketArchivos->nombre) ?></td>
							<td><?= h($ticketArchivos->extension) ?></td>
							<td><?= h($ticketArchivos->tamano) ?></td>
                            <td>
							<?php 
								echo $this->Html->link('link', ['controller' => 'Ticketarchivos', 'action' => 'download', $ticketArchivos->id]);
							?></td>
                            <td><?= h($ticketArchivos->fecha_creacion) ?></td>
                            <td class="actions">
                                <?= $this->Form->postLink(__('Eliminar'), ['controller' => 'TicketArchivos', 'action' => 'delete', $ticketArchivos->id], ['confirm' => __('Esta seguro de eliminar el archivo del ticket', $ticketArchivos->id)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
			  
			  </div>
			</div>
						
			
            
            
            
            
            
			
        </div>
    </div>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>