<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Ticket[]|\Cake\Collection\CollectionInterface $tickets
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>
<?php
	$userId = $this->getRequest()->getAttribute('identity')['id'] ?? null;
?>



<div class="tickets index content">
	<a class="button float-right" href="/tickets/add/<?= $userId ?>">Nuevo Ticket</a>
    
    <h3><?= __('Tickets') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('Id') ?></th>
                    <th><?= $this->Paginator->sort('Titulo') ?></th>
                    <th><?= $this->Paginator->sort('Proyecto') ?></th>
                    <th><?= $this->Paginator->sort('Estado') ?></th>
                    <th><?= $this->Paginator->sort('Prioridad') ?></th>
                    <th><?= $this->Paginator->sort('Usuario') ?></th>
                    <th><?= $this->Paginator->sort('Asignado a') ?></th>
                    <th><?= $this->Paginator->sort('Tipo') ?></th>
                    <th><?= $this->Paginator->sort('Subcategoria') ?></th>
                    <th><?= $this->Paginator->sort('Fecha Creacion') ?></th>
                    <th class="actions"><?= __('Accion') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tickets as $ticket): ?>
                <tr>
                    <td><?= $this->Number->format($ticket->id) ?></td>
                    <td><?= h($ticket->titulo) ?></td>
                    <td><?= h($ticket->proyecto ->nombre) ?></td>
					<td><?= h($ticket->estado ->nombre) ?></td>
					<td><?= h($ticket->prioridad ->nombre) ?></td>
                    <td><?= h($ticket->user ->first_name.' '.$ticket->user ->last_name) ?></td>
                    <td><?= h($ticket->asignado_id) ?></td>
					<td><?= h($ticket->tipo ->nombre) ?></td>
					<td><?= h($ticket->subcategoria ->nombre) ?></td>
                    <td><?= h($ticket->fecha_creacion) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('Ver'), ['action' => 'view', $ticket->id]) ?>
						
						<?php
						if ($roleId != 'user') {	
						?>
                        <?= $this->Html->link(__('Editar'), ['action' => 'edit', $ticket->id]) ?>
						<?php
						}
						?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('primero')) ?>
            <?= $this->Paginator->prev('< ' . __('previo')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('siguiente') . ' >') ?>
            <?= $this->Paginator->last(__('ultimo') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Pagina {{page}} de {{pages}}, mostrando {{current}} registros(s) de un total de {{count}}')) ?></p>
    </div>
</div>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>