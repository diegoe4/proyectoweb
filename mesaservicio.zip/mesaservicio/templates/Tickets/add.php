<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Ticket $ticket
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>



    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
            <?= $this->Html->link(__('Listado de Tickets'), ['action' => 'list'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="tickets form content">
            <?= $this->Form->create($ticket) ?>
            <fieldset>
                <legend><?= __('Agregar Ticket') ?></legend>
				
		
				
                
					<div class="row">
					<div class="col-sm">
					<?php
					  echo $this->Form->control('proyecto_id', ['options' => $proyectos], ['label' => __d('cake_d_c/users', 'Proyecto')]);
					  ?>
					</div>
					<div class="col-sm">
					<?php
					 echo $this->Form->control('tipo_id', ['options' => $tipos], ['label' => __d('cake_d_c/users', 'Tipo')]);
					  ?>
					</div>
					
				    </div>
                    
					<?php
                    echo $this->Form->control('titulo', ['label' => __d('cake_d_c/users', 'Título')]);
                    echo $this->Form->control('descripcion',  ['type' => 'textarea'],['label' => __d('cake_d_c/users', 'Descripción')]);
					?>   
					
					
					
					<div class="row">
					<div class="col-sm">
					<?php
					  echo $this->Form->control('prioridad_id',['options' => $prioridads], ['label' => __d('cake_d_c/users', 'Prioridad')]);
					  ?>
					</div>
					<div class="col-sm">
					<?php
					echo $this->Form->control('subcategoria_id', ['options' => $subcategorias], ['label' => __d('cake_d_c/users', 'Subcategoría')]);
					  ?>
					</div>
				    </div>
            </fieldset>
			</br>
            <?= $this->Form->button(__('Enviar')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>

<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>