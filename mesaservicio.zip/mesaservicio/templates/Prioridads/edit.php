<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Prioridad $prioridad
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>



    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
            <?= $this->Html->link(__('Listado de Prioridades'), ['action' => 'list'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="prioridads form content">
            <?= $this->Form->create($prioridad) ?>
            <fieldset>
                <legend><?= __('Editar Prioridad') ?></legend>
                <?php
                     echo $this->Form->control('nombre', ['label' => __d('cake_d_c/users', 'Nombre')]);
                    echo $this->Form->control('descripcion', ['label' => __d('cake_d_c/users', 'Descripción')]);
                    echo $this->Form->control('activo', ['label' => __d('cake_d_c/users', 'Activo')]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Enviar')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>

<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>
