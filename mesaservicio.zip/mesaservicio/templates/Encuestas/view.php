<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Encuesta $encuesta
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>

    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
            <?= $this->Html->link(__('Listado de Encuestas'), ['action' => 'list'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
	</br>
    <div class="column-responsive column-80">
        <div class="encuestas view content">
            <table>
                <tr>
                    <th><?= __('Nombre') ?></th>
                    <td><?= h($encuesta->nombre) ?></td>
                </tr>
                <tr>
                    <th><?= __('Descripcion') ?></th>
                    <td><?= h($encuesta->descripcion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Departamento') ?></th>
                    <td><?= $encuesta->has('departamento') ? $this->Html->link($encuesta->departamento->nombre, ['controller' => 'Departamentos', 'action' => 'view', $encuesta->departamento->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($encuesta->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Fecha Creacion') ?></th>
                    <td><?= h($encuesta->fecha_creacion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Activo') ?></th>
                    <td><?= $encuesta->activo ? __('Si') : __('No'); ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Preguntas Relacionadas') ?></h4>
                <?php if (!empty($encuesta->preguntas)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Nombre') ?></th>
                            <th><?= __('Descripcion') ?></th>
                            <th><?= __('Encuesta Id') ?></th>
                            <th><?= __('Activo') ?></th>
                            <th><?= __('Explicacion Usuario') ?></th>
                            <th><?= __('Fecha Creacion') ?></th>
                            <th class="actions"><?= __('Acciones') ?></th>
                        </tr>
                        <?php foreach ($encuesta->preguntas as $preguntas) : ?>
                        <tr>
                            <td><?= h($preguntas->id) ?></td>
                            <td><?= h($preguntas->nombre) ?></td>
                            <td><?= h($preguntas->descripcion) ?></td>
                            <td><?= h($preguntas->encuesta_id) ?></td>
                            <td><?= h($preguntas->activo) ?></td>
                            <td><?= h($preguntas->explicacion_usuario) ?></td>
                            <td><?= h($preguntas->fecha_creacion) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('Ver'), ['controller' => 'Preguntas', 'action' => 'view', $preguntas->id]) ?>
                                <?= $this->Html->link(__('Editar'), ['controller' => 'Preguntas', 'action' => 'edit', $preguntas->id]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>