<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Proyecto $proyecto
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>

    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
            <?= $this->Html->link(__('Listado de Proyectos'), ['action' => 'list'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
	</br>
    <div class="column-responsive column-80">
        <div class="proyectos view content">
            <table>
                <tr>
                    <th><?= __('Nombre') ?></th>
                    <td><?= h($proyecto->nombre) ?></td>
                </tr>
                <tr>
                    <th><?= __('Descripcion') ?></th>
                    <td><?= h($proyecto->descripcion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($proyecto->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Fecha Creacion') ?></th>
                    <td><?= h($proyecto->fecha_creacion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Activo') ?></th>
                    <td><?= $proyecto->activo ? __('Si') : __('No'); ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Tickets Relacionados') ?></h4>
                <?php if (!empty($proyecto->tickets)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Titulo') ?></th>
                            <th><?= __('Descripcion') ?></th>
                            <th><?= __('Proyecto Id') ?></th>
                            <th><?= __('Estado Id') ?></th>
                            <th><?= __('Prioridad Id') ?></th>
                            <th><?= __('Usuario Id') ?></th>
                            <th><?= __('Asignado Id') ?></th>
                            <th><?= __('Tipo Id') ?></th>
                            <th><?= __('Subcategoria Id') ?></th>
                            <th><?= __('Fecha Creacion') ?></th>
                            <th class="actions"><?= __('Acciones') ?></th>
                        </tr>
                        <?php foreach ($proyecto->tickets as $tickets) : ?>
                        <tr>
                            <td><?= h($tickets->id) ?></td>
                            <td><?= h($tickets->titulo) ?></td>
                            <td><?= h($tickets->descripcion) ?></td>
                            <td><?= h($tickets->proyecto_id) ?></td>
                            <td><?= h($tickets->estado_id) ?></td>
                            <td><?= h($tickets->prioridad_id) ?></td>
                            <td><?= h($tickets->usuario_id) ?></td>
                            <td><?= h($tickets->asignado_id) ?></td>
                            <td><?= h($tickets->tipo_id) ?></td>
                            <td><?= h($tickets->subcategoria_id) ?></td>
                            <td><?= h($tickets->fecha_creacion) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('Ver'), ['controller' => 'Tickets', 'action' => 'view', $tickets->id]) ?>
                                <?= $this->Html->link(__('Editar'), ['controller' => 'Tickets', 'action' => 'edit', $tickets->id]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>