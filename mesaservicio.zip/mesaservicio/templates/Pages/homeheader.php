<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link      https://cakephp.org CakePHP(tm) Project
 * @since     0.10.0
 * @license   https://opensource.org/licenses/mit-license.php MIT License
 * @var \App\View\AppView $this
 */
use Cake\Cache\Cache;
use Cake\Core\Configure;
use Cake\Core\Plugin;
use Cake\Datasource\ConnectionManager;
use Cake\Error\Debugger;
use Cake\Http\Exception\NotFoundException;

$this->disableAutoLayout();

if (!Configure::read('debug')) :
    throw new NotFoundException(
        'Please replace templates/Pages/home.php with your own version or re-enable debug mode.'
    );
endif;

$cakeDescription = 'CakePHP: the rapid development PHP framework';
?>

<?php

	$roleId = $this->getRequest()->getAttribute('identity')['role'] ?? null;
	$userId = $this->getRequest()->getAttribute('identity')['id'] ?? null;
	$userFullName = $this->getRequest()->getAttribute('identity')['first_name'].' '.$this->getRequest()->getAttribute('identity')['last_name'] ;
?>

<!DOCTYPE html>
<html>
<head>
    <?= $this->Html->charset() ?>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistema Mesa de Servicio</title>
    <?= $this->Html->meta('icon') ?>

    <link href="https://fonts.googleapis.com/css?family=Raleway:400,700" rel="stylesheet">

    <?= $this->Html->css(['milligram.min', 'cake', 'home','bootstrap.min']) ?>
	<?= $this->Html->script(['jquery-3.5.1.min','bootstrap.min']) ?>

    <?= $this->fetch('meta') ?>
    <?= $this->fetch('css') ?>
    <?= $this->fetch('script') ?>
</head>
<body>
	 <img src="/img/banner.jpg" alt="banner" >
	 <!-- Inicio Menu Principal página Principal  -->
     <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand" href="#">Mesa de Servicios</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="/">Inicio </a>
          </li>
          
         <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <b>Tickets</b> 		 
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="/tickets/add/<?= $userId ?>">Ingresar</a>
			  <a class="dropdown-item" href="/tickets/list_user/<?= $userId ?>">Mis Tickets</a>
			  
			<?php
			if ($roleId != 'user') {	
			?>
			  <div class="dropdown-divider"></div>
			  <a class="dropdown-item" href="/tickets/list">Todos los Tickets</a>
			  <?php
			}
			?>
            </div>
          </li>	 
		  
		  
		 		  
		  <?php
			if ($roleId == 'superadmin') {	
			?>
		
		 <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <b>Reportes</b> 		 
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
			  <a class="dropdown-item" href="/reportes/reportetickets/<?php echo date("Y"); ?>">Tickets por estado en un determinado rango de tiempo</a>
			  <a class="dropdown-item" href="/reportes/reporteticketsarea/<?php echo date("Y"); ?>/1">Tickets por estado en un determinado rango de tiempo por Área</a>
			  <a class="dropdown-item" href="/reportes/reporteticketsdepartamento/<?php echo date("Y"); ?>/1">Tickets por estado en un determinado rango de tiempo por Departamento</a>
			  <a class="dropdown-item" href="/reportes/reporteticketssucursal/<?php echo date("Y"); ?>/1">Tickets por estado en un determinado rango de tiempo por Sucursal</a>
			  <a class="dropdown-item" href="/reportes/reporteticketsgeneral/<?php echo date("Y"); ?>">Tickets por Categoría por año</a>
			</div>  
          </li>				
			
		  <li class="nav-item dropdown" >
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <b>Encuestas</b> 		 
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
			  <a class="dropdown-item" href="/encuestas/add">Crear Encuesta</a>
			  <a class="dropdown-item" href="/preguntas/add">Ingresar Preguntas por Encuesta</a>
			  <div class="dropdown-divider"></div>
			  <a class="dropdown-item" href="/puntajes/list">Puntaje de las Encuestas</a>
            </div>
          </li>	
		  <?php
			}
			?>
			
		  <?php
			if ($roleId == 'superadmin') {	
		   ?>
		  <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <b>Administraci&oacute;n</b> 		 
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
			  <h5 class="dropdown-header">Catálogos de los Tickets</h5>
			  <a class="dropdown-item" href="/proyectos/list">Proyectos</a>
			  <a class="dropdown-item" href="/prioridads/list">Prioridades</a>
			  <a class="dropdown-item" href="/tipos/list">Tipo</a>
			  <a class="dropdown-item" href="/estados/list">Estados</a>
			  <a class="dropdown-item" href="/categorias/list">Categoria</a>
			  <a class="dropdown-item" href="/subcategorias/list">SubCategoria</a>
			  <h5 class="dropdown-header">Catálogos de Usuarios</h5>
			  <a class="dropdown-item" href="/empresas/list">Empresas</a>
			  <a class="dropdown-item" href="/sucursals/list">Sucursales</a>
			  <a class="dropdown-item" href="/departamentos/list">Departamentos</a>
			  <a class="dropdown-item" href="/areas/list">Areas</a>
			  <a class="dropdown-item" href="/empleados/list">Empleados</a>
			   
			  <h5 class="dropdown-header">Usuarios</h5>
			  <a class="dropdown-item" href="/users/users/index">Usuarios</a>
			
            </div>
          </li>	
		    <?php
			}
			?>
        </ul>
        <form class="form-inline my-2 my-lg-0" style="display:none">
          <input class="form-control mr-sm-2" type="search" placeholder="Buscar tickets" aria-label="Search">
          <button class="button" type="submit">Buscar</button>
        </form>
		<li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <b>Bienvenido:</b> <?= $userFullName ?>  &nbsp; <b> - Rol:&nbsp;</b> 
			<?php
			if ($roleId == 'user') {
				echo "Usuario";
			} elseif ($roleId == 'admin') {
				echo "Analista Mesa de Servicios";
			} else {
				echo "Director Mesa de Servicios";
			}
			?>
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="/users/users/change-password">Cambiar clave</a>
			  <a class="dropdown-item" href="/users/users/edit/<?= $userId ?>">Actualizar Datos</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="/users/users/logout">Cerrar Sesi&oacute;n</a>
            </div>
          </li>	
      </div>
    </nav>
	<!-- Fin Menu Principal página Principal  -->
	
	</br>
    
    <main class="main">
        <div class="container">
            <div class="content">
			<?= $this->Flash->render('auth') ?>
                   