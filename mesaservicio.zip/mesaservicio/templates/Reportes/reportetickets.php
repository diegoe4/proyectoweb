<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Departamento $departamento
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>


<script>
	// Funcion que nos permite redireccionar por medio de un parametro a la pagina por medio del ano
	function redireccionar(value){
		var urlOriginal = window.location.origin;
		window.location = urlOriginal.concat('/reportes/reportetickets/',value);
	}	
</script>
<?php $chart->printScripts(); ?>			
		
			<legend>Seleccione un año de consulta</legend>
			<?php
			//conseguimos el ano actual
			$Startyear=date('Y');
			$endYear=$Startyear-10;
			$yearSelected = str_replace("/reportes/reportetickets/", "", $_SERVER['REQUEST_URI']);
			// set start and end year range i.e the start year
			$yearArray = range($Startyear,$endYear);
			?>
			<!-- mostramos la lista de datos -->
			<select name="year" style="width: 120px;" onchange="redireccionar(this.value);">
				<?php
				foreach ($yearArray as $year) {
					// Seleccionamos el ano actual
					$selected = ($year == $yearSelected) ? 'selected' : '';
					echo '<option '.$selected.' value="'.$year.'">'.$year.'</option>';
				}
				?>
			</select>
        <div id="container"></div>
		<script type="text/javascript"><?php echo $chart->render("chart"); ?></script>
	
	
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>
