<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Departamento $departamento
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>


<script>
	// Funcion que nos permite redireccionar por medio de un parametro a la pagina por medio del ano
	function redireccionar(ano,departamento){
		if(ano ==''){
			alert('Seleccione un año');
			return false;
		}
		if(departamento ==''){
			alert('Seleccione una departamento');
			return false;
		}
		var urlOriginal = window.location.origin;
		window.location = urlOriginal.concat('/reportes/reporteticketsdepartamento/',ano,'/',departamento);
	}

</script>
<?php $chart->printScripts(); ?>			
			<div class="row">
				<div class="col-6">
				<legend>Seleccione un año de consulta</legend>
				<?php
				//conseguimos el ano actual
				$Startyear=date('Y');
				$endYear=$Startyear-10;
				$yearSelected = str_replace("/reportes/reporteticketsdepartamento/", "", $_SERVER['REQUEST_URI']);
				// set start and end year range i.e the start year
				$yearArray = range($Startyear,$endYear);
				?>
				<!-- mostramos la lista de datos -->
				<select id="year" name="year" style="width: 120px;">
				
					<?php
					echo '<option value="">Seleccione una opción</option>';
					foreach ($yearArray as $year) {
						// Seleccionamos el ano actual
						
						$selected = ($year == $yearSelected) ? 'selected' : '';
						echo '<option '.$selected.' value="'.$year.'">'.$year.'</option>';
					}
					?>
				</select>
				</div>
				<div class="col-6">
				<?php
                    echo $this->Form->control('departamento_id', ['options' => $departamentos,'onChange'=>'redireccionar( $(\'#year\').val(),this.value);','label' => __d('cake_d_c/users', 'Seleccione un departamento de consulta'),'empty'=>'Seleccione una opción','default' => basename($_SERVER['REQUEST_URI'])]);
                ?>
				</div>
			</div>
			</br>
        <div id="container"></div>
		<script type="text/javascript"><?php echo $chart->render("chart"); ?></script>
		<hr>
		<?php
			if ($nombremayortickets != '' ) {	
		?>
		<legend>El departamento que más tickets tiene es <?=$nombremayortickets?> con <?=$valormayortickets?> tickets   </legend>
		<table class="table table-hover">
		<thead>
			<tr>
			<th scope="col">Enero</th>
			<th scope="col">Febrero</th>
			<th scope="col">Marzo</th>
			<th scope="col">Abril</th>
			<th scope="col">Mayo</th>
			<th scope="col">Junio</th>
			<th scope="col">Julio</th>
			<th scope="col">Agosto</th>
			<th scope="col">Septiembre</th>
			<th scope="col">Octubre</th>
			<th scope="col">Noviembre</th>
			<th scope="col">Diciembre</th>
			</tr>
		</thead>
		<tbody>
			<tr>
		    <td><?=$ticketsdepartamentototal[0]?></td>
			<td><?=$ticketsdepartamentototal[1]?></td>
			<td><?=$ticketsdepartamentototal[2]?></td>
			<td><?=$ticketsdepartamentototal[3]?></td>
			<td><?=$ticketsdepartamentototal[4]?></td>
			<td><?=$ticketsdepartamentototal[5]?></td>
			<td><?=$ticketsdepartamentototal[6]?></td>
			<td><?=$ticketsdepartamentototal[7]?></td>
			<td><?=$ticketsdepartamentototal[8]?></td>
			<td><?=$ticketsdepartamentototal[9]?></td>
			<td><?=$ticketsdepartamentototal[10]?></td>
			<td><?=$ticketsdepartamentototal[11]?></td>
			</tr>
		</tbody>
		</table>
		<?php
			} else {
		?>

	   <legend>No hay departamentos que tengan tickets   </legend>

		<?php
			} 
		?>
	
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>
