<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Departamento $departamento
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>


<script>
	// Funcion que nos permite redireccionar por medio de un parametro a la pagina por medio del ano
	function redireccionar(value){
		var urlOriginal = window.location.origin;
		window.location = urlOriginal.concat('/reportes/reporteticketsgeneral/',value);
	}	
</script>
			
		
			<legend>Seleccione un año de consulta</legend>
			<?php
			//conseguimos el ano actual
			$Startyear=date('Y');
			$endYear=$Startyear-10;
			$yearSelected = str_replace("/reportes/reporteticketsgeneral/", "", $_SERVER['REQUEST_URI']);
			// set start and end year range i.e the start year
			$yearArray = range($Startyear,$endYear);
			?>
			<!-- mostramos la lista de datos -->
			<select name="year" style="width: 120px;" onchange="redireccionar(this.value);">
				<?php
				foreach ($yearArray as $year) {
					// Seleccionamos el ano actual
					$selected = ($year == $yearSelected) ? 'selected' : '';
					echo '<option '.$selected.' value="'.$year.'">'.$year.'</option>';
				}
				?>
			</select>
			
			
		
		
		<hr>
		<legend>Categorías por Tickets en un determinado tiempo </legend>
		<table class="table table-hover">
		<thead>
			<tr>
			<th scope="col">Categoría</th>
			<th scope="col">Enero</th>
			<th scope="col">Febrero</th>
			<th scope="col">Marzo</th>
			<th scope="col">Abril</th>
			<th scope="col">Mayo</th>
			<th scope="col">Junio</th>
			<th scope="col">Julio</th>
			<th scope="col">Agosto</th>
			<th scope="col">Septiembre</th>
			<th scope="col">Octubre</th>
			<th scope="col">Noviembre</th>
			<th scope="col">Diciembre</th>
			<th scope="col">Total</th>
			</tr>
		</thead>
		<tbody>
		
			<tr>
			<td><?=$ticketscategoriatotalsanombre?></td>
			<td><?=$ticketscategoriatotalsa[0]?></td>
			<td><?=$ticketscategoriatotalsa[1]?></td>
			<td><?=$ticketscategoriatotalsa[2]?></td>
			<td><?=$ticketscategoriatotalsa[3]?></td>
			<td><?=$ticketscategoriatotalsa[4]?></td>
			<td><?=$ticketscategoriatotalsa[5]?></td>
			<td><?=$ticketscategoriatotalsa[6]?></td>
			<td><?=$ticketscategoriatotalsa[7]?></td>
			<td><?=$ticketscategoriatotalsa[8]?></td>
			<td><?=$ticketscategoriatotalsa[9]?></td>
			<td><?=$ticketscategoriatotalsa[10]?></td>
			<td><?=$ticketscategoriatotalsa[11]?></td>
			<td><?=$ticketscategoriatotalsa[12]?></td>
			</tr>
			<tr>
			<td><?=$ticketscategoriatotalsinombre?></td>
			<td><?=$ticketscategoriatotalsi[0]?></td>
			<td><?=$ticketscategoriatotalsi[1]?></td>
			<td><?=$ticketscategoriatotalsi[2]?></td>
			<td><?=$ticketscategoriatotalsi[3]?></td>
			<td><?=$ticketscategoriatotalsi[4]?></td>
			<td><?=$ticketscategoriatotalsi[5]?></td>
			<td><?=$ticketscategoriatotalsi[6]?></td>
			<td><?=$ticketscategoriatotalsi[7]?></td>
			<td><?=$ticketscategoriatotalsi[8]?></td>
			<td><?=$ticketscategoriatotalsi[9]?></td>
			<td><?=$ticketscategoriatotalsi[10]?></td>
			<td><?=$ticketscategoriatotalsi[11]?></td>
			<td><?=$ticketscategoriatotalsi[12]?></td>
			</tr>
		
		</tbody>
		</table>
		
		
	
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>
