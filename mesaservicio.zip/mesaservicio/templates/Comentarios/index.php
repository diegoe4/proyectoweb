<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Comentario[]|\Cake\Collection\CollectionInterface $comentarios
 */
?>
<div class="comentarios index content">
    <?= $this->Html->link(__('New Comentario'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Comentarios') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('detalle') ?></th>
                    <th><?= $this->Paginator->sort('ticket_id') ?></th>
                    <th><?= $this->Paginator->sort('usuario_id') ?></th>
                    <th><?= $this->Paginator->sort('fecha_creacion') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($comentarios as $comentario): ?>
                <tr>
                    <td><?= $this->Number->format($comentario->id) ?></td>
                    <td><?= h($comentario->detalle) ?></td>
                    <td><?= $comentario->has('ticket') ? $this->Html->link($comentario->ticket->id, ['controller' => 'Tickets', 'action' => 'view', $comentario->ticket->id]) : '' ?></td>
                    <td><?= $comentario->has('user') ? $this->Html->link($comentario->user->id, ['controller' => 'Users', 'action' => 'view', $comentario->user->id]) : '' ?></td>
                    <td><?= h($comentario->fecha_creacion) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $comentario->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $comentario->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $comentario->id], ['confirm' => __('Are you sure you want to delete # {0}?', $comentario->id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
