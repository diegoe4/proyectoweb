<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Comentario $comentario
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Comentario'), ['action' => 'edit', $comentario->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Comentario'), ['action' => 'delete', $comentario->id], ['confirm' => __('Are you sure you want to delete # {0}?', $comentario->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Comentarios'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Comentario'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="comentarios view content">
            <h3><?= h($comentario->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Detalle') ?></th>
                    <td><?= h($comentario->detalle) ?></td>
                </tr>
                <tr>
                    <th><?= __('Ticket') ?></th>
                    <td><?= $comentario->has('ticket') ? $this->Html->link($comentario->ticket->id, ['controller' => 'Tickets', 'action' => 'view', $comentario->ticket->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('User') ?></th>
                    <td><?= $comentario->has('user') ? $this->Html->link($comentario->user->id, ['controller' => 'Users', 'action' => 'view', $comentario->user->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($comentario->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Fecha Creacion') ?></th>
                    <td><?= h($comentario->fecha_creacion) ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Related Comentario Archivos') ?></h4>
                <?php if (!empty($comentario->comentario_archivos)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Nombre') ?></th>
                            <th><?= __('Extension') ?></th>
                            <th><?= __('Contenido') ?></th>
                            <th><?= __('Tamano') ?></th>
                            <th><?= __('Comentario Id') ?></th>
                            <th><?= __('Fecha Creacion') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($comentario->comentario_archivos as $comentarioArchivos) : ?>
                        <tr>
                            <td><?= h($comentarioArchivos->id) ?></td>
                            <td><?= h($comentarioArchivos->nombre) ?></td>
                            <td><?= h($comentarioArchivos->extension) ?></td>
                            <td><?= h($comentarioArchivos->contenido) ?></td>
                            <td><?= h($comentarioArchivos->tamano) ?></td>
                            <td><?= h($comentarioArchivos->comentario_id) ?></td>
                            <td><?= h($comentarioArchivos->fecha_creacion) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'ComentarioArchivos', 'action' => 'view', $comentarioArchivos->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'ComentarioArchivos', 'action' => 'edit', $comentarioArchivos->id]) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'ComentarioArchivos', 'action' => 'delete', $comentarioArchivos->id], ['confirm' => __('Are you sure you want to delete # {0}?', $comentarioArchivos->id)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Historico Cambios') ?></h4>
                <?php if (!empty($comentario->historico_cambios)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Ticket Id') ?></th>
                            <th><?= __('Cambio') ?></th>
                            <th><?= __('Comentario Id') ?></th>
                            <th><?= __('Fecha Creacion') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($comentario->historico_cambios as $historicoCambios) : ?>
                        <tr>
                            <td><?= h($historicoCambios->id) ?></td>
                            <td><?= h($historicoCambios->ticket_id) ?></td>
                            <td><?= h($historicoCambios->cambio) ?></td>
                            <td><?= h($historicoCambios->comentario_id) ?></td>
                            <td><?= h($historicoCambios->fecha_creacion) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'HistoricoCambios', 'action' => 'view', $historicoCambios->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'HistoricoCambios', 'action' => 'edit', $historicoCambios->id]) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'HistoricoCambios', 'action' => 'delete', $historicoCambios->id], ['confirm' => __('Are you sure you want to delete # {0}?', $historicoCambios->id)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
