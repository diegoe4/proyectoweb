<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\ComentarioArchivo $comentarioArchivo
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Comentario Archivos'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="comentarioArchivos form content">
            <?= $this->Form->create($comentarioArchivo) ?>
            <fieldset>
                <legend><?= __('Add Comentario Archivo') ?></legend>
                <?php
                    echo $this->Form->control('nombre');
                    echo $this->Form->control('extension');
                    echo $this->Form->control('tamano');
                    echo $this->Form->control('comentario_id', ['options' => $comentarios]);
                    echo $this->Form->control('fecha_creacion');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
