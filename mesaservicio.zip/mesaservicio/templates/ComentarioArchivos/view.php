<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\ComentarioArchivo $comentarioArchivo
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Comentario Archivo'), ['action' => 'edit', $comentarioArchivo->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Comentario Archivo'), ['action' => 'delete', $comentarioArchivo->id], ['confirm' => __('Are you sure you want to delete # {0}?', $comentarioArchivo->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Comentario Archivos'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Comentario Archivo'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="comentarioArchivos view content">
            <h3><?= h($comentarioArchivo->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Nombre') ?></th>
                    <td><?= h($comentarioArchivo->nombre) ?></td>
                </tr>
                <tr>
                    <th><?= __('Extension') ?></th>
                    <td><?= h($comentarioArchivo->extension) ?></td>
                </tr>
                <tr>
                    <th><?= __('Comentario') ?></th>
                    <td><?= $comentarioArchivo->has('comentario') ? $this->Html->link($comentarioArchivo->comentario->id, ['controller' => 'Comentarios', 'action' => 'view', $comentarioArchivo->comentario->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($comentarioArchivo->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Tamano') ?></th>
                    <td><?= $this->Number->format($comentarioArchivo->tamano) ?></td>
                </tr>
                <tr>
                    <th><?= __('Fecha Creacion') ?></th>
                    <td><?= h($comentarioArchivo->fecha_creacion) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
