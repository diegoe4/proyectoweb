<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\ComentarioArchivo[]|\Cake\Collection\CollectionInterface $comentarioArchivos
 */
?>
<div class="comentarioArchivos index content">
    <?= $this->Html->link(__('New Comentario Archivo'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Comentario Archivos') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('nombre') ?></th>
                    <th><?= $this->Paginator->sort('extension') ?></th>
                    <th><?= $this->Paginator->sort('tamano') ?></th>
                    <th><?= $this->Paginator->sort('comentario_id') ?></th>
                    <th><?= $this->Paginator->sort('fecha_creacion') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($comentarioArchivos as $comentarioArchivo): ?>
                <tr>
                    <td><?= $this->Number->format($comentarioArchivo->id) ?></td>
                    <td><?= h($comentarioArchivo->nombre) ?></td>
                    <td><?= h($comentarioArchivo->extension) ?></td>
                    <td><?= $this->Number->format($comentarioArchivo->tamano) ?></td>
                    <td><?= $comentarioArchivo->has('comentario') ? $this->Html->link($comentarioArchivo->comentario->id, ['controller' => 'Comentarios', 'action' => 'view', $comentarioArchivo->comentario->id]) : '' ?></td>
                    <td><?= h($comentarioArchivo->fecha_creacion) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $comentarioArchivo->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $comentarioArchivo->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $comentarioArchivo->id], ['confirm' => __('Are you sure you want to delete # {0}?', $comentarioArchivo->id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
