<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Pregunta $pregunta
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>


    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
            <?= $this->Html->link(__('Listado de Preguntas'), ['action' => 'list'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
	</br>
    <div class="column-responsive column-80">
        <div class="preguntas form content">
            <?= $this->Form->create($pregunta) ?>
            <fieldset>
                <legend><?= __('Agregar Pregunta') ?></legend>
                <?php
                    echo $this->Form->control('nombre', ['label' => __d('cake_d_c/users', 'Nombre')]);
                    echo $this->Form->control('descripcion', ['label' => __d('cake_d_c/users', 'Descripción')]);
                    echo $this->Form->control('encuesta_id', ['options' => $encuestas], ['label' => __d('cake_d_c/users', 'Encuesta')]);
                    echo $this->Form->control('activo', ['label' => __d('cake_d_c/users', 'Activo')]);
                    echo $this->Form->control('orden', ['label' => __d('cake_d_c/users', 'Orden')]);
                    echo $this->Form->control('explicacion_usuario', ['label' => __d('cake_d_c/users', 'Tiene explicacion usuario')]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Enviar')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>