<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Pregunta $pregunta
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
            <?= $this->Html->link(__('Listado de Preguntas'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
	</br>
    <div class="column-responsive column-80">
        <div class="preguntas view content">
            <table>
                <tr>
                    <th><?= __('Nombre') ?></th>
                    <td><?= h($pregunta->nombre) ?></td>
                </tr>
                <tr>
                    <th><?= __('Descripcion') ?></th>
                    <td><?= h($pregunta->descripcion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Encuesta') ?></th>
                    <td><?= $pregunta->has('encuesta') ? $this->Html->link($pregunta->encuesta->id, ['controller' => 'Encuestas', 'action' => 'view', $pregunta->encuesta->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($pregunta->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Fecha Creacion') ?></th>
                    <td><?= h($pregunta->fecha_creacion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Activo') ?></th>
                    <td><?= $pregunta->activo ? __('Yes') : __('No'); ?></td>
                </tr>
                <tr>
                    <th><?= __('Orden') ?></th>
                    <td><?= $pregunta->orden; ?></td>
                </tr>
                <tr>
                    <th><?= __('Explicacion Usuario') ?></th>
                    <td><?= $pregunta->explicacion_usuario ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Puntajes Relacionados ') ?></h4>
                <?php if (!empty($pregunta->puntajes)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Pregunta Id') ?></th>
                            <th><?= __('Ticket Id') ?></th>
                            <th><?= __('Calificacion') ?></th>
                            <th><?= __('Explicacion') ?></th>
                            <th><?= __('Fecha Creacion') ?></th>
                            <th class="actions"><?= __('Acciones') ?></th>
                        </tr>
                        <?php foreach ($pregunta->puntajes as $puntajes) : ?>
                        <tr>
                            <td><?= h($puntajes->id) ?></td>
                            <td><?= h($puntajes->pregunta_id) ?></td>
                            <td><?= h($puntajes->ticket_id) ?></td>
                            <td><?= h($puntajes->calificacion) ?></td>
                            <td><?= h($puntajes->explicacion) ?></td>
                            <td><?= h($puntajes->fecha_creacion) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('Ver'), ['controller' => 'Puntajes', 'action' => 'view', $puntajes->id]) ?>
                                <?= $this->Html->link(__('Editar'), ['controller' => 'Puntajes', 'action' => 'edit', $puntajes->id]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>
