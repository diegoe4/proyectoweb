<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\HistoricoCambio[]|\Cake\Collection\CollectionInterface $historicoCambios
 */
?>
<div class="historicoCambios index content">
    <?= $this->Html->link(__('New Historico Cambio'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Historico Cambios') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('ticket_id') ?></th>
                    <th><?= $this->Paginator->sort('cambio') ?></th>
                    <th><?= $this->Paginator->sort('comentario_id') ?></th>
                    <th><?= $this->Paginator->sort('user_id') ?></th>
                    <th><?= $this->Paginator->sort('fecha_creacion') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($historicoCambios as $historicoCambio): ?>
                <tr>
                    <td><?= $this->Number->format($historicoCambio->id) ?></td>
                    <td><?= $historicoCambio->has('ticket') ? $this->Html->link($historicoCambio->ticket->titulo, ['controller' => 'Tickets', 'action' => 'view', $historicoCambio->ticket->id]) : '' ?></td>
                    <td><?= h($historicoCambio->cambio) ?></td>
                    <td><?= $historicoCambio->has('comentario') ? $this->Html->link($historicoCambio->comentario->id, ['controller' => 'Comentarios', 'action' => 'view', $historicoCambio->comentario->id]) : '' ?></td>
                    <td><?= h($historicoCambio->user_id) ?></td>
                    <td><?= h($historicoCambio->fecha_creacion) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $historicoCambio->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $historicoCambio->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $historicoCambio->id], ['confirm' => __('Are you sure you want to delete # {0}?', $historicoCambio->id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
