<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\HistoricoCambio $historicoCambio
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Historico Cambio'), ['action' => 'edit', $historicoCambio->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Historico Cambio'), ['action' => 'delete', $historicoCambio->id], ['confirm' => __('Are you sure you want to delete # {0}?', $historicoCambio->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Historico Cambios'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Historico Cambio'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="historicoCambios view content">
            <h3><?= h($historicoCambio->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Ticket') ?></th>
                    <td><?= $historicoCambio->has('ticket') ? $this->Html->link($historicoCambio->ticket->titulo, ['controller' => 'Tickets', 'action' => 'view', $historicoCambio->ticket->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Cambio') ?></th>
                    <td><?= h($historicoCambio->cambio) ?></td>
                </tr>
                <tr>
                    <th><?= __('Comentario') ?></th>
                    <td><?= $historicoCambio->has('comentario') ? $this->Html->link($historicoCambio->comentario->id, ['controller' => 'Comentarios', 'action' => 'view', $historicoCambio->comentario->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('User Id') ?></th>
                    <td><?= h($historicoCambio->user_id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($historicoCambio->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Fecha Creacion') ?></th>
                    <td><?= h($historicoCambio->fecha_creacion) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
