<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\HistoricoCambio $historicoCambio
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $historicoCambio->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $historicoCambio->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Historico Cambios'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="historicoCambios form content">
            <?= $this->Form->create($historicoCambio) ?>
            <fieldset>
                <legend><?= __('Edit Historico Cambio') ?></legend>
                <?php
                    echo $this->Form->control('ticket_id', ['options' => $tickets]);
                    echo $this->Form->control('cambio');
                    echo $this->Form->control('comentario_id', ['options' => $comentarios, 'empty' => true]);
                    echo $this->Form->control('user_id');
                    echo $this->Form->control('fecha_creacion');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
