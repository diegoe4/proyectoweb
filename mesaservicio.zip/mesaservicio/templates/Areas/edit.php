<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Area $area
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>

    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
            <?= $this->Html->link(__('Listado de  Areas'), ['action' => 'list'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="areas form content">
            <?= $this->Form->create($area) ?>
            <fieldset>
                <legend><?= __('Editar Area') ?></legend>
                <?php
                    echo $this->Form->control('nombre', ['label' => __d('cake_d_c/users', 'Nombre')]);
                    echo $this->Form->control('descripcion', ['label' => __d('cake_d_c/users', 'Descripción')]);
                    echo $this->Form->control('departamento_id', ['options' => $departamentos], ['label' => __d('cake_d_c/users', 'Departamento')]);
                    echo $this->Form->control('mesa_servicio', ['label' => __d('cake_d_c/users', 'Es mesa de servicio')]);
                    echo $this->Form->control('activo', ['label' => __d('cake_d_c/users', 'Activo')]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Enviar')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>
