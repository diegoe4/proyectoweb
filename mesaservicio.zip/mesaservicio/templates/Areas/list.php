<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Area[]|\Cake\Collection\CollectionInterface $areas
 */
?>

<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>

<div class="areas index content">
    <?= $this->Html->link(__('Nueva Area'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Areas') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('nombre') ?></th>
                    <th><?= $this->Paginator->sort('descripcion') ?></th>
                    <th><?= $this->Paginator->sort('departamento_id') ?></th>
                    <th><?= $this->Paginator->sort('mesa_servicio') ?></th>
                    <th><?= $this->Paginator->sort('activo') ?></th>
                    <th><?= $this->Paginator->sort('fecha_creacion') ?></th>
                    <th class="actions"><?= __('Acciones') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($areas as $area): ?>
                <tr>
                    <td><?= $this->Number->format($area->id) ?></td>
                    <td><?= h($area->nombre) ?></td>
                    <td><?= h($area->descripcion) ?></td>
                    <td><?= $area->has('departamento') ? $this->Html->link($area->departamento->nombre, ['controller' => 'Departamentos', 'action' => 'view', $area->departamento->id]) : '' ?></td>
                    <td><?= h($area->mesa_servicio) ?></td>
                    <td><?= h($area->activo) ?></td>
                    <td><?= h($area->fecha_creacion) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('Ver'), ['action' => 'view', $area->id]) ?>
                        <?= $this->Html->link(__('Editar'), ['action' => 'edit', $area->id]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
  <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('primero')) ?>
            <?= $this->Paginator->prev('< ' . __('previo')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('siguiente') . ' >') ?>
            <?= $this->Paginator->last(__('ultimo') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Pagina {{page}} de {{pages}}, mostrando {{current}} registros(s) de un total de {{count}}')) ?></p>
    </div>
</div>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>