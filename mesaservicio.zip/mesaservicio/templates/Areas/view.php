<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Area $area
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>

    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
            <?= $this->Html->link(__('Listado de Areas'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
	</br>
    <div class="column-responsive column-80">
        <div class="areas view content">
            <table>
                <tr>
                    <th><?= __('Nombre') ?></th>
                    <td><?= h($area->nombre) ?></td>
                </tr>
                <tr>
                    <th><?= __('Descripcion') ?></th>
                    <td><?= h($area->descripcion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Departamento') ?></th>
                    <td><?= $area->has('departamento') ? $this->Html->link($area->departamento->nombre, ['controller' => 'Departamentos', 'action' => 'view', $area->departamento->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($area->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Fecha Creacion') ?></th>
                    <td><?= h($area->fecha_creacion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Mesa Servicio') ?></th>
                    <td><?= $area->mesa_servicio ? __('Si') : __('No'); ?></td>
                </tr>
                <tr>
                    <th><?= __('Activo') ?></th>
                    <td><?= $area->activo ? __('Si') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>

<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>