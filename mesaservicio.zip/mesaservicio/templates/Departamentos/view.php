<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Departamento $departamento
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>

    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
			<?= $this->Html->link(__('Listado de Departamentos'), ['action' => 'list'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
	</br>
    <div class="column-responsive column-80">
        <div class="departamentos view content">
            <table>
                <tr>
                    <th><?= __('Nombre') ?></th>
                    <td><?= h($departamento->nombre) ?></td>
                </tr>
                <tr>
                    <th><?= __('Descripcion') ?></th>
                    <td><?= h($departamento->descripcion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Empresa') ?></th>
                    <td><?= $departamento->has('empresa') ? $this->Html->link($departamento->empresa->id, ['controller' => 'Empresas', 'action' => 'view', $departamento->empresa->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($departamento->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Sucursal Id') ?></th>
                    <td><?= $this->Number->format($departamento->sucursal_id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Fecha Creacion') ?></th>
                    <td><?= h($departamento->fecha_creacion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Activo') ?></th>
                    <td><?= $departamento->activo ? __('Si') : __('No'); ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Areas Relacionadas') ?></h4>
                <?php if (!empty($departamento->areas)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Nombre') ?></th>
                            <th><?= __('Descripcion') ?></th>
                            <th><?= __('Departamento Id') ?></th>
                            <th><?= __('Mesa Servicio') ?></th>
                            <th><?= __('Activo') ?></th>
                            <th><?= __('Fecha Creacion') ?></th>
                            <th class="actions"><?= __('Acciones') ?></th>
                        </tr>
                        <?php foreach ($departamento->areas as $areas) : ?>
                        <tr>
                            <td><?= h($areas->id) ?></td>
                            <td><?= h($areas->nombre) ?></td>
                            <td><?= h($areas->descripcion) ?></td>
                            <td><?= h($areas->departamento_id) ?></td>
                            <td><?= h($areas->mesa_servicio) ?></td>
                            <td><?= h($areas->activo) ?></td>
                            <td><?= h($areas->fecha_creacion) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('Ver'), ['controller' => 'Areas', 'action' => 'view', $areas->id]) ?>
                                <?= $this->Html->link(__('Editar'), ['controller' => 'Areas', 'action' => 'edit', $areas->id]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Encuestas Relacionadas') ?></h4>
                <?php if (!empty($departamento->encuestas)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Nombre') ?></th>
                            <th><?= __('Descripcion') ?></th>
                            <th><?= __('Departamento Id') ?></th>
                            <th><?= __('Activo') ?></th>
                            <th><?= __('Fecha Creacion') ?></th>
                            <th class="actions"><?= __('Acciones') ?></th>
                        </tr>
                        <?php foreach ($departamento->encuestas as $encuestas) : ?>
                        <tr>
                            <td><?= h($encuestas->id) ?></td>
                            <td><?= h($encuestas->nombre) ?></td>
                            <td><?= h($encuestas->descripcion) ?></td>
                            <td><?= h($encuestas->departamento_id) ?></td>
                            <td><?= h($encuestas->activo) ?></td>
                            <td><?= h($encuestas->fecha_creacion) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('Ver'), ['controller' => 'Encuestas', 'action' => 'view', $encuestas->id]) ?>
                                <?= $this->Html->link(__('Editar'), ['controller' => 'Encuestas', 'action' => 'edit', $encuestas->id]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>
