<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Empresa $empresa
 */
?>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homeheader.php';
?>


    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Accion') ?></h4>
            <?= $this->Html->link(__('Listado de Empresas'), ['action' => 'list'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
	</br>
    <div class="column-responsive column-80">
        <div class="empresas view content">
            <table>
                <tr>
                    <th><?= __('Nombre') ?></th>
                    <td><?= h($empresa->nombre) ?></td>
                </tr>
                <tr>
                    <th><?= __('Descripcion') ?></th>
                    <td><?= h($empresa->descripcion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($empresa->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Fecha Creacion') ?></th>
                    <td><?= h($empresa->fecha_creacion) ?></td>
                </tr>
                <tr>
                    <th><?= __('Activo') ?></th>
                    <td><?= $empresa->activo ? __('Si') : __('No'); ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Departamentos relacionados') ?></h4>
                <?php if (!empty($empresa->departamentos)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Nombre') ?></th>
                            <th><?= __('Descripcion') ?></th>
                            <th><?= __('Empresa Id') ?></th>
                            <th><?= __('Sucursal Id') ?></th>
                            <th><?= __('Activo') ?></th>
                            <th><?= __('Fecha Creacion') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($empresa->departamentos as $departamentos) : ?>
                        <tr>
                            <td><?= h($departamentos->id) ?></td>
                            <td><?= h($departamentos->nombre) ?></td>
                            <td><?= h($departamentos->descripcion) ?></td>
                            <td><?= h($departamentos->empresa_id) ?></td>
                            <td><?= h($departamentos->sucursal_id) ?></td>
                            <td><?= h($departamentos->activo) ?></td>
                            <td><?= h($departamentos->fecha_creacion) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('Ver'), ['controller' => 'Departamentos', 'action' => 'view', $departamentos->id]) ?>
                                <?= $this->Html->link(__('Editar'), ['controller' => 'Departamentos', 'action' => 'edit', $departamentos->id]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php
include '..'.DS.'templates'.DS.'Pages'.DS.'homefooter.php';
?>
